cmake_minimum_required(VERSION 3.22)
project(whisperer_whisper LANGUAGES C CXX)

if(NOT EXISTS "${UPSTREAM_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "whisper.cpp sources not found at '${UPSTREAM_DIR}'. Clone them into third_party/whisper.cpp.")
endif()

set(CMAKE_C_FLAGS_DEBUG   "-O3 -DNDEBUG")
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG")
set(CMAKE_C_VISIBILITY_PRESET hidden)
set(CMAKE_CXX_VISIBILITY_PRESET hidden)

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_TESTS    OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_SERVER   OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP            OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE            OFF CACHE BOOL "" FORCE)

add_subdirectory(${UPSTREAM_DIR} whisper_build)

add_library(whisperer_whisper SHARED whisper_jni.cpp)
target_link_libraries(whisperer_whisper PRIVATE whisper log android)
target_link_options(whisperer_whisper PRIVATE -Wl,--exclude-libs,ALL -Wl,--gc-sections -Wl,-z,max-page-size=16384 -s)
