// JNI bridge: whisper.cpp <-> com.darksh3ep.whisperer.ai.speechrecognition.WhisperNative
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>
#include "whisper.h"

#define TAG "WhispererWhisper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {
struct Session {
    whisper_context *ctx = nullptr;
    std::atomic<bool> abort{false};
    std::mutex mu;
};

jbyteArray to_bytes(JNIEnv *env, const std::string &s) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(s.size()));
    if (arr && !s.empty()) env->SetByteArrayRegion(arr, 0, static_cast<jsize>(s.size()), reinterpret_cast<const jbyte *>(s.data()));
    return arr;
}
}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_darksh3ep_whisperer_ai_speechrecognition_WhisperNative_nativeLoad(JNIEnv *env, jclass, jstring jpath) {
    const char *c = env->GetStringUTFChars(jpath, nullptr);
    std::string path(c ? c : "");
    if (c) env->ReleaseStringUTFChars(jpath, c);

    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    whisper_context *ctx = whisper_init_from_file_with_params(path.c_str(), cp);
    if (!ctx) { LOGE("whisper model load failed: %s", path.c_str()); return 0; }
    auto *s = new Session();
    s->ctx = ctx;
    LOGI("loaded %s", path.c_str());
    return reinterpret_cast<jlong>(s);
}

JNIEXPORT void JNICALL
Java_com_darksh3ep_whisperer_ai_speechrecognition_WhisperNative_nativeAbort(JNIEnv *, jclass, jlong handle) {
    if (auto *s = reinterpret_cast<Session *>(handle)) s->abort.store(true);
}

JNIEXPORT void JNICALL
Java_com_darksh3ep_whisperer_ai_speechrecognition_WhisperNative_nativeFree(JNIEnv *, jclass, jlong handle) {
    auto *s = reinterpret_cast<Session *>(handle);
    if (!s) return;
    s->abort.store(true);
    {
        std::lock_guard<std::mutex> lock(s->mu);
        if (s->ctx) whisper_free(s->ctx);
    }
    delete s;
}

/** samples: 16 kHz mono float PCM. Returns UTF-8 text bytes, or null on failure. */
JNIEXPORT jbyteArray JNICALL
Java_com_darksh3ep_whisperer_ai_speechrecognition_WhisperNative_nativeTranscribe(JNIEnv *env, jclass, jlong handle,
        jfloatArray jsamples, jstring jlang, jint threads) {
    auto *s = reinterpret_cast<Session *>(handle);
    if (!s) return nullptr;
    std::lock_guard<std::mutex> lock(s->mu);
    s->abort.store(false);

    const char *lc = env->GetStringUTFChars(jlang, nullptr);
    std::string lang(lc ? lc : "auto");
    if (lc) env->ReleaseStringUTFChars(jlang, lc);

    jsize n = env->GetArrayLength(jsamples);
    std::vector<float> samples(static_cast<size_t>(n));
    env->GetFloatArrayRegion(jsamples, 0, n, samples.data());

    whisper_full_params p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.n_threads = threads;
    p.language = lang.c_str();
    p.translate = false;
    p.no_context = true;
    p.print_progress = false;
    p.print_realtime = false;
    p.print_timestamps = false;
    p.print_special = false;
    p.temperature = 0.0f;
    p.abort_callback = [](void *ud) -> bool { return static_cast<Session *>(ud)->abort.load(); };
    p.abort_callback_user_data = s;

    if (whisper_full(s->ctx, p, samples.data(), (int) samples.size()) != 0) {
        if (s->abort.load()) return to_bytes(env, "");
        LOGE("whisper_full failed");
        return nullptr;
    }
    std::string text;
    int segs = whisper_full_n_segments(s->ctx);
    for (int i = 0; i < segs; i++) {
        const char *t = whisper_full_get_segment_text(s->ctx, i);
        if (t) text += t;
    }
    return to_bytes(env, text);
}

}  // extern "C"
