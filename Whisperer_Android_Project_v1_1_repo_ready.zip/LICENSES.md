# Licenses and third-party notices

## Whisperer source code
Copyright (c) DarkSh3ep. No license has been chosen for the Whisperer source in this repository;
add a `LICENSE` file of your choice before publishing it publicly.

## Libraries used by the app (all Apache License 2.0)
- AndroidX (Core, Activity, Lifecycle, Navigation, DataStore)
- Jetpack Compose and Material 3
- Kotlin standard library and `kotlinx.coroutines`

Test-only: JUnit 4 (EPL 1.0), `kotlinx-coroutines-test` (Apache 2.0), `org.json:json` (JSON License).

The small UI icons in `app/src/main/res/drawable/ic_*.xml` use Material Icons geometry (Apache License 2.0).

## Models (NOT included in this repository or the APK)
| Component | Target | License note |
|---|---|---|
| Language model | Qwen2.5-Coder-3B-Instruct (Q6_K GGUF) | Released under the **Qwen Research License** (`qwen-research`), not Apache 2.0. Review the license text on the model page for restrictions (e.g. commercial use) before use or redistribution. |
| Speech recognition | Whisper Tiny | OpenAI Whisper weights are published under the MIT license. **Not integrated in this build.** |
| Speech output | Android TextToSpeech (device engine) | License/terms are those of the installed TTS engine and voice data. |

Verify licenses again at integration time; they can change.
