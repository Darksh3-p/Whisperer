// Top-level build file. Plugin versions are declared once here.
//
// Toolchain pairing (documented in README.md):
//   Android Gradle Plugin 9.4.0  <->  Gradle 9.6.1  <->  built-in Kotlin (AGP 9)  <->  JDK 17  <->  compileSdk 36
// AGP 9 compiles Kotlin itself, so the separate org.jetbrains.kotlin.android plugin must NOT be applied.
// The Compose compiler plugin is still required and its version must match the Kotlin version in use.
plugins {
    id("com.android.application") version "9.4.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.10" apply false
}
