pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Whisperer"
include(":app")

// Native AI runtimes (llama.cpp + whisper.cpp) are only built when their sources have been fetched into
// third_party/ (the GitHub Actions workflow does this). Without them the project still compiles (UI shell,
// Android speech) so it can be edited and built anywhere, e.g. in Code on the Go.
val nativeAiSources = settingsDir.resolve("third_party/llama.cpp/CMakeLists.txt").exists() &&
    settingsDir.resolve("third_party/whisper.cpp/CMakeLists.txt").exists()
if (nativeAiSources) {
    include(":llama", ":whisper")
}
