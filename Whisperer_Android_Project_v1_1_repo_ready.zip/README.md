# Whisperer

**Whisperer** is a voice-first personal AI assistant for Android, by **DarkSh3ep**.
Native Kotlin + Jetpack Compose, single `app` module, MVVM-style layers, no DI framework.

> **Read this first — honest status.** Version 1.1 adds the pieces needed for a working assistant:
> in-app **import** of the assistant model (GGUF), the Whisper model and free **voice packs**, plus native
> runtimes (llama.cpp, whisper.cpp, sherpa-onnx). **None of this has been compiled or run by the author** — it was
> written without an Android SDK, NDK or network. The first GitHub Actions run is the real build test; if it fails,
> send the first error from the log. See [`docs/FEATURE_STATUS.md`](docs/FEATURE_STATUS.md).

## How the AI parts work

| Part | Engine | Model you import | Where it comes from |
|---|---|---|---|
| Assistant | llama.cpp (`:llama` module, JNI) | any chat `*.gguf` (e.g. Qwen2.5-Coder-3B-Instruct Q6_K) | built by the GitHub workflow |
| Listening | whisper.cpp (`:whisper` module, JNI) | whisper.cpp ggml `*.bin` (e.g. `ggml-tiny.bin`, `ggml-tiny.en.bin`) | built by the GitHub workflow |
| Speaking | sherpa-onnx (prebuilt) | sherpa-onnx TTS voice pack (`.tar.bz2` / `.zip`) | downloaded by the workflow |

Without an imported Whisper model, listening falls back to Android's on-device recognizer; without a voice pack,
speaking falls back to Android's installed offline voices. Whisperer never uses an online recognizer or voice.

**Import:** *Settings → AI model* has an *Import* button for each model, and *Settings → Voice and audio* has *Import voice pack*.
They use Android's file picker (no storage permission) and copy the file into app-private storage.

**Voice packs:** use sherpa-onnx TTS packs, e.g. `vits-piper-en_US-amy-low.tar.bz2` from the `tts-models` release of
`github.com/k2-fsa/sherpa-onnx`. Supported: VITS/Piper-style packs and Kokoro packs (folder with `tokens.txt`, an `.onnx`
model, usually `espeak-ng-data/`). Not supported: two-stage packs (Matcha) and raw Piper downloads from Hugging Face
(`.onnx` + `.onnx.json` without `tokens.txt` / metadata).

## Where to build

* **GitHub Actions (needed for a working AI APK).** The workflow fetches llama.cpp, whisper.cpp and sherpa-onnx and
  compiles the native code with NDK 28. Build takes roughly 10–25 minutes. Install the `whisperer-debug-apk` artifact.
* **Code on the Go / plain Android Studio:** works as before for the UI shell. Without `third_party/` the Gradle build
  skips the native modules and the app reports "AI runtime not included". Do not expect AI from a local build.
* The debug APK is signed with the committed `app/debug.keystore`, so each new GitHub build installs **over** the last
  one and keeps your imported models. Don't uninstall between updates (uninstalling deletes the models). An APK built
  locally has a different key and cannot be installed over a GitHub one.

## What is implemented in this build (code complete, not yet run on a device)

- First-run setup, home, active conversation, code panel, settings (7 sub-screens), About, connectivity consent.
- Tap-to-talk using Android's **on-device** speech recognizer (Android 13+ and an installed on-device engine required).
- Offline-only text-to-speech (installed English voices that do not need the network; never silently falls back to a network voice).
- Turn-taking: listen → think → speak → **wait for you** (never auto-continues). Interrupt, mute, pause/resume speech.
- User-defined wake phrase + aliases (any language) with save/edit/delete/test, and custom command phrases with
  add/edit/delete/enable/test, duplicate/conflict detection, confidence floor and cooldown.
  *Always-on wake detection is not implemented* — tap to talk is the way to start.
- Connectivity consent: asks aloud, requires a clear spoken "yes", then only opens Android's own Wi-Fi / internet panel,
  and verifies the real network state afterwards. Whisperer never toggles Wi-Fi or mobile data itself.
- Optional background voice session as a microphone foreground service with a persistent notification (Talk / Stop).
- Local conversation history (app-private file) with clear/disable controls.
- Honest model/ASR/TTS status screens; code panel with copy (code is displayed, never run).

## Build status

**Not compiled and not run by the author.** See the note at the top. Never assume an APK exists until the workflow succeeds.

## What is not in this build

Always-on wake detection, internet research, model download inside the app, voice packs of the Matcha / raw-Piper kind.
No file manager, storage permission, app launching, reminders, alarms, notes, calendar, messaging, terminal or code execution — by design.

## Versions and decisions

| Item | Value | Why |
|---|---|---|
| Android Gradle Plugin | 9.4.0 | Needs Gradle 9.6.0+; Gradle 9.6 removed an internal API that AGP 8.x depends on |
| Gradle | 9.6.1 | Required by AGP 9.4 (minimum 9.6.0) |
| Kotlin | Built into AGP 9 (+ Compose compiler plugin 2.4.10) | `org.jetbrains.kotlin.android` is no longer applied |
| JDK | 17 | Required by AGP 9.x |
| compileSdk / targetSdk | 36 | Google Play requires new apps/updates to target API 36 (since 2026-08-31) |
| minSdk | 29 | `Settings.Panel` connectivity panels need API 29 |
| Compose BOM | 2025.06.01 | Material 3 |

Android version of the test phone is **not assumed**. Features needing newer Android degrade with an honest message
(e.g. on-device speech recognition on Android 12 or older reports "unavailable").

## Build

Requirements: JDK 17, Android SDK (platform 36, build-tools 36.0.0).

```bash
./gradlew assembleDebug          # APK: app/build/outputs/apk/debug/app-debug.apk
./gradlew testDebugUnitTest      # unit tests
```

### Gradle wrapper JAR — important

`gradlew`, `gradlew.bat` and `gradle/wrapper/gradle-wrapper.properties` are included, but
`gradle/wrapper/gradle-wrapper.jar` is a binary that could not be generated in the environment where this
project was written. The GitHub workflow therefore **creates it automatically when it is missing**
(it installs Gradle 9.6.1 and runs `gradle wrapper`). To commit the real JAR yourself (recommended):

```bash
gradle wrapper --gradle-version 9.6.1     # needs any locally installed Gradle
git add gradle/wrapper/gradle-wrapper.jar
```
Android Studio can also do this: open the project, then *Gradle → Wrapper* will regenerate it.

## Upload to GitHub and build the APK

1. Create a new GitHub repository named `Whisperer`.
2. Unzip `Whisperer_Android_Project.zip`. Upload the **contents** of the inner `Whisperer/` folder so that
   `settings.gradle.kts` and `gradlew` sit at the repository root (not inside an extra folder).
   Make sure the hidden `.github/workflows/android-build.yml` is included.
3. Commit to the `main` branch.
4. Open the **Actions** tab → **Whisperer Android CI** → wait for the run to finish.
5. Open the successful run → **Artifacts** → download **`whisperer-debug-apk`** → unzip → install `app-debug.apk`
   (allow installs from your browser/file source if Android asks).
6. If it fails, open the failed step, copy the first Gradle/SDK error and send it back for a fix. Do not assume an APK exists.

The workflow has two jobs: **Build debug APK** (what you need) and **Unit tests** (independent; a failing test does not block the APK).
The debug APK is for testing only; a Play Store build needs a separate signing/release setup.

## Model setup

Model weights are **not** in the repo or APK (`*.gguf`, `*.bin` are git-ignored). Import them in the app.

- Recommended assistant: `Qwen2.5-Coder-3B-Instruct` Q6_K GGUF (about 2.5 GB). **License:** Qwen Research License
  (`qwen-research`), not Apache 2.0 — read its terms before using or distributing it.
- Whisper: `ggml-tiny.bin` (multilingual) or `ggml-tiny.en.bin` (English only) from the whisper.cpp model list.
- The model must fit in RAM next to the app: the 3B Q6_K file plus context needs roughly 3 GB. Replies are generated on
  4 CPU threads; **speed is unmeasured** — test on the phone before relying on it.
- Tuning: `-Pwhisperer.armArch=armv8.2-a+dotprod+i8mm` enables i8mm kernels if your CPU supports them (a wrong flag
  crashes with an illegal-instruction error). Pin other versions with the workflow's *Run workflow* inputs
  (`llama_ref`, `whisper_ref`, `sherpa_tag`). The JNI code targets the llama.cpp C API of late 2025; a much newer
  tag may need small changes in `llama/src/main/cpp/llama_jni.cpp`.

## Permissions

| Permission | Why |
|---|---|
| `RECORD_AUDIO` | Requested in context, only when you start voice interaction or a test |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MICROPHONE` | Optional background voice session (visible notification, Stop button) |
| `POST_NOTIFICATIONS` | Android 13+: the notification must be visible for a background session |
| `ACCESS_NETWORK_STATE` | Read-only connectivity status / verification |
| `MODIFY_AUDIO_SETTINGS` | Audio output selection |

**No** storage, media, contacts, location, accessibility, device-admin or overlay permissions.

## Privacy

Microphone audio is processed by Android's on-device recognizer only; it is never sent to an online service by Whisperer.
Conversation history stays in app-private storage (`allowBackup=false`) and can be disabled/cleared in Settings.
No analytics, no API keys, no secrets in the repo.

## Project layout

```
app/src/main/java/com/darksh3ep/whisperer/
  ui/        Compose screens (home, conversation, code, settings, consent, onboarding), theme, components
  session/   VoiceSessionController (turn-taking state machine)
  domain/    pure Kotlin: commands, phrase matching, consent state machine, code parsing
  ai/        provider interfaces: llm, speechrecognition, speechsynthesis, wake
  audio/     audio focus + routing        connectivity/  network state + Android panels
  data/      DataStore settings, local history        service/  foreground microphone service
app/src/test/  unit tests (domain, data, controller with fakes)
assets/branding/  canonical Whisper Wave logo (SVG)    docs/  status, architecture, device checklist, mockups
```

## Branding

`assets/branding/whisperer-logo.svg` is the canonical "Whisper Wave" mark (Concept 1). The adaptive launcher icon
(`ic_launcher_foreground.xml`, monochrome layer for themed icons, `#111A32` background) and the in-app logo
(`whisperer_logo.xml`) are vector conversions of the same path data. The "Whisperer" wordmark is live text, not part of the icon.
