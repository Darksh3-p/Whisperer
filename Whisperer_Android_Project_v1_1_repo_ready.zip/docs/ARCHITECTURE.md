# Architecture

```
ui (Compose)  ──►  ViewModels (SessionViewModel, StatusViewModel, SettingsViewModel, PhraseViewModel, ConsentViewModel)
                        │
                        ▼
              AppContainer (hand-wired singletons)
   ┌────────────┬───────────────┬───────────────┬──────────────┬───────────────┐
   session      ai (providers)  audio           connectivity   data
   Voice-       llm / asr /     AudioRoute-     Connectivity-  DataStore +
   Session-     tts / wake      Manager         Checker,       JSON history
   Controller                                   SystemPanels
        ▲
   domain (pure Kotlin): commands, phrase matching, consent state machine, code parsing
   service: VoiceSessionService (foreground, type=microphone, START_NOT_STICKY)
```

## Voice turn (VoiceSessionController)
`IDLE → LISTENING → (command? run it : THINKING) → SPEAKING → IDLE (wait)`.
The controller never starts listening on its own. Failures also return to `IDLE` with a notice.
`SessionUiState.micActive` is true only while the recognizer is capturing.

## Provider interfaces (where real AI plugs in)
- `AssistantEngine` (`ai/llm`) — implement with llama.cpp (JNI) and return `AssistantResult.Reply`. Until then `UnavailableAssistantEngine`
  returns `Unavailable(status)`. Set `InferenceRuntime.INTEGRATED = true` only together with a tested engine.
  Verify before integrating: exact GGUF, chat template (ChatML for Qwen2.5), tokenizer, memory (≈2.5 GB weights + KV cache on a 12 GB phone
  shared with ASR/TTS), thermals. **Do not quote performance numbers before measuring on the target device.**
- `SpeechRecognizerProvider` (`ai/speechrecognition`) — current: Android on-device. Whisper Tiny (e.g. whisper.cpp) can be added behind the same interface with VAD + chunking.
- `SpeechOutput` (`ai/speechsynthesis`) — current: Android TTS restricted to installed offline English voices.
- `WakePhraseDetector` (`ai/wake`) — currently `UnavailableWakePhraseDetector`.

## Wake phrase design (not implemented)
A user-defined arbitrary phrase cannot use a fixed-keyword SDK. Proposed pipeline, to be benchmarked for battery before any claim:
1. low-power VAD gate on a user-started foreground session;
2. lightweight phrase recognition / enrolled-phrase model (not continuous Whisper Tiny);
3. similarity threshold + cooldown (`WakePhraseMatcher`, `CommandMatcher` already provide the matching + safeguards);
4. tap-to-talk fallback (exists).

## Consent flow
`ConsentReducer` (pure) → states `AwaitingApproval → Approved → AwaitingSystemPanel → Verified` or `Declined`.
`ConsentViewModel` speaks the question (offline TTS), listens once per attempt, and only opens `Settings.Panel`
(Wi-Fi / internet connectivity) after a clear spoken yes; after returning it reads `ConnectivityManager` and reports the real state.

## Background microphone rules followed
Foreground service type `microphone`, permissions `FOREGROUND_SERVICE_MICROPHONE` + `RECORD_AUDIO`, started only from the visible app,
persistent notification with Stop, not sticky, ended on task removal. No promise is made across force-stop, reboot, battery saver, OEM task killers or permission revocation.
