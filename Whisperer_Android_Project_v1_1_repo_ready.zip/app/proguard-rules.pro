# Release minification is disabled for this first release; no custom rules are required.
