package com.darksh3ep.whisperer.ai.speechsynthesis

import kotlinx.coroutines.flow.StateFlow

enum class TtsState {
    INITIALIZING,
    /** At least one installed English voice that does not need the network was found. */
    OFFLINE_AVAILABLE,
    /** The engine works, but no installed offline English voice exists. Whisperer will NOT use a network voice. */
    NO_OFFLINE_VOICE,
    ENGINE_UNAVAILABLE,
}

data class TtsCapability(
    val state: TtsState = TtsState.INITIALIZING,
    val offlineVoiceCount: Int = 0,
)

data class VoiceOption(val name: String, val label: String)

enum class SpeechError { NO_VOICE, ENGINE_ERROR }

interface SpeechListener {
    fun onDone()
    fun onError(error: SpeechError)
}

/**
 * Provider interface for speech output. The Android implementation only ever uses voices that are
 * installed locally and do not require the network; it never silently falls back to a network voice.
 * All methods must be called from the main thread.
 */
interface SpeechOutput {
    val capability: StateFlow<TtsCapability>
    fun voices(): List<VoiceOption>
    fun applySettings(rate: Float, voiceName: String?)
    fun refreshCapability()
    fun speak(text: String, listener: SpeechListener)
    fun stop()
    /** Pause at the current sentence. Returns false when nothing is being spoken. */
    fun pause(): Boolean
    fun resume()
    fun shutdown()
}
