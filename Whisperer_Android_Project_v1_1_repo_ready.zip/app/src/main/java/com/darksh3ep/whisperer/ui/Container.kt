package com.darksh3ep.whisperer.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.darksh3ep.whisperer.AppContainer
import com.darksh3ep.whisperer.WhispererApp

@Composable
fun rememberContainer(): AppContainer =
    (LocalContext.current.applicationContext as WhispererApp).container

/** Creates a ViewModel that needs the app's [AppContainer]. */
@Composable
inline fun <reified VM : ViewModel> containerViewModel(crossinline create: (AppContainer) -> VM): VM {
    val container = rememberContainer()
    return viewModel(factory = viewModelFactory { initializer { create(container) } })
}
