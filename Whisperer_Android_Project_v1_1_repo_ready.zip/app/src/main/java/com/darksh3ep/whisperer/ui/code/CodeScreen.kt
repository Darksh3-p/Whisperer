package com.darksh3ep.whisperer.ui.code

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ui.SessionViewModel
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.NoticeCard
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.Tone
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.theme.CodeBackground
import com.darksh3ep.whisperer.ui.theme.CodeFont
import com.darksh3ep.whisperer.ui.theme.Lavender
import com.darksh3ep.whisperer.ui.theme.TextPrimary
import com.darksh3ep.whisperer.ui.theme.TextSecondary
import com.darksh3ep.whisperer.ui.theme.TextTertiary
import kotlinx.coroutines.delay

/** Compact code panel. Whisperer displays code but never runs it: no editor, terminal or project browser. */
@Composable
fun CodeScreen(onReturn: () -> Unit) {
    val session: SessionViewModel = containerViewModel { SessionViewModel(it) }
    val state by session.state.collectAsStateWithLifecycle()
    val snippet = state.codeSnippet
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }

    // A sample preview (opened from Settings > AI model) must not linger once the panel is closed.
    DisposableEffect(Unit) {
        onDispose {
            if (!session.state.value.sessionActive) session.showCode(null)
        }
    }

    LaunchedEffect(copied) {
        if (copied) {
            delay(2_000)
            copied = false
        }
    }

    ScreenScaffold(
        title = stringResource(R.string.code_panel_title),
        onBack = onReturn,
    ) {
        if (snippet == null) {
            Text(
                text = stringResource(R.string.code_empty),
                style = MaterialTheme.typography.bodyLarge,
                color = TextSecondary,
            )
        } else {
            Text(
                text = snippet.language?.uppercase() ?: stringResource(R.string.code_language_unknown),
                style = MaterialTheme.typography.titleMedium,
                color = Lavender,
            )
            NoticeCard(text = stringResource(R.string.code_safety_note), tone = Tone.WARNING)

            val lineCount = snippet.code.lines().size
            val numbers = (1..lineCount).joinToString("\n")
            val highlighted = remember(snippet) { SyntaxHighlighter.highlight(snippet.code, snippet.language) }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(CodeBackground)
                    .horizontalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(text = numbers, style = CodeFont, color = TextTertiary, softWrap = false)
                Text(text = highlighted, style = CodeFont, color = TextPrimary, softWrap = false)
            }

            AppButton(
                text = stringResource(if (copied) R.string.code_copied else R.string.code_copy),
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("code", snippet.code))
                    copied = true
                },
                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
            )
        }
        AppButton(
            text = stringResource(R.string.code_return),
            onClick = onReturn,
            kind = ButtonKind.SECONDARY,
        )
        Spacer(Modifier.height(8.dp))
    }
}
