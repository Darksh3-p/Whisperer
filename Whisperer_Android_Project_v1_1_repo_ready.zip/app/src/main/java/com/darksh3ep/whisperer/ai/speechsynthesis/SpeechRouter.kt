package com.darksh3ep.whisperer.ai.speechsynthesis

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

/**
 * Chooses between Android's installed offline voices and imported voice packs.
 * Voice names starting with "pack:" select a voice pack; "Automatic" prefers Android's voice and falls back
 * to a voice pack when Android has no offline voice. Never uses a network voice.
 */
class SpeechRouter(
    private val android: SpeechOutput,
    private val packs: PackSpeechOutput,
    scope: CoroutineScope,
) : SpeechOutput {

    private var voiceName: String? = null

    override val capability: StateFlow<TtsCapability> =
        combine(android.capability, packs.capability) { a, p -> merge(a, p) }
            .stateIn(scope, SharingStarted.Eagerly, merge(android.capability.value, packs.capability.value))

    private fun merge(a: TtsCapability, p: TtsCapability): TtsCapability {
        val androidOk = a.state == TtsState.OFFLINE_AVAILABLE
        val packOk = p.state == TtsState.OFFLINE_AVAILABLE
        return when {
            androidOk || packOk -> TtsCapability(
                TtsState.OFFLINE_AVAILABLE,
                (if (androidOk) a.offlineVoiceCount else 0) + (if (packOk) p.offlineVoiceCount else 0),
            )
            a.state == TtsState.INITIALIZING -> a
            else -> a
        }
    }

    private fun choose(): SpeechOutput {
        val androidOk = android.capability.value.state == TtsState.OFFLINE_AVAILABLE
        val packOk = packs.capability.value.state == TtsState.OFFLINE_AVAILABLE
        return when {
            packOk && packs.hasVoice(voiceName) -> packs
            androidOk -> android
            packOk -> packs
            else -> android
        }
    }

    override fun voices(): List<VoiceOption> = packs.voices() + android.voices()

    override fun applySettings(rate: Float, voiceName: String?) {
        this.voiceName = voiceName
        android.applySettings(rate, voiceName?.takeUnless { it.startsWith(PACK_VOICE_PREFIX) })
        packs.applySettings(rate, voiceName)
    }

    override fun refreshCapability() {
        android.refreshCapability()
        packs.refreshCapability()
    }

    override fun speak(text: String, listener: SpeechListener) {
        val target = choose()
        if (target === packs) android.stop() else packs.stop()
        target.speak(text, listener)
    }

    override fun stop() {
        android.stop()
        packs.stop()
    }

    override fun pause(): Boolean = android.pause() || packs.pause()

    override fun resume() {
        android.resume()
        packs.resume()
    }

    override fun shutdown() {
        android.shutdown()
        packs.shutdown()
    }
}
