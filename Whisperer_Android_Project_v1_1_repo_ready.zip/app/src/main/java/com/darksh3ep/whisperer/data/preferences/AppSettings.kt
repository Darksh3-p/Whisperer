package com.darksh3ep.whisperer.data.preferences

import com.darksh3ep.whisperer.domain.commands.DefaultCommands
import com.darksh3ep.whisperer.domain.commands.VoiceCommand
import com.darksh3ep.whisperer.domain.commands.WakePhraseConfig

data class AppSettings(
    val onboardingComplete: Boolean = false,
    /** Off by default. When on, a user-started session runs as a foreground service with a notification. */
    val backgroundSessionEnabled: Boolean = false,
    /** Conversation history is stored locally by default and can be switched off and cleared. */
    val historyEnabled: Boolean = true,
    val hapticsEnabled: Boolean = false,
    val speechRate: Float = 1.0f,
    val voiceName: String? = null,
    val wake: WakePhraseConfig = WakePhraseConfig(),
    val commands: List<VoiceCommand> = DefaultCommands.all(),
)
