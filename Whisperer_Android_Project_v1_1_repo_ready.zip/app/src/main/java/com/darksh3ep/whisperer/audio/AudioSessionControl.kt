package com.darksh3ep.whisperer.audio

import com.darksh3ep.whisperer.domain.audio.AudioOutputOption
import com.darksh3ep.whisperer.domain.audio.AudioRoute
import kotlinx.coroutines.flow.StateFlow

/** Audio focus and routing needed by a voice session. Implemented on Android by [AudioRouteManager]. */
interface AudioSessionControl {
    val route: StateFlow<AudioRoute>
    /** Request transient audio focus for the session. [onLost] is called when another app/call takes it. */
    fun requestFocus(onLost: () -> Unit): Boolean
    fun abandonFocus()
    /** Selectable outputs (Android 12+). Empty when the OS offers no choice. */
    fun selectableOutputs(): List<AudioOutputOption>
    /** Select an output, or pass null to return to the system default. Best effort. */
    fun selectOutput(id: Int?): Boolean
}
