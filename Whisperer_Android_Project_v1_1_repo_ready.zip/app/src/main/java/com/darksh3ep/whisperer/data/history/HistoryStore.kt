package com.darksh3ep.whisperer.data.history

import com.darksh3ep.whisperer.domain.conversation.ChatMessage
import com.darksh3ep.whisperer.domain.conversation.Notice
import com.darksh3ep.whisperer.domain.conversation.Speaker
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File

data class ConversationRecord(
    val id: String,
    val startedAtMillis: Long,
    val messages: List<ChatMessage>,
)

/** Local-only conversation history. Never uploaded; can be cleared by the user. */
interface HistoryStore {
    /** Newest first. */
    suspend fun load(): List<ConversationRecord>
    suspend fun append(record: ConversationRecord)
    suspend fun clear()
}

/** Stores history as one JSON file in app-private storage. */
class FileHistoryStore(
    private val file: File,
    private val maxRecords: Int = 50,
    private val io: CoroutineDispatcher = Dispatchers.IO,
) : HistoryStore {
    private val lock = Mutex()

    override suspend fun load(): List<ConversationRecord> = lock.withLock {
        withContext(io) { readAll().sortedByDescending { it.startedAtMillis } }
    }

    override suspend fun append(record: ConversationRecord) {
        lock.withLock {
            withContext(io) {
                val all = readAll().toMutableList()
                all.add(record)
                val trimmed = all.sortedBy { it.startedAtMillis }.takeLast(maxRecords)
                writeAll(trimmed)
            }
        }
    }

    override suspend fun clear() {
        lock.withLock {
            withContext(io) {
                if (file.exists()) file.delete()
            }
        }
    }

    private fun readAll(): List<ConversationRecord> {
        if (!file.exists()) return emptyList()
        return try {
            val root = JSONObject(file.readText())
            val records = root.getJSONArray("records")
            val out = ArrayList<ConversationRecord>()
            for (i in 0 until records.length()) {
                val item = records.getJSONObject(i)
                val messages = ArrayList<ChatMessage>()
                val array = item.getJSONArray("messages")
                for (m in 0 until array.length()) {
                    val message = array.getJSONObject(m)
                    val speaker = try {
                        Speaker.valueOf(message.getString("speaker"))
                    } catch (e: IllegalArgumentException) {
                        continue
                    }
                    messages.add(
                        ChatMessage(
                            id = message.getLong("id"),
                            speaker = speaker,
                            text = message.getString("text"),
                            timeMillis = message.getLong("time"),
                            notice = Notice.NONE,
                        )
                    )
                }
                out.add(ConversationRecord(item.getString("id"), item.getLong("startedAt"), messages))
            }
            out
        } catch (e: JSONException) {
            emptyList()
        } catch (e: java.io.IOException) {
            emptyList()
        }
    }

    private fun writeAll(records: List<ConversationRecord>) {
        val array = JSONArray()
        for (record in records) {
            val messages = JSONArray()
            for (message in record.messages) {
                val m = JSONObject()
                m.put("id", message.id)
                m.put("speaker", message.speaker.name)
                m.put("text", message.text)
                m.put("time", message.timeMillis)
                messages.put(m)
            }
            val item = JSONObject()
            item.put("id", record.id)
            item.put("startedAt", record.startedAtMillis)
            item.put("messages", messages)
            array.put(item)
        }
        val root = JSONObject()
        root.put("records", array)
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        temp.writeText(root.toString())
        if (!temp.renameTo(file)) {
            file.writeText(root.toString())
            temp.delete()
        }
    }
}
