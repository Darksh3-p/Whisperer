package com.darksh3ep.whisperer.domain.audio

/** Where audio output is currently going, as far as Android reports it. */
enum class AudioRoute(val isExternal: Boolean) {
    PHONE_SPEAKER(false),
    WIRED_HEADSET(true),
    USB_AUDIO(true),
    BLUETOOTH(true),
    UNKNOWN(false),
}

/** One selectable audio output (Android 12+ communication devices). */
data class AudioOutputOption(
    val id: Int,
    val route: AudioRoute,
    val name: String,
)
