package com.darksh3ep.whisperer.ui.settings

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.domain.commands.CommandAction
import com.darksh3ep.whisperer.domain.commands.PhraseCheck
import com.darksh3ep.whisperer.domain.commands.VoiceCommand
import com.darksh3ep.whisperer.ui.PhraseViewModel
import com.darksh3ep.whisperer.ui.actionLabel
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.MicPermissionHost
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.SwitchRow
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.theme.Coral
import com.darksh3ep.whisperer.ui.theme.Lavender
import com.darksh3ep.whisperer.ui.theme.TextPrimary

private data class EditTarget(val command: VoiceCommand?)

@Composable
fun CommandsScreen(onBack: () -> Unit) {
    val vm: PhraseViewModel = containerViewModel { PhraseViewModel(it) }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val testResult by vm.testResult.collectAsStateWithLifecycle()

    var editTarget by remember { mutableStateOf<EditTarget?>(null) }
    var deleteTarget by remember { mutableStateOf<VoiceCommand?>(null) }
    var confirmRestore by remember { mutableStateOf(false) }
    var testingId by remember { mutableStateOf<String?>(null) }

    ScreenScaffold(title = stringResource(R.string.settings_commands_title), onBack = onBack) {
        BodyText(stringResource(R.string.settings_commands_desc))
        BodyText(stringResource(R.string.commands_supporting))

        AppButton(
            text = stringResource(R.string.commands_add),
            onClick = { editTarget = EditTarget(null) },
        )

        val commands = settings?.commands.orEmpty()
        commands.forEach { command ->
            SectionCard(title = stringResource(actionLabel(command.action))) {
                Text(
                    text = command.phrases.joinToString(" \u00B7 ") { "\u201C$it\u201D" },
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary,
                )
                SwitchRow(
                    title = stringResource(R.string.commands_enabled),
                    subtitle = null,
                    checked = command.enabled,
                    onCheckedChange = { vm.setCommandEnabled(command.id, it) },
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    TextButton(
                        onClick = { editTarget = EditTarget(command) },
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) { Text(stringResource(R.string.action_edit), color = Lavender) }

                    MicPermissionHost(onGranted = { testingId?.let { id -> commands.firstOrNull { it.id == id }?.let(vm::testCommand) } }) { requestMic ->
                        TextButton(
                            onClick = {
                                testingId = command.id
                                requestMic()
                            },
                            modifier = Modifier.heightIn(min = 48.dp),
                        ) { Text(stringResource(R.string.commands_test), color = Lavender) }
                    }

                    TextButton(
                        onClick = { deleteTarget = command },
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) { Text(stringResource(R.string.action_delete), color = Coral) }
                }
                if (testingId == command.id) {
                    PhraseTestResultCard(testResult)
                }
            }
        }

        AppButton(
            text = stringResource(R.string.commands_restore),
            onClick = { confirmRestore = true },
            kind = ButtonKind.SECONDARY,
        )
    }

    val target = editTarget
    if (target != null) {
        CommandEditDialog(
            existing = target.command,
            onDismiss = { editTarget = null },
            onSave = { action, lines -> vm.saveCommand(target.command, action, lines) },
        )
    }

    val toDelete = deleteTarget
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(stringResource(R.string.commands_delete_title)) },
            text = { Text(stringResource(R.string.commands_delete_body)) },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteCommand(toDelete.id)
                    deleteTarget = null
                }) { Text(stringResource(R.string.action_delete), color = Coral) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text(stringResource(R.string.action_cancel)) }
            },
        )
    }

    if (confirmRestore) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            title = { Text(stringResource(R.string.commands_restore_title)) },
            text = { Text(stringResource(R.string.commands_restore_body)) },
            confirmButton = {
                TextButton(onClick = {
                    vm.restoreDefaultCommands()
                    confirmRestore = false
                }) { Text(stringResource(R.string.commands_restore)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmRestore = false }) { Text(stringResource(R.string.action_cancel)) }
            },
        )
    }
}

@Composable
private fun CommandEditDialog(
    existing: VoiceCommand?,
    onDismiss: () -> Unit,
    onSave: (CommandAction, String) -> PhraseCheck,
) {
    var action by remember { mutableStateOf(existing?.action ?: CommandAction.STOP) }
    var phrases by remember { mutableStateOf(existing?.phrases?.joinToString("\n").orEmpty()) }
    var check by remember { mutableStateOf<PhraseCheck?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(stringResource(if (existing == null) R.string.commands_add else R.string.commands_edit_title))
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (existing == null) {
                    Text(stringResource(R.string.commands_choose_action), color = Lavender)
                    CommandAction.entries.forEach { option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .selectable(selected = action == option, role = Role.RadioButton) { action = option },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = action == option, onClick = null)
                            Spacer(Modifier.width(12.dp))
                            Text(stringResource(actionLabel(option)), color = TextPrimary)
                        }
                    }
                } else {
                    Text(stringResource(actionLabel(existing.action)), color = Lavender)
                }
                OutlinedTextField(
                    value = phrases,
                    onValueChange = { phrases = it },
                    label = { Text(stringResource(R.string.commands_phrases_label)) },
                    supportingText = { Text(stringResource(R.string.commands_phrases_hint)) },
                    minLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                )
                val message = phraseCheckMessage(check)
                if (message != null) Text(message, color = Coral)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val result = onSave(action, phrases)
                if (result == PhraseCheck.Ok) onDismiss() else check = result
            }) { Text(stringResource(R.string.action_save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}
