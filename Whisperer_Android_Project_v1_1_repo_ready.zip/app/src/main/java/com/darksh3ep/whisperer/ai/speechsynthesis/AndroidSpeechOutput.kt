package com.darksh3ep.whisperer.ai.speechsynthesis

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.darksh3ep.whisperer.domain.conversation.SentenceSplitter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/** Text-to-speech through Android's TextToSpeech, restricted to installed, offline English voices. */
class AndroidSpeechOutput(context: Context) : SpeechOutput {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    private var engine: TextToSpeech? = null
    private var offlineVoices: List<Voice> = emptyList()
    private var rate = 1.0f
    private var preferredVoice: String? = null

    private var chunks: List<String> = emptyList()
    private var chunkIndex = 0
    private var sequence = 0
    private var listener: SpeechListener? = null
    private var speaking = false
    private var paused = false

    private val _capability = MutableStateFlow(TtsCapability())
    override val capability: StateFlow<TtsCapability> = _capability.asStateFlow()

    init {
        createEngine()
    }

    private fun createEngine() {
        _capability.value = TtsCapability(TtsState.INITIALIZING, 0)
        engine = TextToSpeech(appContext) { status -> main.post { onEngineInit(status) } }
    }

    private fun onEngineInit(status: Int) {
        val tts = engine
        if (status != TextToSpeech.SUCCESS || tts == null) {
            _capability.value = TtsCapability(TtsState.ENGINE_UNAVAILABLE, 0)
            return
        }
        tts.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        tts.setOnUtteranceProgressListener(progressListener)
        refreshCapability()
    }

    override fun refreshCapability() {
        val tts = engine ?: return
        if (_capability.value.state == TtsState.ENGINE_UNAVAILABLE) return
        val all: Set<Voice> = try {
            tts.voices ?: emptySet()
        } catch (e: Exception) {
            emptySet()
        }
        offlineVoices = all
            .filter { isInstalledOfflineEnglish(it) }
            .sortedBy { it.name }
        _capability.value = TtsCapability(
            state = if (offlineVoices.isEmpty()) TtsState.NO_OFFLINE_VOICE else TtsState.OFFLINE_AVAILABLE,
            offlineVoiceCount = offlineVoices.size,
        )
        applyVoiceAndRate()
    }

    private fun isInstalledOfflineEnglish(voice: Voice): Boolean {
        if (voice.isNetworkConnectionRequired) return false
        if (voice.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true) return false
        return voice.locale.language == Locale.ENGLISH.language
    }

    override fun voices(): List<VoiceOption> =
        offlineVoices.map { VoiceOption(it.name, it.locale.displayName + " \u00B7 " + it.name) }

    override fun applySettings(rate: Float, voiceName: String?) {
        this.rate = rate
        this.preferredVoice = voiceName
        applyVoiceAndRate()
    }

    private fun applyVoiceAndRate() {
        val tts = engine ?: return
        tts.setSpeechRate(rate)
        if (offlineVoices.isEmpty()) return
        val deviceLocale = Locale.getDefault()
        val chosen = offlineVoices.firstOrNull { it.name == preferredVoice }
            ?: offlineVoices.firstOrNull { it.locale == deviceLocale }
            ?: offlineVoices.firstOrNull { it.locale == Locale.US }
            ?: offlineVoices.first()
        tts.setVoice(chosen)
    }

    override fun speak(text: String, listener: SpeechListener) {
        val tts = engine
        if (tts == null || _capability.value.state != TtsState.OFFLINE_AVAILABLE) {
            main.post { listener.onError(SpeechError.NO_VOICE) }
            return
        }
        stopInternal()
        val parts = SentenceSplitter.split(text)
        if (parts.isEmpty()) {
            main.post { listener.onDone() }
            return
        }
        chunks = parts
        chunkIndex = 0
        this.listener = listener
        speaking = true
        paused = false
        enqueueFrom(0)
    }

    private fun enqueueFrom(start: Int) {
        val tts = engine ?: return
        for (index in start until chunks.size) {
            val mode = if (index == start) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val result = tts.speak(chunks[index], mode, null, utteranceId(sequence, index))
            if (result == TextToSpeech.ERROR) {
                fail(SpeechError.ENGINE_ERROR)
                return
            }
        }
    }

    override fun stop() {
        stopInternal()
        listener = null
    }

    private fun stopInternal() {
        sequence += 1
        speaking = false
        paused = false
        chunks = emptyList()
        try {
            engine?.stop()
        } catch (e: Exception) {
            // Ignore: engine already stopped.
        }
    }

    override fun pause(): Boolean {
        if (!speaking || paused) return false
        paused = true
        sequence += 1
        try {
            engine?.stop()
        } catch (e: Exception) {
            // Ignore.
        }
        return true
    }

    override fun resume() {
        if (!paused) return
        paused = false
        speaking = true
        sequence += 1
        enqueueFrom(chunkIndex)
    }

    override fun shutdown() {
        stopInternal()
        listener = null
        try {
            engine?.shutdown()
        } catch (e: Exception) {
            // Ignore.
        }
        engine = null
    }

    private fun finishDone() {
        val target = listener
        listener = null
        speaking = false
        paused = false
        target?.onDone()
    }

    private fun fail(error: SpeechError) {
        val target = listener
        listener = null
        speaking = false
        paused = false
        sequence += 1
        try {
            engine?.stop()
        } catch (e: Exception) {
            // Ignore.
        }
        target?.onError(error)
    }

    private fun utteranceId(seq: Int, index: Int) = "w-$seq-$index"

    private fun parseId(id: String?): Pair<Int, Int>? {
        val parts = id?.split('-') ?: return null
        if (parts.size != 3) return null
        val seq = parts[1].toIntOrNull() ?: return null
        val index = parts[2].toIntOrNull() ?: return null
        return seq to index
    }

    private val progressListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            val parsed = parseId(utteranceId) ?: return
            main.post { if (parsed.first == sequence) chunkIndex = parsed.second }
        }

        override fun onDone(utteranceId: String?) {
            val parsed = parseId(utteranceId) ?: return
            main.post {
                if (parsed.first == sequence && parsed.second == chunks.size - 1 && !paused) finishDone()
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            val parsed = parseId(utteranceId) ?: return
            main.post { if (parsed.first == sequence) fail(SpeechError.ENGINE_ERROR) }
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            val parsed = parseId(utteranceId) ?: return
            main.post { if (parsed.first == sequence) fail(SpeechError.ENGINE_ERROR) }
        }
    }
}
