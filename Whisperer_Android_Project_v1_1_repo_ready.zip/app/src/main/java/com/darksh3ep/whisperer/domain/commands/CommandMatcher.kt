package com.darksh3ep.whisperer.domain.commands

sealed interface MatchOutcome {
    data object NoMatch : MatchOutcome

    data class Matched(
        val command: VoiceCommand,
        val phrase: String,
        val score: Double,
    ) : MatchOutcome

    /** A candidate was found but deliberately not acted on (false-trigger safeguard). */
    data class Suppressed(
        val command: VoiceCommand,
        val reason: SuppressReason,
    ) : MatchOutcome

    /** Two different commands matched about equally well; nothing is run. */
    data class Ambiguous(val actions: List<CommandAction>) : MatchOutcome
}

enum class SuppressReason { COOLDOWN, LOW_ASR_CONFIDENCE }

/**
 * Deterministic matcher for simple session commands (no LLM involved).
 *
 * Safeguards:
 *  - the WHOLE utterance must be close to a phrase (so "stop the loop at index three" does not trigger "stop");
 *  - a similarity [threshold];
 *  - optional recognizer confidence floor;
 *  - per-action [cooldownMillis];
 *  - ambiguity between different actions runs nothing.
 */
class CommandMatcher(
    val threshold: Double = 0.85,
    val cooldownMillis: Long = 1500L,
    val minAsrConfidence: Float = 0.35f,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private val lastFired = HashMap<CommandAction, Long>()

    /** Classify without recording a firing and without cooldown (used by the Test command screens). */
    fun classify(utterance: String, commands: List<VoiceCommand>): MatchOutcome {
        val normalized = PhraseText.normalize(utterance)
        if (normalized.isEmpty()) return MatchOutcome.NoMatch

        val candidates = ArrayList<MatchOutcome.Matched>()
        for (command in commands) {
            if (!command.enabled) continue
            var best: MatchOutcome.Matched? = null
            for (phrase in command.phrases) {
                if (PhraseText.normalize(phrase).isEmpty()) continue
                val score = PhraseText.similarity(normalized, phrase)
                if (score >= threshold && (best == null || score > best.score)) {
                    best = MatchOutcome.Matched(command, phrase, score)
                }
            }
            if (best != null) candidates.add(best)
        }
        if (candidates.isEmpty()) return MatchOutcome.NoMatch

        val top = candidates.maxByOrNull { it.score } ?: return MatchOutcome.NoMatch
        val rivals = candidates.filter {
            it.command.action != top.command.action && it.score >= top.score - AMBIGUITY_MARGIN
        }
        if (rivals.isNotEmpty()) {
            val actions = (listOf(top) + rivals).map { it.command.action }.distinct()
            return MatchOutcome.Ambiguous(actions)
        }
        return top
    }

    /** Classify for real use: applies the confidence floor and cooldown, and records a firing. */
    fun match(
        utterance: String,
        commands: List<VoiceCommand>,
        asrConfidence: Float? = null,
    ): MatchOutcome {
        val outcome = classify(utterance, commands)
        if (outcome !is MatchOutcome.Matched) return outcome

        if (asrConfidence != null && asrConfidence < minAsrConfidence) {
            return MatchOutcome.Suppressed(outcome.command, SuppressReason.LOW_ASR_CONFIDENCE)
        }
        val now = clock()
        val last = lastFired[outcome.command.action]
        if (last != null && now - last < cooldownMillis) {
            return MatchOutcome.Suppressed(outcome.command, SuppressReason.COOLDOWN)
        }
        lastFired[outcome.command.action] = now
        return outcome
    }

    private companion object {
        const val AMBIGUITY_MARGIN = 0.02
    }
}

/** Checks a transcript against the user's wake phrase and aliases (used by "Test wake phrase"). */
object WakePhraseMatcher {
    data class WakeMatch(val phrase: String, val score: Double)

    fun match(transcript: String, config: WakePhraseConfig, threshold: Double = 0.8): WakeMatch? {
        var best: WakeMatch? = null
        for (phrase in config.allPhrases) {
            val score = PhraseText.similarity(transcript, phrase)
            if (score >= threshold && (best == null || score > best.score)) {
                best = WakeMatch(phrase, score)
            }
        }
        return best
    }
}
