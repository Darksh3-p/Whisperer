package com.darksh3ep.whisperer.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ai.speechrecognition.RecognitionFailure
import com.darksh3ep.whisperer.domain.commands.PhraseCheck
import com.darksh3ep.whisperer.domain.commands.PhraseOwner
import com.darksh3ep.whisperer.ui.PhraseTestResult
import com.darksh3ep.whisperer.ui.actionLabel
import com.darksh3ep.whisperer.ui.components.NoticeCard
import com.darksh3ep.whisperer.ui.components.Tone

/** Human-readable validation message, or null when the phrases are fine. */
@Composable
fun phraseCheckMessage(check: PhraseCheck?): String? = when (check) {
    null, PhraseCheck.Ok -> null
    PhraseCheck.Empty -> stringResource(R.string.phrase_error_empty)
    PhraseCheck.TooShort -> stringResource(R.string.phrase_error_too_short)
    PhraseCheck.RepeatedInList -> stringResource(R.string.phrase_error_repeated)
    is PhraseCheck.Conflict -> {
        val ownerName = when (val owner = check.owner) {
            PhraseOwner.Wake -> stringResource(R.string.phrase_owner_wake)
            is PhraseOwner.Command -> stringResource(actionLabel(owner.action))
        }
        stringResource(R.string.phrase_error_conflict, check.existingPhrase, ownerName)
    }
}

/** Shows the outcome of a "Test wake phrase" / "Test command" run. */
@Composable
fun PhraseTestResultCard(result: PhraseTestResult?) {
    if (result == null) return
    val (text, tone) = when (result) {
        PhraseTestResult.Listening -> stringResource(R.string.test_listening) to Tone.OK
        PhraseTestResult.Unavailable -> stringResource(R.string.asr_status_unavailable) to Tone.WARNING
        PhraseTestResult.SessionBusy -> stringResource(R.string.test_session_busy) to Tone.WARNING
        is PhraseTestResult.Failed -> when (result.reason) {
            RecognitionFailure.PERMISSION -> stringResource(R.string.status_mic_permission_needed) to Tone.WARNING
            else -> stringResource(R.string.error_recognition_failure) to Tone.ERROR
        }
        is PhraseTestResult.WakeMatched -> stringResource(
            R.string.wake_test_match, result.heard, result.phrase, (result.score * 100).toInt()
        ) to Tone.OK
        is PhraseTestResult.WakeNoMatch -> stringResource(R.string.wake_test_no_match, result.heard) to Tone.WARNING
        is PhraseTestResult.CommandMatchedThis -> stringResource(
            R.string.cmd_test_match_this, result.heard, (result.score * 100).toInt()
        ) to Tone.OK
        is PhraseTestResult.CommandMatchedOther -> stringResource(
            R.string.cmd_test_match_other, result.heard, stringResource(actionLabel(result.action))
        ) to Tone.WARNING
        is PhraseTestResult.CommandNoMatch -> stringResource(R.string.cmd_test_no_match, result.heard) to Tone.WARNING
    }
    Column(
        modifier = Modifier
            .padding(top = 4.dp)
            .semantics { liveRegion = LiveRegionMode.Polite },
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        NoticeCard(text = text, tone = tone)
    }
}

fun Modifier.fillMaxWidthCompat(): Modifier = this.then(Modifier.fillMaxWidth())
