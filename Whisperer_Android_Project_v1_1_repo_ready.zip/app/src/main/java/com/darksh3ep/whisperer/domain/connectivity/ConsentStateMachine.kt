package com.darksh3ep.whisperer.domain.connectivity

/** Which connection the request is about. Android only lets us guide the user to its own panels. */
enum class ConnectionKind { WIFI, MOBILE_DATA, ANY }

enum class DeclineReason { USER_DECLINED, NOT_UNDERSTOOD }

sealed interface ConsentState {
    data object Idle : ConsentState

    /** The question has been asked (aloud and on screen); waiting for a clear spoken answer. */
    data class AwaitingApproval(val kind: ConnectionKind, val unclearCount: Int = 0) : ConsentState

    /** A clear spoken "yes" was heard. Only now may the user continue to the Android panel. */
    data class Approved(val kind: ConnectionKind) : ConsentState

    data class Declined(val kind: ConnectionKind, val reason: DeclineReason) : ConsentState

    /** The Android system panel was opened; we are waiting for the user to come back. */
    data class AwaitingSystemPanel(val kind: ConnectionKind) : ConsentState

    /** Result of checking the actual network state after returning. */
    data class Verified(val kind: ConnectionKind, val connected: Boolean) : ConsentState
}

sealed interface ConsentEvent {
    data class Begin(val kind: ConnectionKind) : ConsentEvent
    data class Heard(val text: String) : ConsentEvent
    /** Silence, timeout or a recognition failure. Never counts as approval. */
    data object HeardNothing : ConsentEvent
    data object TappedNotNow : ConsentEvent
    data object TappedContinue : ConsentEvent
    data class ReturnedFromSettings(val connected: Boolean) : ConsentEvent
}

/**
 * Pure state machine for the connectivity consent flow.
 *
 * Rules (from the product requirements):
 *  - approval must be a clear spoken "yes";
 *  - silence or ambiguous speech is not approval, and after [MAX_UNCLEAR] unclear answers we stop asking;
 *  - a refusal ends the flow and does not re-prompt;
 *  - the Android panel can only be opened from [ConsentState.Approved];
 *  - success is only reported from a verified check of the real network state.
 */
object ConsentReducer {
    const val MAX_UNCLEAR = 2

    fun reduce(state: ConsentState, event: ConsentEvent): ConsentState = when (event) {
        is ConsentEvent.Begin -> ConsentState.AwaitingApproval(event.kind, 0)

        is ConsentEvent.Heard ->
            if (state is ConsentState.AwaitingApproval) {
                when (ApprovalParser.parse(event.text)) {
                    Approval.YES -> ConsentState.Approved(state.kind)
                    Approval.NO -> ConsentState.Declined(state.kind, DeclineReason.USER_DECLINED)
                    Approval.UNCLEAR -> unclear(state)
                }
            } else {
                state
            }

        ConsentEvent.HeardNothing ->
            if (state is ConsentState.AwaitingApproval) unclear(state) else state

        ConsentEvent.TappedNotNow -> when (state) {
            is ConsentState.AwaitingApproval -> ConsentState.Declined(state.kind, DeclineReason.USER_DECLINED)
            is ConsentState.Approved -> ConsentState.Declined(state.kind, DeclineReason.USER_DECLINED)
            else -> state
        }

        ConsentEvent.TappedContinue ->
            if (state is ConsentState.Approved) ConsentState.AwaitingSystemPanel(state.kind) else state

        is ConsentEvent.ReturnedFromSettings ->
            if (state is ConsentState.AwaitingSystemPanel) {
                ConsentState.Verified(state.kind, event.connected)
            } else {
                state
            }
    }

    private fun unclear(state: ConsentState.AwaitingApproval): ConsentState =
        if (state.unclearCount + 1 >= MAX_UNCLEAR) {
            ConsentState.Declined(state.kind, DeclineReason.NOT_UNDERSTOOD)
        } else {
            state.copy(unclearCount = state.unclearCount + 1)
        }
}
