package com.darksh3ep.whisperer.ui.settings

import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.domain.commands.PhraseCheck
import com.darksh3ep.whisperer.ui.PhraseViewModel
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.MicPermissionHost
import com.darksh3ep.whisperer.ui.components.NoticeCard
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.SwitchRow
import com.darksh3ep.whisperer.ui.components.Tone
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.theme.Coral

@Composable
fun WakePhraseScreen(onBack: () -> Unit) {
    val vm: PhraseViewModel = containerViewModel { PhraseViewModel(it) }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val testResult by vm.testResult.collectAsStateWithLifecycle()

    val wake = settings?.wake
    var phrase by remember(wake?.phrase) { mutableStateOf(wake?.phrase.orEmpty()) }
    var aliases by remember(wake?.aliases) { mutableStateOf(wake?.aliases?.joinToString("\n").orEmpty()) }
    var check by remember { mutableStateOf<PhraseCheck?>(null) }
    var savedFlag by remember { mutableStateOf(false) }

    ScreenScaffold(title = stringResource(R.string.settings_wake_title), onBack = onBack) {
        BodyText(stringResource(R.string.settings_wake_desc))
        // Honest status: nothing listens in the background in this build.
        NoticeCard(stringResource(R.string.wake_unavailable_note), Tone.WARNING)
        BodyText(stringResource(R.string.wake_supporting))

        SectionCard {
            SwitchRow(
                title = stringResource(R.string.wake_enable),
                subtitle = stringResource(R.string.wake_enable_hint),
                checked = wake?.enabled == true,
                onCheckedChange = { vm.setWakeEnabled(it) },
                enabled = wake?.phrase?.isNotBlank() == true,
            )
        }

        SectionCard(title = stringResource(R.string.wake_phrase_label)) {
            OutlinedTextField(
                value = phrase,
                onValueChange = {
                    phrase = it
                    savedFlag = false
                },
                label = { Text(stringResource(R.string.wake_phrase_label)) },
                singleLine = true,
                modifier = androidx.compose.ui.Modifier.fillMaxWidthCompat(),
            )
            OutlinedTextField(
                value = aliases,
                onValueChange = {
                    aliases = it
                    savedFlag = false
                },
                label = { Text(stringResource(R.string.wake_aliases_label)) },
                supportingText = { Text(stringResource(R.string.wake_aliases_hint)) },
                minLines = 2,
                modifier = androidx.compose.ui.Modifier.fillMaxWidthCompat(),
            )
            val message = phraseCheckMessage(check)
            if (message != null) {
                Text(message, color = Coral)
            }
            if (savedFlag) {
                BodyText(stringResource(R.string.wake_saved))
            }
            AppButton(
                text = stringResource(R.string.action_save),
                onClick = {
                    val result = vm.saveWake(phrase, aliases)
                    check = result
                    savedFlag = result == PhraseCheck.Ok
                },
            )
            AppButton(
                text = stringResource(R.string.wake_delete),
                onClick = {
                    vm.deleteWake()
                    phrase = ""
                    aliases = ""
                    check = null
                    savedFlag = false
                },
                kind = ButtonKind.DANGER,
                enabled = wake?.phrase?.isNotBlank() == true,
            )
        }

        SectionCard(title = stringResource(R.string.wake_test)) {
            BodyText(stringResource(R.string.wake_test_hint))
            MicPermissionHost(onGranted = { vm.testWake() }) { requestMic ->
                AppButton(
                    text = stringResource(R.string.wake_test),
                    onClick = requestMic,
                    kind = ButtonKind.SECONDARY,
                    enabled = wake?.phrase?.isNotBlank() == true,
                )
            }
            PhraseTestResultCard(testResult)
        }
    }
}
