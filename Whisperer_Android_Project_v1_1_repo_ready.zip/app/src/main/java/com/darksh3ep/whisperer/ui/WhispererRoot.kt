package com.darksh3ep.whisperer.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind
import com.darksh3ep.whisperer.ui.code.CodeScreen
import com.darksh3ep.whisperer.ui.consent.ConsentScreen
import com.darksh3ep.whisperer.ui.conversation.ConversationScreen
import com.darksh3ep.whisperer.ui.home.HomeScreen
import com.darksh3ep.whisperer.ui.onboarding.OnboardingScreen
import com.darksh3ep.whisperer.ui.settings.AboutScreen
import com.darksh3ep.whisperer.ui.settings.CommandsScreen
import com.darksh3ep.whisperer.ui.settings.HistoryScreen
import com.darksh3ep.whisperer.ui.settings.ModelScreen
import com.darksh3ep.whisperer.ui.settings.NetworkScreen
import com.darksh3ep.whisperer.ui.settings.PrivacyScreen
import com.darksh3ep.whisperer.ui.settings.SettingsDestinations
import com.darksh3ep.whisperer.ui.settings.SettingsScreen
import com.darksh3ep.whisperer.ui.settings.VoiceSettingsScreen
import com.darksh3ep.whisperer.ui.settings.WakePhraseScreen
import com.darksh3ep.whisperer.ui.theme.Midnight

object Routes {
    const val HOME = "home"
    const val CONVERSATION = "conversation"
    const val CODE = "code"
    const val SETTINGS = "settings"
    const val VOICE = "settings/voice"
    const val WAKE = "settings/wake"
    const val COMMANDS = "settings/commands"
    const val MODEL = "settings/model"
    const val PRIVACY = "settings/privacy"
    const val HISTORY = "settings/history"
    const val NETWORK = "settings/network"
    const val ABOUT = "settings/about"
    const val CONSENT = "consent/{kind}"

    fun consent(kind: ConnectionKind) = "consent/${kind.name}"
}

/**
 * Navigation is deliberately minimal: Assistant (home + conversation + code panel) and Settings.
 * There is no file manager, library, documents or import destination.
 */
@Composable
fun WhispererRoot() {
    val container = rememberContainer()
    val settings by container.settings.collectAsStateWithLifecycle()
    val loaded = settings

    Surface(modifier = Modifier.fillMaxSize(), color = Midnight) {
        when {
            loaded == null -> Box(Modifier.fillMaxSize())
            !loaded.onboardingComplete -> OnboardingScreen()
            else -> WhispererNavHost()
        }
    }
}

@Composable
private fun WhispererNavHost() {
    val nav = rememberNavController()

    // Guards make "leave" idempotent: the conversation can end from several places at once.
    fun leave(route: String) {
        if (nav.currentDestination?.route == route) nav.popBackStack()
    }

    NavHost(navController = nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenSettings = { nav.navigate(Routes.SETTINGS) },
                onOpenConversation = { nav.navigate(Routes.CONVERSATION) { launchSingleTop = true } },
            )
        }
        composable(Routes.CONVERSATION) {
            ConversationScreen(
                onLeave = { leave(Routes.CONVERSATION) },
                onOpenCode = { nav.navigate(Routes.CODE) { launchSingleTop = true } },
            )
        }
        composable(Routes.CODE) {
            CodeScreen(onReturn = { leave(Routes.CODE) })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                destinations = SettingsDestinations(
                    onVoice = { nav.navigate(Routes.VOICE) },
                    onWake = { nav.navigate(Routes.WAKE) },
                    onCommands = { nav.navigate(Routes.COMMANDS) },
                    onModel = { nav.navigate(Routes.MODEL) },
                    onPrivacy = { nav.navigate(Routes.PRIVACY) },
                    onNetwork = { nav.navigate(Routes.NETWORK) },
                    onAbout = { nav.navigate(Routes.ABOUT) },
                ),
                onBack = { leave(Routes.SETTINGS) },
            )
        }
        composable(Routes.VOICE) { VoiceSettingsScreen(onBack = { leave(Routes.VOICE) }) }
        composable(Routes.WAKE) { WakePhraseScreen(onBack = { leave(Routes.WAKE) }) }
        composable(Routes.COMMANDS) { CommandsScreen(onBack = { leave(Routes.COMMANDS) }) }
        composable(Routes.MODEL) {
            ModelScreen(
                onBack = { leave(Routes.MODEL) },
                onOpenCodePreview = { nav.navigate(Routes.CODE) { launchSingleTop = true } },
            )
        }
        composable(Routes.PRIVACY) {
            PrivacyScreen(
                onBack = { leave(Routes.PRIVACY) },
                onOpenHistory = { nav.navigate(Routes.HISTORY) },
                onOpenNetwork = { nav.navigate(Routes.NETWORK) },
            )
        }
        composable(Routes.HISTORY) { HistoryScreen(onBack = { leave(Routes.HISTORY) }) }
        composable(Routes.NETWORK) {
            NetworkScreen(
                onBack = { leave(Routes.NETWORK) },
                onRequestConsent = { kind -> nav.navigate(Routes.consent(kind)) },
            )
        }
        composable(Routes.ABOUT) { AboutScreen(onBack = { leave(Routes.ABOUT) }) }
        composable(
            route = Routes.CONSENT,
            arguments = listOf(navArgument("kind") { type = NavType.StringType }),
        ) { entry ->
            val kind = runCatching {
                ConnectionKind.valueOf(entry.arguments?.getString("kind").orEmpty())
            }.getOrDefault(ConnectionKind.ANY)
            ConsentScreen(kind = kind, onDone = { leave(Routes.CONSENT) })
        }
    }
}
