package com.darksh3ep.whisperer.ui.onboarding

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ai.llm.ModelStatus
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsState
import com.darksh3ep.whisperer.domain.commands.PhraseCheck
import com.darksh3ep.whisperer.ui.PhraseViewModel
import com.darksh3ep.whisperer.ui.SettingsViewModel
import com.darksh3ep.whisperer.ui.StatusViewModel
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.MicPermissionHost
import com.darksh3ep.whisperer.ui.components.NoticeCard
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.StatusLine
import com.darksh3ep.whisperer.ui.components.SwitchRow
import com.darksh3ep.whisperer.ui.components.Tone
import com.darksh3ep.whisperer.ui.components.WhispererLogo
import com.darksh3ep.whisperer.ui.components.rememberBackgroundSessionToggle
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.settings.fillMaxWidthCompat
import com.darksh3ep.whisperer.ui.settings.phraseCheckMessage
import com.darksh3ep.whisperer.ui.theme.Coral
import com.darksh3ep.whisperer.ui.theme.Lavender
import com.darksh3ep.whisperer.ui.theme.Midnight
import com.darksh3ep.whisperer.ui.theme.TextPrimary
import com.darksh3ep.whisperer.ui.theme.TextSecondary
import com.darksh3ep.whisperer.ui.ttsStatusText

private const val LAST_STEP = 6

/**
 * First-run setup (UI spec "Screen 6"): welcome, microphone, background session, wake phrase,
 * offline voice check, model status, network behaviour. No file or storage permission is ever requested.
 */
@Composable
fun OnboardingScreen() {
    val settingsVm: SettingsViewModel = containerViewModel { SettingsViewModel(it) }
    val statusVm: StatusViewModel = containerViewModel { StatusViewModel(it) }
    val phraseVm: PhraseViewModel = containerViewModel { PhraseViewModel(it) }

    var step by rememberSaveable { mutableStateOf(0) }
    var showPrivacy by remember { mutableStateOf(false) }

    val settings by settingsVm.settings.collectAsStateWithLifecycle()
    val tts by statusVm.tts.collectAsStateWithLifecycle()
    val model by statusVm.model.collectAsStateWithLifecycle()

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { statusVm.refresh() }
    BackHandler(enabled = step > 0) { step -= 1 }

    when (step) {
        0 -> OnboardingPage(
            step = step,
            title = stringResource(R.string.onboarding_welcome_title),
            showLogo = true,
            primaryText = stringResource(R.string.onboarding_get_started),
            onPrimary = { step = 1 },
            secondaryText = stringResource(R.string.onboarding_privacy_link),
            onSecondary = { showPrivacy = true },
        ) {
            Text(
                text = stringResource(R.string.onboarding_welcome_body),
                style = MaterialTheme.typography.bodyLarge,
                color = TextSecondary,
                textAlign = TextAlign.Center,
            )
        }

        1 -> MicPermissionHost(onGranted = { step = 2 }, explainFirst = false) { requestMic ->
            OnboardingPage(
                step = step,
                title = stringResource(R.string.mic_permission_title),
                showLogo = false,
                primaryText = stringResource(R.string.action_continue),
                onPrimary = requestMic,
                secondaryText = stringResource(R.string.onboarding_skip),
                onSecondary = { step = 2 },
            ) {
                BodyText(stringResource(R.string.mic_permission_body))
            }
        }

        2 -> {
            var notificationsProblem by remember { mutableStateOf(false) }
            val toggle = rememberBackgroundSessionToggle(
                onChange = {
                    notificationsProblem = false
                    settingsVm.setBackgroundSession(it)
                },
                onNotificationsUnavailable = { notificationsProblem = true },
            )
            OnboardingPage(
                step = step,
                title = stringResource(R.string.onboarding_background_title),
                showLogo = false,
                primaryText = stringResource(R.string.action_continue),
                onPrimary = { step = 3 },
                secondaryText = null,
                onSecondary = null,
            ) {
                BodyText(stringResource(R.string.onboarding_background_body))
                SectionCard {
                    SwitchRow(
                        title = stringResource(R.string.privacy_background_switch),
                        subtitle = stringResource(R.string.privacy_background_desc),
                        checked = settings?.backgroundSessionEnabled == true,
                        onCheckedChange = { toggle(it) },
                    )
                }
                if (notificationsProblem) {
                    NoticeCard(stringResource(R.string.privacy_background_notifications_needed), Tone.WARNING)
                }
            }
        }

        3 -> {
            var phrase by remember { mutableStateOf("") }
            var check by remember { mutableStateOf<PhraseCheck?>(null) }
            OnboardingPage(
                step = step,
                title = stringResource(R.string.onboarding_wake_title),
                showLogo = false,
                primaryText = stringResource(R.string.onboarding_wake_save),
                onPrimary = {
                    if (phrase.isBlank()) {
                        step = 4
                    } else {
                        val result = phraseVm.saveWake(phrase, "")
                        check = result
                        if (result == PhraseCheck.Ok) step = 4
                    }
                },
                secondaryText = stringResource(R.string.onboarding_wake_skip),
                onSecondary = { step = 4 },
            ) {
                BodyText(stringResource(R.string.onboarding_wake_body))
                NoticeCard(stringResource(R.string.wake_unavailable_note), Tone.WARNING)
                OutlinedTextField(
                    value = phrase,
                    onValueChange = { phrase = it },
                    label = { Text(stringResource(R.string.wake_phrase_label)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidthCompat(),
                )
                val message = phraseCheckMessage(check)
                if (message != null) Text(message, color = Coral)
            }
        }

        4 -> OnboardingPage(
            step = step,
            title = stringResource(R.string.onboarding_voice_title),
            showLogo = false,
            primaryText = stringResource(R.string.action_continue),
            onPrimary = { step = 5 },
            secondaryText = null,
            onSecondary = null,
        ) {
            BodyText(stringResource(R.string.onboarding_voice_body))
            SectionCard {
                StatusLine(
                    stringResource(ttsStatusText(tts.state)),
                    if (tts.state == TtsState.OFFLINE_AVAILABLE) Tone.OK else Tone.WARNING,
                )
                if (tts.state == TtsState.NO_OFFLINE_VOICE || tts.state == TtsState.ENGINE_UNAVAILABLE) {
                    BodyText(stringResource(R.string.error_no_voice))
                    BodyText(stringResource(R.string.tts_install_hint))
                }
            }
        }

        5 -> OnboardingPage(
            step = step,
            title = stringResource(R.string.onboarding_model_title),
            showLogo = false,
            primaryText = stringResource(R.string.action_continue),
            onPrimary = { step = 6 },
            secondaryText = null,
            onSecondary = null,
        ) {
            BodyText(stringResource(R.string.onboarding_model_body))
            SectionCard {
                val info = model
                if (info == null) {
                    StatusLine(stringResource(R.string.model_loading), Tone.NEUTRAL)
                } else {
                    when (info.status) {
                        ModelStatus.NOT_INSTALLED ->
                            StatusLine(stringResource(R.string.model_status_not_installed), Tone.WARNING)
                        ModelStatus.INVALID_FILE ->
                            StatusLine(stringResource(R.string.error_model_failure), Tone.ERROR)
                        ModelStatus.RUNTIME_UNAVAILABLE ->
                            StatusLine(stringResource(R.string.model_status_runtime_unavailable), Tone.WARNING)
                        ModelStatus.READY ->
                            StatusLine(stringResource(R.string.model_status_ready), Tone.OK)
                    }
                }
                BodyText(stringResource(R.string.model_target))
                BodyText(stringResource(R.string.model_download_unavailable))
            }
        }

        else -> OnboardingPage(
            step = step,
            title = stringResource(R.string.onboarding_network_title),
            showLogo = false,
            primaryText = stringResource(R.string.onboarding_finish),
            onPrimary = { settingsVm.completeOnboarding() },
            secondaryText = null,
            onSecondary = null,
        ) {
            BodyText(stringResource(R.string.network_consent_body))
            BodyText(stringResource(R.string.network_mobile_data_note))
            BodyText(stringResource(R.string.network_online_disclosure))
        }
    }

    if (showPrivacy) {
        AlertDialog(
            onDismissRequest = { showPrivacy = false },
            title = { Text(stringResource(R.string.onboarding_privacy_link)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(stringResource(R.string.onboarding_privacy_body), color = TextPrimary)
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacy = false }) { Text(stringResource(R.string.action_close)) }
            },
        )
    }
}

@Composable
private fun OnboardingPage(
    step: Int,
    title: String,
    showLogo: Boolean,
    primaryText: String,
    onPrimary: () -> Unit,
    secondaryText: String?,
    onSecondary: (() -> Unit)?,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Midnight)
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            text = stringResource(R.string.onboarding_step, step + 1, LAST_STEP + 1),
            style = MaterialTheme.typography.labelMedium,
            color = Lavender,
        )
        if (showLogo) {
            Spacer(Modifier.height(16.dp))
            WhispererLogo(size = 112.dp)
        }
        Text(
            text = title,
            style = MaterialTheme.typography.headlineLarge,
            color = TextPrimary,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .semantics { heading() },
        )
        content()
        Spacer(Modifier.height(8.dp))
        AppButton(text = primaryText, onClick = onPrimary)
        if (secondaryText != null && onSecondary != null) {
            AppButton(text = secondaryText, onClick = onSecondary, kind = ButtonKind.SECONDARY)
        }
    }
}
