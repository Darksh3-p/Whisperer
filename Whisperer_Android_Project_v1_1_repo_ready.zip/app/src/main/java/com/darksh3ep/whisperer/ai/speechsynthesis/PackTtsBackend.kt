package com.darksh3ep.whisperer.ai.speechsynthesis

import com.darksh3ep.whisperer.data.models.VoicePack

/**
 * Neural text-to-speech engine for imported voice packs (sherpa-onnx). All methods block and must be
 * called from one background thread.
 */
interface PackTtsBackend {
    /** Loads [pack]. Returns false if the files cannot be loaded. May take a second or two. */
    fun load(pack: VoicePack): Boolean

    /** Sample rate of the loaded voice, in Hz (valid after a successful [load]). */
    val sampleRate: Int

    /** Synthesizes [text] to mono float PCM in -1..1, or null on failure. [speed] 1.0 = normal. */
    fun generate(text: String, speed: Float): FloatArray?

    fun release()
}
