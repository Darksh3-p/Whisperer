package com.darksh3ep.whisperer.ui.settings

import android.Manifest
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.connectivity.SystemPanels
import com.darksh3ep.whisperer.ui.SettingsViewModel
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.NavRow
import com.darksh3ep.whisperer.ui.components.NoticeCard
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.StatusLine
import com.darksh3ep.whisperer.ui.components.SwitchRow
import com.darksh3ep.whisperer.ui.components.Tone
import com.darksh3ep.whisperer.ui.components.rememberBackgroundSessionToggle
import com.darksh3ep.whisperer.ui.components.rememberPermissionGranted
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.theme.Coral

@Composable
fun PrivacyScreen(
    onBack: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenNetwork: () -> Unit,
) {
    val vm: SettingsViewModel = containerViewModel { SettingsViewModel(it) }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val micGranted by rememberPermissionGranted(Manifest.permission.RECORD_AUDIO)
    var notificationsProblem by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    val toggleBackground = rememberBackgroundSessionToggle(
        onChange = {
            notificationsProblem = false
            vm.setBackgroundSession(it)
        },
        onNotificationsUnavailable = { notificationsProblem = true },
    )

    ScreenScaffold(title = stringResource(R.string.settings_privacy_title), onBack = onBack) {
        BodyText(stringResource(R.string.settings_privacy_desc))

        SectionCard(title = stringResource(R.string.privacy_mic_title)) {
            StatusLine(
                stringResource(if (micGranted) R.string.privacy_mic_granted else R.string.privacy_mic_not_granted),
                if (micGranted) Tone.OK else Tone.WARNING,
            )
            BodyText(stringResource(R.string.home_privacy_hint))
            if (!micGranted) {
                AppButton(
                    text = stringResource(R.string.action_open_app_settings),
                    onClick = { SystemPanels.openAppSettings(context) },
                    kind = ButtonKind.SECONDARY,
                )
            }
        }

        SectionCard(title = stringResource(R.string.privacy_background_title)) {
            SwitchRow(
                title = stringResource(R.string.privacy_background_switch),
                subtitle = stringResource(R.string.privacy_background_desc),
                checked = settings?.backgroundSessionEnabled == true,
                onCheckedChange = { toggleBackground(it) },
            )
            BodyText(stringResource(R.string.privacy_background_limits))
            if (notificationsProblem) {
                NoticeCard(stringResource(R.string.privacy_background_notifications_needed), Tone.WARNING)
            }
        }

        SectionCard(title = stringResource(R.string.privacy_history_title)) {
            SwitchRow(
                title = stringResource(R.string.privacy_history_switch),
                subtitle = stringResource(R.string.privacy_history_desc),
                checked = settings?.historyEnabled != false,
                onCheckedChange = { vm.setHistoryEnabled(it) },
            )
            NavRow(
                title = stringResource(R.string.history_title),
                subtitle = null,
                onClick = onOpenHistory,
            )
            AppButton(
                text = stringResource(R.string.history_clear_action),
                onClick = { confirmClear = true },
                kind = ButtonKind.DANGER,
            )
        }

        SectionCard(title = stringResource(R.string.privacy_network_title)) {
            BodyText(stringResource(R.string.network_online_disclosure))
            NavRow(
                title = stringResource(R.string.settings_network_title),
                subtitle = stringResource(R.string.settings_network_desc),
                onClick = onOpenNetwork,
            )
        }

        BodyText(stringResource(R.string.privacy_no_files))
    }

    if (confirmClear) {
        ClearHistoryDialog(
            onConfirm = {
                vm.clearHistory()
                confirmClear = false
            },
            onDismiss = { confirmClear = false },
        )
    }
}

@Composable
fun ClearHistoryDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.history_clear_title)) },
        text = { Text(stringResource(R.string.history_clear_body)) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(stringResource(R.string.history_clear_confirm), color = Coral)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}
