package com.darksh3ep.whisperer.data.models

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

enum class ImportError {
    CANNOT_READ,
    NOT_A_GGUF_MODEL,
    NOT_A_WHISPER_MODEL,
    GGUF_IN_WHISPER_SLOT,
    WHISPER_IN_LLM_SLOT,
    NOT_AN_ARCHIVE,
    PACK_INCOMPLETE,
    PACK_UNSUPPORTED,
    NOT_ENOUGH_SPACE,
    FAILED,
}

sealed interface ImportState {
    data object Idle : ImportState
    data class Working(val kind: ModelKind, val name: String, val doneBytes: Long, val totalBytes: Long, val extracting: Boolean) : ImportState
    data class Done(val kind: ModelKind, val name: String) : ImportState
    data class Failed(val kind: ModelKind, val error: ImportError) : ImportState
}

private class ImportException(val error: ImportError) : Exception()

/**
 * Copies a model chosen with Android's own file picker into app-private storage. The picker hands over
 * a one-time stream, so no storage permission is needed. Runs in the app scope: leaving the screen does not cancel it.
 */
class ModelImporter(
    private val context: Context,
    private val store: ModelStore,
    private val scope: CoroutineScope,
) {
    private val _state = MutableStateFlow<ImportState>(ImportState.Idle)
    val state: StateFlow<ImportState> = _state.asStateFlow()
    private var job: Job? = null

    fun isBusy(): Boolean = job?.isActive == true

    fun dismiss() {
        if (!isBusy()) _state.value = ImportState.Idle
    }

    fun cancel() {
        job?.cancel()
    }

    fun start(kind: ModelKind, uri: Uri) {
        if (isBusy()) return
        store.ensureDirs()
        store.cleanLeftovers()
        job = scope.launch(Dispatchers.IO) {
            val (name, size) = queryNameAndSize(uri)
            _state.value = ImportState.Working(kind, name, 0L, size, extracting = false)
            try {
                when (kind) {
                    ModelKind.LLM -> importSingle(uri, name, size, kind, store.llmDir, ".gguf") { magic ->
                        when (magic) {
                            FileMagic.GGUF -> null
                            FileMagic.WHISPER_GGML -> ImportError.WHISPER_IN_LLM_SLOT
                            else -> ImportError.NOT_A_GGUF_MODEL
                        }
                    }
                    ModelKind.WHISPER -> importSingle(uri, name, size, kind, store.whisperDir, ".bin") { magic ->
                        when (magic) {
                            FileMagic.WHISPER_GGML -> null
                            FileMagic.GGUF -> ImportError.GGUF_IN_WHISPER_SLOT
                            else -> ImportError.NOT_A_WHISPER_MODEL
                        }
                    }
                    ModelKind.VOICE_PACK -> importPack(uri, name, size)
                }
                _state.value = ImportState.Done(kind, name)
            } catch (e: CancellationException) {
                store.cleanLeftovers()
                _state.value = ImportState.Idle
                throw e
            } catch (e: ImportException) {
                store.cleanLeftovers()
                _state.value = ImportState.Failed(kind, e.error)
            } catch (e: Exception) {
                store.cleanLeftovers()
                _state.value = ImportState.Failed(kind, ImportError.FAILED)
            }
        }
    }

    // ------------------------------------------------------------------ single file (GGUF / Whisper)

    private fun importSingle(
        uri: Uri,
        displayName: String,
        size: Long,
        kind: ModelKind,
        targetDir: File,
        extension: String,
        check: (FileMagic) -> ImportError?,
    ) {
        requireSpace(targetDir, if (size > 0) size else 0L, factor = 1.05)
        val safeName = PackLayout.sanitizeId(displayName).let {
            if (it.endsWith(extension, ignoreCase = true)) it else it + extension
        }
        val part = File(targetDir, "$safeName.part")
        val input = context.contentResolver.openInputStream(uri) ?: throw ImportException(ImportError.CANNOT_READ)
        input.use { raw ->
            val buffered = BufferedInputStream(raw, 1 shl 16)
            buffered.mark(16)
            val head = ByteArray(8)
            val n = buffered.read(head)
            buffered.reset()
            check(FileMagic.detect(head, maxOf(n, 0)))?.let { throw ImportException(it) }

            part.outputStream().buffered(1 shl 16).use { out ->
                copyWithProgress(buffered, out, kind, displayName, size)
            }
        }
        // Replace whatever was installed before (one model per slot).
        targetDir.listFiles { f -> f.isFile && !f.name.endsWith(".part") }?.forEach { it.delete() }
        if (!part.renameTo(File(targetDir, safeName))) {
            part.delete()
            throw ImportException(ImportError.FAILED)
        }
    }

    private fun copyWithProgress(input: InputStream, out: java.io.OutputStream, kind: ModelKind, name: String, total: Long) {
        val buffer = ByteArray(1 shl 20)
        var done = 0L
        var lastReport = 0L
        while (true) {
            if (!scopeActive()) throw CancellationException()
            val n = input.read(buffer)
            if (n < 0) break
            out.write(buffer, 0, n)
            done += n
            val now = System.nanoTime()
            if (now - lastReport > 200_000_000L) {
                lastReport = now
                _state.value = ImportState.Working(kind, name, done, total, extracting = false)
            }
        }
        out.flush()
    }

    private fun scopeActive(): Boolean = job?.isActive != false

    // ------------------------------------------------------------------ voice packs (.zip / .tar.bz2 / .tar.gz)

    private fun importPack(uri: Uri, displayName: String, size: Long) {
        requireSpace(store.voicesDir, if (size > 0) size * 3 else 0L, factor = 1.0)
        val tmp = File(store.voicesDir, ".tmp-${System.currentTimeMillis()}")
        if (!tmp.mkdirs()) throw ImportException(ImportError.FAILED)
        try {
            val counter = CountingInputStream(
                context.contentResolver.openInputStream(uri) ?: throw ImportException(ImportError.CANNOT_READ)
            )
            counter.use { counted ->
                val buffered = BufferedInputStream(counted, 1 shl 16)
                buffered.mark(16)
                val head = ByteArray(8)
                val n = buffered.read(head)
                buffered.reset()
                val report = {
                    _state.value = ImportState.Working(ModelKind.VOICE_PACK, displayName, counted.count, size, extracting = true)
                }
                when (FileMagic.detect(head, maxOf(n, 0))) {
                    FileMagic.ZIP -> extractZip(buffered, tmp, report)
                    FileMagic.BZIP2 -> extractTar(BZip2CompressorInputStream(buffered), tmp, report)
                    FileMagic.GZIP -> extractTar(GZIPInputStream(buffered), tmp, report)
                    else -> throw ImportException(ImportError.NOT_AN_ARCHIVE)
                }
            }

            val root = PackLayout.findRoot(tmp) ?: throw ImportException(ImportError.PACK_INCOMPLETE)
            val pack = PackLayout.describe(root) ?: throw ImportException(ImportError.PACK_INCOMPLETE)
            if (pack.type == VoicePackType.UNSUPPORTED) throw ImportException(ImportError.PACK_UNSUPPORTED)

            val baseId = PackLayout.sanitizeId(if (root == tmp) displayName else root.name)
            var id = baseId
            var counter2 = 2
            while (File(store.voicesDir, id).exists()) id = "$baseId-${counter2++}"
            if (!root.renameTo(File(store.voicesDir, id))) throw ImportException(ImportError.FAILED)
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun extractZip(input: InputStream, target: File, report: () -> Unit) {
        ZipInputStream(input).use { zip ->
            var entries = 0
            var total = 0L
            while (true) {
                if (!scopeActive()) throw CancellationException()
                val entry = zip.nextEntry ?: break
                if (++entries > MAX_ENTRIES) throw ImportException(ImportError.PACK_UNSUPPORTED)
                val out = safeChild(target, entry.name)
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    total += writeEntry(zip, out)
                    if (total > MAX_EXTRACTED_BYTES) throw ImportException(ImportError.PACK_UNSUPPORTED)
                }
                report()
            }
        }
    }

    private fun extractTar(decompressed: InputStream, target: File, report: () -> Unit) {
        TarArchiveInputStream(decompressed).use { tar ->
            var entries = 0
            var total = 0L
            while (true) {
                if (!scopeActive()) throw CancellationException()
                val entry = tar.nextEntry ?: break
                if (++entries > MAX_ENTRIES) throw ImportException(ImportError.PACK_UNSUPPORTED)
                if (!tar.canReadEntryData(entry)) continue
                val out = safeChild(target, entry.name)
                if (entry.isDirectory) {
                    out.mkdirs()
                } else if (entry.isFile) {
                    out.parentFile?.mkdirs()
                    total += writeEntry(tar, out)
                    if (total > MAX_EXTRACTED_BYTES) throw ImportException(ImportError.PACK_UNSUPPORTED)
                }
                // Symlinks and other special entries are skipped on purpose.
                report()
            }
        }
    }

    private fun writeEntry(input: InputStream, out: File): Long {
        var written = 0L
        out.outputStream().buffered(1 shl 16).use { stream ->
            val buffer = ByteArray(1 shl 16)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                stream.write(buffer, 0, n)
                written += n
            }
        }
        return written
    }

    // ------------------------------------------------------------------ helpers

    private fun queryNameAndSize(uri: Uri): Pair<String, Long> {
        var name: String? = null
        var size = -1L
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = c.getString(nameIdx)
                    if (sizeIdx >= 0 && !c.isNull(sizeIdx)) size = c.getLong(sizeIdx)
                }
            }
        } catch (e: Exception) {
            // Use fallbacks below.
        }
        return (name ?: uri.lastPathSegment ?: "model") to size
    }

    private fun requireSpace(dir: File, needed: Long, factor: Double) {
        if (needed <= 0) return
        dir.mkdirs()
        val free = try { StatFs(dir.absolutePath).availableBytes } catch (e: Exception) { Long.MAX_VALUE }
        if (free < (needed * factor).toLong()) throw ImportException(ImportError.NOT_ENOUGH_SPACE)
    }

    companion object {
        private const val MAX_ENTRIES = 20_000
        private const val MAX_EXTRACTED_BYTES = 2L * 1024 * 1024 * 1024

        /** Resolves an archive entry inside [root]; entries that would escape it ("../") are rejected. */
        fun safeChild(root: File, entryName: String): File {
            val child = File(root, entryName)
            val rootPath = root.canonicalPath
            val childPath = child.canonicalPath
            if (childPath != rootPath && !childPath.startsWith(rootPath + File.separator)) {
                throw ImportException(ImportError.PACK_UNSUPPORTED)
            }
            return child
        }
    }
}

/** Counts bytes read from the underlying stream so extraction can show progress. */
private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
    @Volatile var count = 0L
        private set

    @Throws(IOException::class)
    override fun read(): Int = super.read().also { if (it >= 0) count++ }

    @Throws(IOException::class)
    override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, len).also { if (it > 0) count += it }
}
