package com.darksh3ep.whisperer.ui.home

import com.darksh3ep.whisperer.ai.llm.ModelStatus
import com.darksh3ep.whisperer.ai.speechrecognition.AsrAvailability
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsState
import com.darksh3ep.whisperer.connectivity.NetworkSnapshot

enum class PrimaryStatus {
    MIC_PERMISSION_NEEDED,
    SESSION_ACTIVE,
    CHECKING,
    MODEL_NOT_INSTALLED,
    MODEL_FILE_INVALID,
    MODEL_RUNTIME_UNAVAILABLE,
    READY,
}

enum class ConnectivityStatus { INTERNET_AVAILABLE, INTERNET_UNAVAILABLE, OFFLINE_MODE }

/** Decides which status lines the home screen may show. Only verified states are ever reported. */
object HomeStatusResolver {

    fun primary(micGranted: Boolean, sessionActive: Boolean, model: ModelStatus?): PrimaryStatus = when {
        !micGranted -> PrimaryStatus.MIC_PERMISSION_NEEDED
        sessionActive -> PrimaryStatus.SESSION_ACTIVE
        model == null -> PrimaryStatus.CHECKING
        model == ModelStatus.NOT_INSTALLED -> PrimaryStatus.MODEL_NOT_INSTALLED
        model == ModelStatus.INVALID_FILE -> PrimaryStatus.MODEL_FILE_INVALID
        model == ModelStatus.RUNTIME_UNAVAILABLE -> PrimaryStatus.MODEL_RUNTIME_UNAVAILABLE
        else -> PrimaryStatus.READY
    }

    /** "Offline mode" is only claimed when assistant, recognition AND speech output are all usable locally. */
    fun connectivity(
        network: NetworkSnapshot,
        model: ModelStatus?,
        asr: AsrAvailability,
        tts: TtsState,
    ): ConnectivityStatus {
        if (network.connected) return ConnectivityStatus.INTERNET_AVAILABLE
        val fullyLocal = model == ModelStatus.READY &&
            asr == AsrAvailability.AVAILABLE &&
            tts == TtsState.OFFLINE_AVAILABLE
        return if (fullyLocal) ConnectivityStatus.OFFLINE_MODE else ConnectivityStatus.INTERNET_UNAVAILABLE
    }
}
