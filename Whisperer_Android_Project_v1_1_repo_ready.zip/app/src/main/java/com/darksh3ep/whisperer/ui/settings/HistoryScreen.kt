package com.darksh3ep.whisperer.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.data.history.ConversationRecord
import com.darksh3ep.whisperer.domain.conversation.Speaker
import com.darksh3ep.whisperer.ui.SettingsViewModel
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.theme.Lavender
import com.darksh3ep.whisperer.ui.theme.TextPrimary
import com.darksh3ep.whisperer.ui.theme.TextSecondary
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val vm: SettingsViewModel = containerViewModel { SettingsViewModel(it) }
    val history by vm.history.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.loadHistory() }

    ScreenScaffold(title = stringResource(R.string.history_title), onBack = onBack) {
        val records = history
        when {
            records == null -> BodyText(stringResource(R.string.model_loading))
            records.isEmpty() -> BodyText(stringResource(R.string.history_empty))
            else -> {
                records.forEach { record -> RecordCard(record) }
                AppButton(
                    text = stringResource(R.string.history_clear_action),
                    onClick = { confirmClear = true },
                    kind = ButtonKind.DANGER,
                )
            }
        }
    }

    if (confirmClear) {
        ClearHistoryDialog(
            onConfirm = {
                vm.clearHistory()
                confirmClear = false
            },
            onDismiss = { confirmClear = false },
        )
    }
}

@Composable
private fun RecordCard(record: ConversationRecord) {
    var expanded by remember { mutableStateOf(false) }
    val date = remember(record.startedAtMillis) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(record.startedAtMillis))
    }
    val preview = record.messages.firstOrNull { it.speaker == Speaker.USER }?.text.orEmpty()

    SectionCard(modifier = Modifier.clickable(role = Role.Button) { expanded = !expanded }) {
        Text(date, style = MaterialTheme.typography.labelMedium, color = Lavender)
        if (!expanded) {
            Text(preview, style = MaterialTheme.typography.bodyLarge, color = TextPrimary, maxLines = 2)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                record.messages.forEach { message ->
                    val who = stringResource(
                        if (message.speaker == Speaker.USER) R.string.speaker_you else R.string.speaker_whisperer
                    )
                    Text(who, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(message.text, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                }
            }
        }
    }
}
