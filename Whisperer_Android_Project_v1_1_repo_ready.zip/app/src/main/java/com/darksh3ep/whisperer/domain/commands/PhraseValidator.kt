package com.darksh3ep.whisperer.domain.commands

sealed interface PhraseOwner {
    data object Wake : PhraseOwner
    data class Command(val id: String, val action: CommandAction) : PhraseOwner
}

sealed interface PhraseCheck {
    data object Ok : PhraseCheck
    data object Empty : PhraseCheck
    data object TooShort : PhraseCheck
    /** The same (or nearly the same) phrase appears twice in the list being saved. */
    data object RepeatedInList : PhraseCheck
    /** The phrase is already used by the wake phrase or by another command. */
    data class Conflict(val owner: PhraseOwner, val existingPhrase: String) : PhraseCheck
}

/** Duplicate / conflict handling for wake phrases and command phrases. */
object PhraseValidator {
    const val MIN_LENGTH = 2
    const val CONFLICT_SIMILARITY = 0.9

    /**
     * Validates the phrases being saved for [editing] (null when adding a new command).
     * Phrases that belong to [editing] today are ignored, so saving an unchanged entry does not conflict with itself.
     */
    fun checkAll(
        candidates: List<String>,
        editing: PhraseOwner?,
        wake: WakePhraseConfig,
        commands: List<VoiceCommand>,
    ): PhraseCheck {
        val cleaned = candidates.map { it.trim() }.filter { it.isNotEmpty() }
        if (cleaned.isEmpty()) return PhraseCheck.Empty

        for (phrase in cleaned) {
            if (PhraseText.normalize(phrase).length < MIN_LENGTH) return PhraseCheck.TooShort
        }
        for (i in cleaned.indices) {
            for (j in i + 1 until cleaned.size) {
                if (PhraseText.similarity(cleaned[i], cleaned[j]) >= CONFLICT_SIMILARITY) {
                    return PhraseCheck.RepeatedInList
                }
            }
        }
        for (phrase in cleaned) {
            if (editing != PhraseOwner.Wake) {
                for (existing in wake.allPhrases) {
                    if (PhraseText.similarity(phrase, existing) >= CONFLICT_SIMILARITY) {
                        return PhraseCheck.Conflict(PhraseOwner.Wake, existing)
                    }
                }
            }
            for (command in commands) {
                if (editing is PhraseOwner.Command && editing.id == command.id) continue
                for (existing in command.phrases) {
                    if (PhraseText.similarity(phrase, existing) >= CONFLICT_SIMILARITY) {
                        return PhraseCheck.Conflict(PhraseOwner.Command(command.id, command.action), existing)
                    }
                }
            }
        }
        return PhraseCheck.Ok
    }
}
