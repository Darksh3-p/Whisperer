package com.darksh3ep.whisperer.domain.conversation

import com.darksh3ep.whisperer.domain.audio.AudioRoute

enum class Speaker { USER, ASSISTANT, SYSTEM }

/** What the voice session is doing right now. Always shown to the user as text as well as animation. */
enum class Phase { IDLE, LISTENING, THINKING, SPEAKING, SPEECH_PAUSED }

/**
 * Short status messages produced by the session. The UI maps each one to approved copy in strings.xml;
 * the domain layer never contains user-facing prose and never carries raw exception text.
 */
enum class Notice {
    NONE,
    MODEL_NOT_INSTALLED,
    MODEL_RUNTIME_UNAVAILABLE,
    MODEL_LOAD_FAILED,
    ASR_UNAVAILABLE,
    MIC_PERMISSION_NEEDED,
    RECOGNITION_FAILED,
    TTS_FAILED,
    NO_VOICE,
    ROUTE_DISCONNECTED,
    GENERIC_ERROR,
    INTERRUPTED,
    NOTHING_TO_REPEAT,
    MIC_MUTED,
    AUDIO_INTERRUPTED,
    BACKGROUND_UNAVAILABLE,
}

data class ChatMessage(
    val id: Long,
    val speaker: Speaker,
    val text: String,
    val timeMillis: Long,
    /** Only used for SYSTEM messages; selects the localized notice text. */
    val notice: Notice = Notice.NONE,
)

data class CodeSnippet(
    /** Language label exactly as supplied by the response's code fence; null when it is not stated (never guessed). */
    val language: String?,
    val code: String,
)

data class SessionUiState(
    val sessionActive: Boolean = false,
    /** True only while the foreground service + notification are actually running. */
    val backgroundActive: Boolean = false,
    val phase: Phase = Phase.IDLE,
    val micMuted: Boolean = false,
    /** True only while the recognizer is actually capturing audio. Drives the visible microphone indicator. */
    val micActive: Boolean = false,
    val partialTranscript: String = "",
    val messages: List<ChatMessage> = emptyList(),
    val audioRoute: AudioRoute = AudioRoute.PHONE_SPEAKER,
    val notice: Notice = Notice.NONE,
    val codeSnippet: CodeSnippet? = null,
)
