package com.darksh3ep.whisperer.ai.wake

/**
 * Always-on wake phrase detection.
 *
 * Design for a future implementation (see docs/ARCHITECTURE.md):
 *   1. low-power voice-activity gate on a user-started foreground session,
 *   2. lightweight phrase recognition / enrolled-phrase model (NOT continuous Whisper Tiny),
 *   3. confidence threshold + cooldown, 4. tap-to-talk fallback.
 *
 * This build contains NO always-on detector. The user's phrase can be saved and checked against
 * what the speech recognizer hears ("Test wake phrase"), but nothing listens for it in the background.
 */
interface WakePhraseDetector {
    val isAvailable: Boolean
}

object UnavailableWakePhraseDetector : WakePhraseDetector {
    override val isAvailable: Boolean = false
}
