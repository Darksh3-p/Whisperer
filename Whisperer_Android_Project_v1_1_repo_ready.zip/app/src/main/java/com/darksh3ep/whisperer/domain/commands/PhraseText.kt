package com.darksh3ep.whisperer.domain.commands

import java.text.Normalizer
import java.util.Locale

/** Language-neutral text normalisation and similarity used for wake phrases and command phrases. */
object PhraseText {
    private val separators = Regex("[^\\p{L}\\p{M}\\p{N}]+")

    fun normalize(input: String): String {
        val folded = Normalizer.normalize(input, Normalizer.Form.NFKC)
        return folded.lowercase(Locale.ROOT).replace(separators, " ").trim()
    }

    /** 1.0 = identical after normalisation, 0.0 = nothing in common. */
    fun similarity(a: String, b: String): Double {
        val x = normalize(a)
        val y = normalize(b)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        if (x == y) return 1.0
        val distance = levenshtein(x, y)
        return 1.0 - distance.toDouble() / maxOf(x.length, y.length).toDouble()
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(
                    current[j - 1] + 1,
                    previous[j] + 1,
                    previous[j - 1] + cost,
                )
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
