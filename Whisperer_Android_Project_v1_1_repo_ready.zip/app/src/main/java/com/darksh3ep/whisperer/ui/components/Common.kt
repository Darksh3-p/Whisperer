package com.darksh3ep.whisperer.ui.components

import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ui.theme.Amber
import com.darksh3ep.whisperer.ui.theme.Coral
import com.darksh3ep.whisperer.ui.theme.Midnight
import com.darksh3ep.whisperer.ui.theme.Surface1
import com.darksh3ep.whisperer.ui.theme.Surface2
import com.darksh3ep.whisperer.ui.theme.TextPrimary
import com.darksh3ep.whisperer.ui.theme.TextSecondary

/** The Whisper Wave brand mark (exact vector from assets/branding/whisperer-logo.svg). */
@Composable
fun WhispererLogo(size: Dp, modifier: Modifier = Modifier, contentDescription: String? = null) {
    Image(
        painter = painterResource(R.drawable.whisperer_logo),
        contentDescription = contentDescription,
        modifier = modifier.size(size),
    )
}

/** True when the user asked Android to remove animations. */
@Composable
fun rememberReducedMotion(): Boolean {
    val context = LocalContext.current
    return remember {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
}

/** Optional, user-controlled haptic tick. */
@Composable
fun rememberHaptic(enabled: Boolean): () -> Unit {
    val haptics = LocalHapticFeedback.current
    return { if (enabled) haptics.performHapticFeedback(HapticFeedbackType.LongPress) }
}

/** Full-screen layout with an optional back button, respecting system bars and font scaling. */
@Composable
fun ScreenScaffold(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    scrollable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Midnight)
            .safeDrawingPadding(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                    Icon(
                        painter = painterResource(R.drawable.ic_back),
                        contentDescription = stringResource(R.string.action_back),
                        tint = TextPrimary,
                    )
                }
            } else {
                Spacer(Modifier.width(12.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                modifier = Modifier.semantics { heading() },
            )
        }
        val bodyModifier = if (scrollable) {
            Modifier.weight(1f).verticalScroll(rememberScrollState())
        } else {
            Modifier.weight(1f)
        }
        Column(
            modifier = bodyModifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            content = content,
        )
    }
}

@Composable
fun SectionCard(
    modifier: Modifier = Modifier,
    title: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Surface1),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (title != null) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = com.darksh3ep.whisperer.ui.theme.Lavender,
                    modifier = Modifier.semantics { heading() },
                )
            }
            content()
        }
    }
}

enum class ButtonKind { PRIMARY, SECONDARY, DANGER }

@Composable
fun AppButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: ButtonKind = ButtonKind.PRIMARY,
    enabled: Boolean = true,
) {
    val shape = RoundedCornerShape(18.dp)
    val sized = modifier.fillMaxWidth().heightIn(min = 56.dp)
    when (kind) {
        ButtonKind.PRIMARY -> Button(
            onClick = onClick,
            modifier = sized,
            enabled = enabled,
            shape = shape,
        ) { Text(text, style = MaterialTheme.typography.labelLarge) }

        ButtonKind.SECONDARY -> Button(
            onClick = onClick,
            modifier = sized,
            enabled = enabled,
            shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = Surface2,
                contentColor = TextPrimary,
                disabledContainerColor = Surface1,
                disabledContentColor = TextSecondary,
            ),
        ) { Text(text, style = MaterialTheme.typography.labelLarge) }

        ButtonKind.DANGER -> OutlinedButton(
            onClick = onClick,
            modifier = sized,
            enabled = enabled,
            shape = shape,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Coral),
        ) { Text(text, style = MaterialTheme.typography.labelLarge) }
    }
}

/** A tappable settings row with title, description and a chevron. */
@Composable
fun NavRow(title: String, subtitle: String?, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(role = Role.Button, onClick = onClick)
            .heightIn(min = 56.dp)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }
        }
        Icon(
            painter = painterResource(R.drawable.ic_chevron_right),
            contentDescription = null,
            tint = TextSecondary,
        )
    }
}

@Composable
fun SwitchRow(
    title: String,
    subtitle: String?,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .toggleable(
                value = checked,
                enabled = enabled,
                role = Role.Switch,
                onValueChange = onCheckedChange,
            )
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = null,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Midnight,
                checkedTrackColor = com.darksh3ep.whisperer.ui.theme.Teal,
            ),
        )
    }
}

enum class Tone { NEUTRAL, WARNING, ERROR, OK }

/** Status line: a coloured dot AND text (state is never conveyed by colour alone). */
@Composable
fun StatusLine(text: String, tone: Tone, modifier: Modifier = Modifier) {
    val color = when (tone) {
        Tone.OK -> com.darksh3ep.whisperer.ui.theme.Teal
        Tone.WARNING -> Amber
        Tone.ERROR -> Coral
        Tone.NEUTRAL -> TextSecondary
    }
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
    }
}

@Composable
fun NoticeCard(text: String, tone: Tone, modifier: Modifier = Modifier) {
    val color = when (tone) {
        Tone.ERROR -> Coral
        Tone.WARNING -> Amber
        Tone.OK -> com.darksh3ep.whisperer.ui.theme.Teal
        Tone.NEUTRAL -> TextSecondary
    }
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Surface2),
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .width(4.dp)
                    .height(32.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
            Spacer(Modifier.width(12.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
        }
    }
}

@Composable
fun BodyText(text: String, modifier: Modifier = Modifier, color: Color = TextSecondary) {
    Text(text, style = MaterialTheme.typography.bodyMedium, color = color, modifier = modifier)
}
