package com.darksh3ep.whisperer.ai.speechrecognition

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Offline speech recognition with whisper.cpp. Audio is captured from the microphone, stopped by a simple
 * silence detector (or by [stopListening]), then transcribed fully on-device. Nothing leaves the phone.
 * Public methods must be called on the main thread; callbacks are delivered on the main thread.
 */
class WhisperRecognizer(
    context: Context,
    private val modelFile: () -> File?,
) : SpeechRecognizerProvider {

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "whisperer-asr").apply { isDaemon = true } }
    private val generation = AtomicInteger(0)

    @Volatile private var stopRequested = false
    @Volatile private var activeRecord: AudioRecord? = null

    // Touched only from the executor thread.
    private var handle = 0L
    private var loadedPath: String? = null

    /** True when the native library is present and a Whisper model file has been imported. */
    fun isReady(): Boolean = WhisperNative.isAvailable && modelFile() != null

    override fun availability(): AsrAvailability =
        if (isReady()) AsrAvailability.AVAILABLE else AsrAvailability.NO_ON_DEVICE_ENGINE

    override fun start(callbacks: RecognitionCallbacks) {
        val file = modelFile()
        if (!WhisperNative.isAvailable || file == null) {
            callbacks.onFailure(RecognitionFailure.UNAVAILABLE)
            return
        }
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            callbacks.onFailure(RecognitionFailure.PERMISSION)
            return
        }
        val gen = generation.incrementAndGet()
        stopRequested = false
        executor.execute { runSession(gen, file, callbacks) }
    }

    override fun stopListening() {
        stopRequested = true
    }

    override fun cancel() {
        generation.incrementAndGet()
        stopRequested = true
        // A transcription already running finishes in the background and its result is dropped (generation changed).
    }

    override fun destroy() {
        cancel()
        executor.execute {
            if (handle != 0L) WhisperNative.nativeFree(handle)
            handle = 0L
            loadedPath = null
        }
    }

    /** Frees the model memory without stopping the recognizer. */
    fun release() {
        executor.execute {
            if (handle != 0L) WhisperNative.nativeFree(handle)
            handle = 0L
            loadedPath = null
        }
    }

    private fun current(gen: Int) = generation.get() == gen

    private fun post(gen: Int, block: () -> Unit) {
        main.post { if (current(gen)) block() }
    }

    private fun runSession(gen: Int, file: File, callbacks: RecognitionCallbacks) {
        val samples = capture(gen, callbacks) ?: return
        if (!current(gen)) return
        if (samples.size < SAMPLE_RATE / 4) {
            post(gen) { callbacks.onFailure(RecognitionFailure.NO_SPEECH) }
            return
        }
        try {
            if (handle == 0L || loadedPath != file.absolutePath) {
                if (handle != 0L) WhisperNative.nativeFree(handle)
                handle = WhisperNative.nativeLoad(file.absolutePath)
                loadedPath = if (handle != 0L) file.absolutePath else null
            }
            if (handle == 0L) {
                post(gen) { callbacks.onFailure(RecognitionFailure.UNAVAILABLE) }
                return
            }
            val language = WhisperText.languageFor(file, Locale.getDefault().language)
            val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
            val bytes = WhisperNative.nativeTranscribe(handle, samples, language, threads)
            if (!current(gen)) return
            val text = if (bytes == null) null else WhisperText.clean(String(bytes, Charsets.UTF_8))
            when {
                bytes == null -> post(gen) { callbacks.onFailure(RecognitionFailure.OTHER) }
                text.isNullOrBlank() -> post(gen) { callbacks.onFailure(RecognitionFailure.NO_SPEECH) }
                else -> post(gen) { callbacks.onFinal(text, null) }
            }
        } catch (t: Throwable) {
            post(gen) { callbacks.onFailure(RecognitionFailure.OTHER) }
        }
    }

    /** Records until silence / stop / cancel. Returns 16 kHz mono float samples, or null if it failed or was cancelled. */
    private fun capture(gen: Int, callbacks: RecognitionCallbacks): FloatArray? {
        val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) {
            post(gen) { callbacks.onFailure(RecognitionFailure.OTHER) }
            return null
        }
        val record = try {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuffer, SAMPLE_RATE * 2))
                .build()
        } catch (e: SecurityException) {
            post(gen) { callbacks.onFailure(RecognitionFailure.PERMISSION) }
            return null
        } catch (e: Exception) {
            post(gen) { callbacks.onFailure(RecognitionFailure.OTHER) }
            return null
        }
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            post(gen) { callbacks.onFailure(RecognitionFailure.BUSY) }
            return null
        }

        activeRecord = record
        val detector = UtteranceDetector()
        val all = ShortBuffer()
        val frame = ShortArray(FRAME_SAMPLES)
        var verdict = UtteranceDetector.Verdict.CONTINUE
        try {
            record.startRecording()
            post(gen) { callbacks.onListening() }
            while (current(gen) && !stopRequested && verdict == UtteranceDetector.Verdict.CONTINUE) {
                val n = record.read(frame, 0, frame.size)
                if (n <= 0) {
                    verdict = UtteranceDetector.Verdict.NO_SPEECH
                    break
                }
                all.add(frame, n)
                val rms = UtteranceDetector.rms(frame, n)
                post(gen) { callbacks.onLevel((rms * 12.0).toFloat().coerceIn(0f, 1f)) }
                verdict = detector.onFrame(rms)
            }
        } catch (e: Exception) {
            post(gen) { callbacks.onFailure(RecognitionFailure.OTHER) }
            return null
        } finally {
            try { record.stop() } catch (e: Exception) { /* already stopped */ }
            record.release()
            activeRecord = null
        }

        if (!current(gen)) return null
        // No speech at all (silence timeout, or the user stopped before saying anything).
        if (!detector.speechStarted && verdict != UtteranceDetector.Verdict.END_OF_SPEECH) {
            post(gen) { callbacks.onFailure(RecognitionFailure.NO_SPEECH) }
            return null
        }
        // Whisper wants at least ~1 s of audio; pad with silence.
        val pcm = all.toShortArray()
        val padded = FloatArray(maxOf(pcm.size, SAMPLE_RATE + SAMPLE_RATE / 5))
        for (i in pcm.indices) padded[i] = pcm[i] / 32768f
        return padded
    }

    /** Minimal growable short buffer. */
    private class ShortBuffer {
        private var data = ShortArray(SAMPLE_RATE * 10)
        private var size = 0
        fun add(src: ShortArray, count: Int) {
            if (size + count > data.size) data = data.copyOf(maxOf(data.size * 2, size + count))
            System.arraycopy(src, 0, data, size, count)
            size += count
        }
        fun toShortArray(): ShortArray = data.copyOf(size)
    }

    companion object {
        const val SAMPLE_RATE = 16_000
        private const val FRAME_SAMPLES = 480 // 30 ms
    }
}

/**
 * Uses Whisper when a Whisper model is imported and the native runtime is present; otherwise falls back to
 * Android's own on-device recognizer. Never uses an online recognizer.
 */
class HybridRecognizer(
    private val whisper: WhisperRecognizer,
    private val android: SpeechRecognizerProvider,
) : SpeechRecognizerProvider {

    private var active: SpeechRecognizerProvider = android

    private fun pick(): SpeechRecognizerProvider = if (whisper.isReady()) whisper else android

    override fun availability(): AsrAvailability = pick().availability()

    override fun start(callbacks: RecognitionCallbacks) {
        active.cancel()
        active = pick()
        active.start(callbacks)
    }

    override fun stopListening() = active.stopListening()
    override fun cancel() = active.cancel()

    override fun destroy() {
        whisper.destroy()
        android.destroy()
    }

    fun release() = whisper.release()
}
