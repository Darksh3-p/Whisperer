package com.darksh3ep.whisperer.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darksh3ep.whisperer.AppContainer
import android.net.Uri
import com.darksh3ep.whisperer.ai.llm.InferenceRuntime
import com.darksh3ep.whisperer.ai.llm.ModelFileInfo
import com.darksh3ep.whisperer.ai.speechrecognition.WhisperNative
import com.darksh3ep.whisperer.ai.speechsynthesis.PackTtsRuntime
import com.darksh3ep.whisperer.data.models.ImportState
import com.darksh3ep.whisperer.data.models.ModelKind
import com.darksh3ep.whisperer.data.models.VoicePack
import com.darksh3ep.whisperer.ai.speechrecognition.AsrAvailability
import com.darksh3ep.whisperer.ai.speechrecognition.ListenResult
import com.darksh3ep.whisperer.ai.speechrecognition.RecognitionFailure
import com.darksh3ep.whisperer.ai.speechrecognition.listenOnce
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechError
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechListener
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsCapability
import com.darksh3ep.whisperer.ai.speechsynthesis.VoiceOption
import com.darksh3ep.whisperer.connectivity.NetworkSnapshot
import com.darksh3ep.whisperer.data.history.ConversationRecord
import com.darksh3ep.whisperer.data.preferences.AppSettings
import com.darksh3ep.whisperer.domain.audio.AudioOutputOption
import com.darksh3ep.whisperer.domain.commands.CommandAction
import com.darksh3ep.whisperer.domain.commands.MatchOutcome
import com.darksh3ep.whisperer.domain.commands.PhraseCheck
import com.darksh3ep.whisperer.domain.commands.PhraseOwner
import com.darksh3ep.whisperer.domain.commands.PhraseValidator
import com.darksh3ep.whisperer.domain.commands.VoiceCommand
import com.darksh3ep.whisperer.domain.commands.WakePhraseConfig
import com.darksh3ep.whisperer.domain.commands.WakePhraseMatcher
import com.darksh3ep.whisperer.domain.conversation.CodeSnippet
import com.darksh3ep.whisperer.domain.conversation.SessionUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Thin view-model over the application-scoped voice session controller. */
class SessionViewModel(private val container: AppContainer) : ViewModel() {
    private val controller get() = container.sessionController

    val state: StateFlow<SessionUiState> get() = controller.state
    val level: StateFlow<Float> get() = controller.inputLevel
    val settings: StateFlow<AppSettings?> = container.settings

    fun startAndListen() = controller.startAndListen()
    fun tapToTalk() = controller.tapToTalk()
    fun interrupt() = controller.interrupt()
    fun pauseSpeech() = controller.pauseSpeech()
    fun resumeSpeech() = controller.resumeSpeech()
    fun setMuted(muted: Boolean) = controller.setMuted(muted)
    fun endSession() = controller.endSession()
    fun showCode(snippet: CodeSnippet?) = controller.showCode(snippet)

    fun audioOutputs(): List<AudioOutputOption> = container.audioRoutes.selectableOutputs()
    fun selectAudioOutput(id: Int?) {
        container.audioRoutes.selectOutput(id)
    }
}

/** Live status of the model, speech recognition, speech output and network. */
class StatusViewModel(private val container: AppContainer) : ViewModel() {
    val network: StateFlow<NetworkSnapshot> = container.connectivity.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), container.connectivity.current())

    val tts: StateFlow<TtsCapability> = container.speechOutput.capability

    val audioRoute: StateFlow<com.darksh3ep.whisperer.domain.audio.AudioRoute> = container.audioRoutes.route

    private val _model = MutableStateFlow<ModelFileInfo?>(null)
    /** null while the first check is still running. */
    val model: StateFlow<ModelFileInfo?> = _model.asStateFlow()

    private val _asr = MutableStateFlow(container.recognizer.availability())
    val asr: StateFlow<AsrAvailability> = _asr.asStateFlow()

    private val _whisper = MutableStateFlow<WhisperInfo?>(null)
    /** null while the first check is still running. */
    val whisper: StateFlow<WhisperInfo?> = _whisper.asStateFlow()

    private val _packs = MutableStateFlow<List<VoicePack>>(emptyList())
    val packs: StateFlow<List<VoicePack>> = _packs.asStateFlow()

    val importState: StateFlow<ImportState> = container.modelImporter.state

    val llmRuntime: Boolean get() = InferenceRuntime.INTEGRATED
    val whisperRuntime: Boolean get() = WhisperNative.isAvailable
    val packRuntime: Boolean get() = PackTtsRuntime.isAvailable

    init {
        viewModelScope.launch {
            container.modelImporter.state.collect { if (it is ImportState.Done) refresh() }
        }
    }

    fun refresh() {
        container.speechOutput.refreshCapability()
        _asr.value = container.recognizer.availability()
        viewModelScope.launch {
            _model.value = withContext(Dispatchers.IO) { container.modelLocator.locate() }
            _whisper.value = withContext(Dispatchers.IO) {
                val file = container.modelStore.whisperFile()
                WhisperInfo(file?.name, file?.length() ?: 0L)
            }
            _packs.value = withContext(Dispatchers.IO) { container.modelStore.voicePacks() }
        }
    }

    fun importModel(kind: ModelKind, uri: Uri) = container.modelImporter.start(kind, uri)
    fun cancelImport() = container.modelImporter.cancel()
    fun dismissImport() = container.modelImporter.dismiss()

    fun removeModel(kind: ModelKind) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                when (kind) {
                    ModelKind.LLM -> container.modelStore.deleteLlm()
                    ModelKind.WHISPER -> container.modelStore.deleteWhisper()
                    ModelKind.VOICE_PACK -> Unit
                }
            }
            container.onModelsChanged(kind)
            refresh()
        }
    }

    fun removeVoicePack(id: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { container.modelStore.deleteVoicePack(id) }
            // If the deleted pack was selected, fall back to automatic.
            if (container.settings.value?.voiceName == "pack:$id") container.settingsRepository.setVoiceName(null)
            container.onModelsChanged(ModelKind.VOICE_PACK)
            refresh()
        }
    }

    /** True when Whisper (not Android's recognizer) will be used to listen. */
    fun whisperActive(): Boolean = container.whisperActive()
}

data class WhisperInfo(val fileName: String?, val sizeBytes: Long)

class SettingsViewModel(private val container: AppContainer) : ViewModel() {
    private val repo = container.settingsRepository
    val settings: StateFlow<AppSettings?> = container.settings

    val sessionActive: StateFlow<Boolean> = container.sessionController.state
        .map { it.sessionActive }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    fun setBackgroundSession(value: Boolean) { viewModelScope.launch { repo.setBackgroundSessionEnabled(value) } }
    fun setHistoryEnabled(value: Boolean) { viewModelScope.launch { repo.setHistoryEnabled(value) } }
    fun setHaptics(value: Boolean) { viewModelScope.launch { repo.setHapticsEnabled(value) } }
    fun setSpeechRate(value: Float) { viewModelScope.launch { repo.setSpeechRate(value) } }
    fun setVoiceName(value: String?) { viewModelScope.launch { repo.setVoiceName(value) } }
    fun completeOnboarding() { viewModelScope.launch { repo.setOnboardingComplete(true) } }

    fun voices(): List<VoiceOption> = container.speechOutput.voices()

    /** Speaks a fixed sample sentence with the selected offline voice. */
    fun testVoice(sample: String, onProblem: () -> Unit) {
        container.speechOutput.speak(sample, object : SpeechListener {
            override fun onDone() {}
            override fun onError(error: SpeechError) = onProblem()
        })
    }

    fun stopVoiceTest() = container.speechOutput.stop()

    fun showSampleCode(snippet: CodeSnippet) = container.sessionController.showCode(snippet)

    private val _history = MutableStateFlow<List<ConversationRecord>?>(null)
    val history: StateFlow<List<ConversationRecord>?> = _history.asStateFlow()

    fun loadHistory() {
        viewModelScope.launch { _history.value = container.historyStore.load() }
    }

    fun clearHistory() {
        viewModelScope.launch {
            container.historyStore.clear()
            _history.value = emptyList()
        }
    }

    override fun onCleared() {
        container.speechOutput.stop()
        super.onCleared()
    }
}

sealed interface PhraseTestResult {
    data object Listening : PhraseTestResult
    data object Unavailable : PhraseTestResult
    data object SessionBusy : PhraseTestResult
    data class Failed(val reason: RecognitionFailure) : PhraseTestResult
    data class WakeMatched(val heard: String, val phrase: String, val score: Double) : PhraseTestResult
    data class WakeNoMatch(val heard: String) : PhraseTestResult
    data class CommandMatchedThis(val heard: String, val score: Double) : PhraseTestResult
    data class CommandMatchedOther(val heard: String, val action: CommandAction) : PhraseTestResult
    data class CommandNoMatch(val heard: String) : PhraseTestResult
}

/** Editing and testing of the wake phrase and custom command phrases. */
class PhraseViewModel(private val container: AppContainer) : ViewModel() {
    private val repo = container.settingsRepository
    val settings: StateFlow<AppSettings?> = container.settings

    private val _test = MutableStateFlow<PhraseTestResult?>(null)
    val testResult: StateFlow<PhraseTestResult?> = _test.asStateFlow()
    private var testJob: Job? = null

    private fun lines(text: String): List<String> =
        text.lines().map { it.trim() }.filter { it.isNotEmpty() }

    // ---- wake phrase ----

    fun saveWake(phrase: String, aliasLines: String): PhraseCheck {
        val current = settings.value ?: return PhraseCheck.Empty
        val main = phrase.trim()
        if (main.isEmpty()) return PhraseCheck.Empty
        val aliases = lines(aliasLines)
        val check = PhraseValidator.checkAll(listOf(main) + aliases, PhraseOwner.Wake, current.wake, current.commands)
        if (check == PhraseCheck.Ok) {
            viewModelScope.launch { repo.setWake(WakePhraseConfig(current.wake.enabled, main, aliases)) }
        }
        return check
    }

    fun setWakeEnabled(enabled: Boolean) {
        val current = settings.value ?: return
        if (current.wake.phrase.isBlank()) return
        viewModelScope.launch { repo.setWake(current.wake.copy(enabled = enabled)) }
    }

    fun deleteWake() {
        viewModelScope.launch { repo.setWake(WakePhraseConfig()) }
        _test.value = null
    }

    fun testWake() {
        val wake = settings.value?.wake ?: return
        if (wake.allPhrases.isEmpty()) return
        runTest { heard ->
            val match = WakePhraseMatcher.match(heard, wake)
            if (match != null) {
                PhraseTestResult.WakeMatched(heard, match.phrase, match.score)
            } else {
                PhraseTestResult.WakeNoMatch(heard)
            }
        }
    }

    // ---- commands ----

    fun saveCommand(existing: VoiceCommand?, action: CommandAction, phraseLines: String): PhraseCheck {
        val current = settings.value ?: return PhraseCheck.Empty
        val phrases = lines(phraseLines)
        val owner = existing?.let { PhraseOwner.Command(it.id, it.action) }
        val check = PhraseValidator.checkAll(phrases, owner, current.wake, current.commands)
        if (check == PhraseCheck.Ok) {
            val updated = if (existing == null) {
                current.commands + VoiceCommand(VoiceCommand.newId(), action, phrases, true)
            } else {
                current.commands.map { if (it.id == existing.id) it.copy(phrases = phrases) else it }
            }
            viewModelScope.launch { repo.setCommands(updated) }
        }
        return check
    }

    fun setCommandEnabled(id: String, enabled: Boolean) {
        val current = settings.value ?: return
        val updated = current.commands.map { if (it.id == id) it.copy(enabled = enabled) else it }
        viewModelScope.launch { repo.setCommands(updated) }
    }

    fun deleteCommand(id: String) {
        val current = settings.value ?: return
        viewModelScope.launch { repo.setCommands(current.commands.filter { it.id != id }) }
    }

    fun restoreDefaultCommands() {
        viewModelScope.launch { repo.resetCommands() }
    }

    fun testCommand(target: VoiceCommand) {
        val commands = settings.value?.commands ?: return
        runTest { heard ->
            when (val outcome = container.commandMatcher.classify(heard, commands)) {
                is MatchOutcome.Matched ->
                    if (outcome.command.id == target.id) {
                        PhraseTestResult.CommandMatchedThis(heard, outcome.score)
                    } else {
                        PhraseTestResult.CommandMatchedOther(heard, outcome.command.action)
                    }
                else -> PhraseTestResult.CommandNoMatch(heard)
            }
        }
    }

    fun clearTest() {
        testJob?.cancel()
        _test.value = null
    }

    private fun runTest(describe: (String) -> PhraseTestResult) {
        testJob?.cancel()
        if (container.sessionController.state.value.sessionActive) {
            _test.value = PhraseTestResult.SessionBusy
            return
        }
        if (container.recognizer.availability() != AsrAvailability.AVAILABLE) {
            _test.value = PhraseTestResult.Unavailable
            return
        }
        _test.value = PhraseTestResult.Listening
        testJob = viewModelScope.launch {
            _test.value = when (val result = container.recognizer.listenOnce()) {
                is ListenResult.Heard -> describe(result.text)
                is ListenResult.Failed -> PhraseTestResult.Failed(result.reason)
            }
        }
    }

    override fun onCleared() {
        testJob?.cancel()
        super.onCleared()
    }
}
