package com.darksh3ep.whisperer.data.preferences

import com.darksh3ep.whisperer.domain.commands.CommandAction
import com.darksh3ep.whisperer.domain.commands.VoiceCommand
import com.darksh3ep.whisperer.domain.commands.WakePhraseConfig
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** JSON (de)serialisation for the structured settings stored in DataStore. */
object SettingsCodec {

    fun encodeCommands(commands: List<VoiceCommand>): String {
        val array = JSONArray()
        for (command in commands) {
            val phrases = JSONArray()
            command.phrases.forEach { phrases.put(it) }
            val item = JSONObject()
            item.put("id", command.id)
            item.put("action", command.action.name)
            item.put("enabled", command.enabled)
            item.put("phrases", phrases)
            array.put(item)
        }
        return array.toString()
    }

    /** Returns null when there is nothing valid stored (caller then uses the defaults). */
    fun decodeCommands(json: String?): List<VoiceCommand>? {
        if (json.isNullOrBlank()) return null
        return try {
            val array = JSONArray(json)
            val out = ArrayList<VoiceCommand>()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val action = try {
                    CommandAction.valueOf(item.getString("action"))
                } catch (e: IllegalArgumentException) {
                    continue
                }
                val phrases = ArrayList<String>()
                val phraseArray = item.getJSONArray("phrases")
                for (p in 0 until phraseArray.length()) phrases.add(phraseArray.getString(p))
                out.add(
                    VoiceCommand(
                        id = item.getString("id"),
                        action = action,
                        phrases = phrases,
                        enabled = item.optBoolean("enabled", true),
                    )
                )
            }
            out
        } catch (e: JSONException) {
            null
        }
    }

    fun encodeWake(config: WakePhraseConfig): String {
        val aliases = JSONArray()
        config.aliases.forEach { aliases.put(it) }
        val item = JSONObject()
        item.put("enabled", config.enabled)
        item.put("phrase", config.phrase)
        item.put("aliases", aliases)
        return item.toString()
    }

    fun decodeWake(json: String?): WakePhraseConfig {
        if (json.isNullOrBlank()) return WakePhraseConfig()
        return try {
            val item = JSONObject(json)
            val aliases = ArrayList<String>()
            val array = item.optJSONArray("aliases")
            if (array != null) {
                for (i in 0 until array.length()) aliases.add(array.getString(i))
            }
            WakePhraseConfig(
                enabled = item.optBoolean("enabled", false),
                phrase = item.optString("phrase", ""),
                aliases = aliases,
            )
        } catch (e: JSONException) {
            WakePhraseConfig()
        }
    }
}
