package com.darksh3ep.whisperer.session

/** Starts/stops the visible foreground microphone service for a user-started background session. */
interface SessionHost {
    /** Returns true only if the foreground service and its notification are really running. */
    fun startBackgroundSession(): Boolean
    fun stopBackgroundSession()
}

/** Settings the session needs, read at the moment each decision is made. */
data class SessionSettings(
    val commands: List<com.darksh3ep.whisperer.domain.commands.VoiceCommand>,
    val backgroundEnabled: Boolean,
    val historyEnabled: Boolean,
)
