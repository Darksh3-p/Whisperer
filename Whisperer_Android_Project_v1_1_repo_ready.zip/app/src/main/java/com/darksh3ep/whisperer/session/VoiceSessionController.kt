package com.darksh3ep.whisperer.session

import com.darksh3ep.whisperer.ai.llm.AssistantEngine
import com.darksh3ep.whisperer.ai.llm.AssistantResult
import com.darksh3ep.whisperer.ai.llm.ModelStatus
import com.darksh3ep.whisperer.ai.speechrecognition.AsrAvailability
import com.darksh3ep.whisperer.ai.speechrecognition.RecognitionCallbacks
import com.darksh3ep.whisperer.ai.speechrecognition.RecognitionFailure
import com.darksh3ep.whisperer.ai.speechrecognition.SpeechRecognizerProvider
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechError
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechListener
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechOutput
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsState
import com.darksh3ep.whisperer.audio.AudioSessionControl
import com.darksh3ep.whisperer.data.history.ConversationRecord
import com.darksh3ep.whisperer.data.history.HistoryStore
import com.darksh3ep.whisperer.domain.audio.AudioRoute
import com.darksh3ep.whisperer.domain.commands.CommandAction
import com.darksh3ep.whisperer.domain.commands.CommandMatcher
import com.darksh3ep.whisperer.domain.commands.MatchOutcome
import com.darksh3ep.whisperer.domain.conversation.ChatMessage
import com.darksh3ep.whisperer.domain.conversation.CodeBlockParser
import com.darksh3ep.whisperer.domain.conversation.CodeSnippet
import com.darksh3ep.whisperer.domain.conversation.Notice
import com.darksh3ep.whisperer.domain.conversation.Phase
import com.darksh3ep.whisperer.domain.conversation.SessionUiState
import com.darksh3ep.whisperer.domain.conversation.Speaker
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Owns one user-started voice session: listen -> think -> speak -> WAIT.
 *
 * Behaviour guarantees:
 *  - Turn-taking: after a response (or any failure) the controller goes idle and waits for the user.
 *    It never starts listening again on its own.
 *  - The microphone indicator ([SessionUiState.micActive]) is true only while the recognizer is capturing.
 *  - No fabricated answers: if the assistant engine cannot answer, a system notice is shown instead.
 *  - Everything here must be called on the main thread.
 */
class VoiceSessionController(
    private val scope: CoroutineScope,
    private val recognizer: SpeechRecognizerProvider,
    private val speech: SpeechOutput,
    private val assistant: AssistantEngine,
    private val audio: AudioSessionControl,
    private val host: SessionHost,
    private val history: HistoryStore,
    private val matcher: CommandMatcher,
    private val settings: () -> SessionSettings,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private val _state = MutableStateFlow(SessionUiState(audioRoute = audio.route.value))
    val state: StateFlow<SessionUiState> = _state.asStateFlow()

    private val _level = MutableStateFlow(0f)
    /** Microphone input level 0..1 for the waveform; 0 when not listening. */
    val inputLevel: StateFlow<Float> = _level.asStateFlow()

    private var assistantJob: Job? = null
    private var nextMessageId = 1L
    private var startedAt = 0L

    // ------------------------------------------------------------------ session lifecycle

    fun startSession() {
        if (_state.value.sessionActive) return
        val current = settings()
        nextMessageId = 1L
        startedAt = clock()
        audio.requestFocus { onAudioFocusLost() }

        var background = false
        var notice = Notice.NONE
        if (current.backgroundEnabled) {
            background = host.startBackgroundSession()
            if (!background) notice = Notice.BACKGROUND_UNAVAILABLE
        }
        // Load the model while the user is still speaking so the first answer is not delayed.
        scope.launch { assistant.warmUp() }
        _state.value = SessionUiState(
            sessionActive = true,
            backgroundActive = background,
            audioRoute = audio.route.value,
            notice = notice,
        )
    }

    /** Starts a session if needed and begins listening for one utterance. */
    fun startAndListen() {
        startSession()
        listen()
    }

    fun endSession() {
        val snapshot = _state.value
        if (!snapshot.sessionActive) return
        assistantJob?.cancel()
        assistantJob = null
        recognizer.cancel()
        speech.stop()
        audio.abandonFocus()
        host.stopBackgroundSession()
        _level.value = 0f

        val keep = snapshot.messages.filter { it.speaker != Speaker.SYSTEM }
        val save = keep.any { it.speaker == Speaker.USER } && settings().historyEnabled
        val record = ConversationRecord(
            id = "conv-$startedAt",
            startedAtMillis = startedAt,
            messages = keep,
        )
        _state.value = SessionUiState(audioRoute = snapshot.audioRoute)
        if (save) scope.launch { history.append(record) }
    }

    /**
     * The app left the foreground. Without a visible foreground-service session the microphone must
     * not stay in use, so the session ends. A background session started by the user keeps running.
     */
    fun onAppBackgrounded() {
        val snapshot = _state.value
        if (snapshot.sessionActive && !snapshot.backgroundActive) endSession()
    }

    // ------------------------------------------------------------------ user actions

    /** The orb / notification "Talk" action. */
    fun tapToTalk() {
        if (!_state.value.sessionActive) startSession()
        when (_state.value.phase) {
            Phase.IDLE -> listen()
            Phase.LISTENING -> recognizer.stopListening()
            Phase.SPEAKING, Phase.SPEECH_PAUSED, Phase.THINKING -> interrupt()
        }
    }

    /** Stop speaking (or thinking) right now and listen. */
    fun interrupt() {
        val phase = _state.value.phase
        if (phase == Phase.LISTENING || !_state.value.sessionActive) return
        speech.stop()
        assistantJob?.cancel()
        assistantJob = null
        _state.update { it.copy(phase = Phase.IDLE, notice = Notice.NONE) }
        listen()
        if (_state.value.phase == Phase.LISTENING) setNotice(Notice.INTERRUPTED)
    }

    fun pauseSpeech() {
        if (_state.value.phase == Phase.SPEAKING && speech.pause()) {
            _state.update { it.copy(phase = Phase.SPEECH_PAUSED) }
        }
    }

    fun resumeSpeech() {
        if (_state.value.phase == Phase.SPEECH_PAUSED) {
            speech.resume()
            _state.update { it.copy(phase = Phase.SPEAKING) }
        }
    }

    fun setMuted(muted: Boolean) {
        if (muted) {
            if (_state.value.phase == Phase.LISTENING) recognizer.cancel()
            _level.value = 0f
            _state.update {
                it.copy(
                    micMuted = true,
                    micActive = false,
                    partialTranscript = "",
                    phase = if (it.phase == Phase.LISTENING) Phase.IDLE else it.phase,
                )
            }
        } else {
            _state.update { it.copy(micMuted = false, notice = Notice.NONE) }
        }
    }

    fun clearNotice() = setNotice(Notice.NONE)

    fun showCode(snippet: CodeSnippet?) = _state.update { it.copy(codeSnippet = snippet) }

    // ------------------------------------------------------------------ platform events

    fun onRouteChanged(route: AudioRoute) {
        val previous = _state.value.audioRoute
        _state.update { it.copy(audioRoute = route) }
        if (_state.value.sessionActive && previous.isExternal && !route.isExternal) {
            setNotice(Notice.ROUTE_DISCONNECTED)
        }
    }

    private fun onAudioFocusLost() {
        if (!_state.value.sessionActive) return
        recognizer.cancel()
        speech.stop()
        assistantJob?.cancel()
        assistantJob = null
        _level.value = 0f
        _state.update {
            it.copy(
                phase = Phase.IDLE,
                micActive = false,
                partialTranscript = "",
                notice = Notice.AUDIO_INTERRUPTED,
            )
        }
    }

    // ------------------------------------------------------------------ listening

    private fun listen() {
        val snapshot = _state.value
        if (!snapshot.sessionActive) return
        if (snapshot.micMuted) {
            setNotice(Notice.MIC_MUTED)
            return
        }
        if (recognizer.availability() != AsrAvailability.AVAILABLE) {
            _state.update { it.copy(phase = Phase.IDLE, micActive = false, notice = Notice.ASR_UNAVAILABLE) }
            return
        }
        _state.update {
            it.copy(
                phase = Phase.LISTENING,
                micActive = true,
                partialTranscript = "",
                // Keep the "background session couldn't start" explanation visible; clear other transient notices.
                notice = if (it.notice == Notice.BACKGROUND_UNAVAILABLE) it.notice else Notice.NONE,
            )
        }
        recognizer.start(callbacks)
    }

    private val callbacks = object : RecognitionCallbacks {
        override fun onLevel(level: Float) {
            if (_state.value.phase == Phase.LISTENING) _level.value = level
        }

        override fun onPartial(text: String) {
            if (_state.value.phase == Phase.LISTENING) _state.update { it.copy(partialTranscript = text) }
        }

        override fun onFinal(text: String, confidence: Float?) {
            if (_state.value.phase != Phase.LISTENING) return
            _level.value = 0f
            handleUtterance(text, confidence)
        }

        override fun onFailure(reason: RecognitionFailure) {
            if (_state.value.phase != Phase.LISTENING) return
            _level.value = 0f
            val notice = when (reason) {
                RecognitionFailure.PERMISSION -> Notice.MIC_PERMISSION_NEEDED
                RecognitionFailure.UNAVAILABLE -> Notice.ASR_UNAVAILABLE
                else -> Notice.RECOGNITION_FAILED
            }
            // Wait for the user: never restart listening automatically.
            _state.update {
                it.copy(phase = Phase.IDLE, micActive = false, partialTranscript = "", notice = notice)
            }
        }
    }

    // ------------------------------------------------------------------ understanding

    private fun handleUtterance(text: String, confidence: Float?) {
        val clean = text.trim()
        if (clean.isEmpty()) {
            _state.update {
                it.copy(phase = Phase.IDLE, micActive = false, notice = Notice.RECOGNITION_FAILED)
            }
            return
        }
        appendMessage(Speaker.USER, clean)
        _state.update { it.copy(micActive = false, partialTranscript = "", notice = Notice.NONE) }

        when (val outcome = matcher.match(clean, settings().commands, confidence)) {
            is MatchOutcome.Matched -> runCommand(outcome.command.action)
            is MatchOutcome.Suppressed -> _state.update { it.copy(phase = Phase.IDLE) }
            is MatchOutcome.Ambiguous,
            MatchOutcome.NoMatch -> requestAssistant(clean)
        }
    }

    private fun runCommand(action: CommandAction) {
        when (action) {
            CommandAction.STOP -> {
                speech.stop()
                assistantJob?.cancel()
                assistantJob = null
                _state.update { it.copy(phase = Phase.IDLE) }
            }
            CommandAction.END_SESSION -> endSession()
            CommandAction.REPEAT -> {
                val last = _state.value.messages.lastOrNull { it.speaker == Speaker.ASSISTANT }
                if (last == null) {
                    appendSystem(Notice.NOTHING_TO_REPEAT)
                    _state.update { it.copy(phase = Phase.IDLE) }
                } else {
                    speak(CodeBlockParser.spokenText(last.text))
                }
            }
            CommandAction.CONTINUE -> requestAssistant(PROMPT_CONTINUE)
            CommandAction.EXPLAIN_DIFFERENTLY -> requestAssistant(PROMPT_EXPLAIN_DIFFERENTLY)
            CommandAction.SLOWER_SIMPLER -> requestAssistant(PROMPT_SLOWER_SIMPLER)
            CommandAction.CHECK_CODE -> requestAssistant(PROMPT_CHECK_CODE)
        }
    }

    // ------------------------------------------------------------------ assistant

    private fun requestAssistant(request: String) {
        _state.update { it.copy(phase = Phase.THINKING, notice = Notice.NONE) }
        val context = _state.value.messages.filter { it.speaker != Speaker.SYSTEM }
        assistantJob?.cancel()
        assistantJob = scope.launch {
            val result = try {
                assistant.respond(context, request)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AssistantResult.Failed
            }
            if (_state.value.phase != Phase.THINKING) return@launch
            when (result) {
                is AssistantResult.Reply -> deliverReply(result.text)
                is AssistantResult.Unavailable -> {
                    val notice = when (result.status) {
                        ModelStatus.NOT_INSTALLED -> Notice.MODEL_NOT_INSTALLED
                        ModelStatus.INVALID_FILE -> Notice.MODEL_LOAD_FAILED
                        ModelStatus.RUNTIME_UNAVAILABLE -> Notice.MODEL_RUNTIME_UNAVAILABLE
                        ModelStatus.READY -> Notice.GENERIC_ERROR
                    }
                    appendSystem(notice)
                    _state.update { it.copy(phase = Phase.IDLE) }
                }
                AssistantResult.Failed -> {
                    appendSystem(Notice.GENERIC_ERROR)
                    _state.update { it.copy(phase = Phase.IDLE) }
                }
            }
        }
    }

    private fun deliverReply(text: String) {
        appendMessage(Speaker.ASSISTANT, text)
        val snippet = CodeBlockParser.parse(text).firstOrNull()
        if (snippet != null) _state.update { it.copy(codeSnippet = snippet) }
        speak(CodeBlockParser.spokenText(text))
    }

    // ------------------------------------------------------------------ speaking

    private fun speak(text: String) {
        if (text.isBlank()) {
            _state.update { it.copy(phase = Phase.IDLE) }
            return
        }
        if (speech.capability.value.state != TtsState.OFFLINE_AVAILABLE) {
            // No offline voice: show the text only. Whisperer never falls back to a network voice.
            _state.update { it.copy(phase = Phase.IDLE, notice = Notice.NO_VOICE) }
            return
        }
        _state.update { it.copy(phase = Phase.SPEAKING, notice = Notice.NONE) }
        speech.speak(text, object : SpeechListener {
            override fun onDone() {
                // Wait for the user after speaking; do not auto-continue.
                if (_state.value.phase == Phase.SPEAKING) _state.update { it.copy(phase = Phase.IDLE) }
            }

            override fun onError(error: SpeechError) {
                val notice = if (error == SpeechError.NO_VOICE) Notice.NO_VOICE else Notice.TTS_FAILED
                if (_state.value.phase == Phase.SPEAKING || _state.value.phase == Phase.SPEECH_PAUSED) {
                    _state.update { it.copy(phase = Phase.IDLE, notice = notice) }
                }
            }
        })
    }

    // ------------------------------------------------------------------ helpers

    private fun appendMessage(speaker: Speaker, text: String, notice: Notice = Notice.NONE) {
        val message = ChatMessage(nextMessageId++, speaker, text, clock(), notice)
        _state.update { it.copy(messages = it.messages + message) }
    }

    private fun appendSystem(notice: Notice) = appendMessage(Speaker.SYSTEM, "", notice)

    private fun setNotice(notice: Notice) = _state.update { it.copy(notice = notice) }

    companion object {
        // Fixed English instructions sent to the assistant engine when a session command needs the model.
        const val PROMPT_CONTINUE = "Please continue."
        const val PROMPT_EXPLAIN_DIFFERENTLY = "Please explain that again in a different way."
        const val PROMPT_SLOWER_SIMPLER = "Please explain that more slowly and more simply."
        const val PROMPT_CHECK_CODE = "Please review the code you just showed."
    }
}
