package com.darksh3ep.whisperer.ai.speechrecognition

import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

enum class AsrAvailability {
    AVAILABLE,
    /** Android 13+ is required for the on-device recognizer API used by this build. */
    OS_TOO_OLD,
    /** No on-device recognition service is installed/enabled on this device. */
    NO_ON_DEVICE_ENGINE,
}

enum class RecognitionFailure { NO_SPEECH, PERMISSION, BUSY, UNAVAILABLE, OTHER }

interface RecognitionCallbacks {
    fun onListening() {}
    fun onLevel(level: Float) {}
    fun onPartial(text: String) {}
    fun onFinal(text: String, confidence: Float?)
    fun onFailure(reason: RecognitionFailure)
}

/**
 * Provider interface for speech recognition. The implementation in this build uses Android's
 * ON-DEVICE recognizer only, so microphone audio is never sent to an online recognition service.
 * A Whisper Tiny implementation could be added behind this interface later.
 * All methods must be called from the main thread.
 */
interface SpeechRecognizerProvider {
    fun availability(): AsrAvailability
    fun start(callbacks: RecognitionCallbacks)
    /** Finish capturing now and deliver what was heard so far. */
    fun stopListening()
    /** Abort without delivering a result. */
    fun cancel()
    fun destroy()
}

sealed interface ListenResult {
    data class Heard(val text: String, val confidence: Float?) : ListenResult
    data class Failed(val reason: RecognitionFailure) : ListenResult
}

/** Listen for exactly one utterance (used by the wake/command/consent tests). */
suspend fun SpeechRecognizerProvider.listenOnce(): ListenResult =
    suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { cancel() }
        start(object : RecognitionCallbacks {
            override fun onFinal(text: String, confidence: Float?) {
                if (continuation.isActive) continuation.resume(ListenResult.Heard(text, confidence))
            }

            override fun onFailure(reason: RecognitionFailure) {
                if (continuation.isActive) continuation.resume(ListenResult.Failed(reason))
            }
        })
    }
