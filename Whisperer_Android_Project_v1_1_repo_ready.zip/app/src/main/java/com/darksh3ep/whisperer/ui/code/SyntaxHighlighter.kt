package com.darksh3ep.whisperer.ui.code

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import com.darksh3ep.whisperer.ui.theme.Amber
import com.darksh3ep.whisperer.ui.theme.Lavender
import com.darksh3ep.whisperer.ui.theme.Teal
import com.darksh3ep.whisperer.ui.theme.TextTertiary

/**
 * Small, language-agnostic highlighter (keywords, strings, comments, numbers) for the code panel.
 * It only colours text for reading; it does not parse or run anything.
 */
object SyntaxHighlighter {
    private val keywords = setOf(
        "def", "class", "return", "if", "else", "elif", "for", "while", "in", "import", "from", "as",
        "try", "except", "finally", "with", "fun", "val", "var", "when", "object", "interface",
        "public", "private", "protected", "static", "final", "void", "int", "long", "float", "double",
        "boolean", "new", "this", "null", "true", "false", "None", "True", "False", "function",
        "const", "let", "await", "async", "lambda", "break", "continue", "throw", "throws", "catch",
        "switch", "case", "default", "package", "extends", "implements", "is", "not", "and", "or",
    )

    /** Languages where '#' starts a comment. A '#' is not treated as a comment when the language is unknown. */
    private val hashCommentLanguages = setOf(
        "python", "py", "bash", "sh", "shell", "zsh", "yaml", "yml", "ruby", "rb", "r", "toml",
    )

    fun highlight(code: String, language: String?): AnnotatedString {
        val hashComments = language?.lowercase() in hashCommentLanguages
        val slashComments = !hashComments
        return buildAnnotatedString {
            var i = 0
            val n = code.length
            while (i < n) {
                val ch = code[i]
                if ((hashComments && ch == '#') ||
                    (slashComments && ch == '/' && i + 1 < n && code[i + 1] == '/')
                ) {
                    val newline = code.indexOf('\n', i)
                    val end = if (newline < 0) n else newline
                    withStyle(SpanStyle(color = TextTertiary)) { append(code.substring(i, end)) }
                    i = end
                } else if (ch == '"' || ch == '\'') {
                    var j = i + 1
                    while (j < n && code[j] != ch && code[j] != '\n') {
                        if (code[j] == '\\' && j + 1 < n) j++
                        j++
                    }
                    val end = if (j < n && code[j] == ch) j + 1 else j
                    withStyle(SpanStyle(color = Teal)) { append(code.substring(i, end)) }
                    i = end
                } else if (ch.isDigit()) {
                    var j = i
                    while (j < n && (code[j].isLetterOrDigit() || code[j] == '.')) j++
                    withStyle(SpanStyle(color = Amber)) { append(code.substring(i, j)) }
                    i = j
                } else if (ch.isLetter() || ch == '_') {
                    var j = i
                    while (j < n && (code[j].isLetterOrDigit() || code[j] == '_')) j++
                    val word = code.substring(i, j)
                    if (word in keywords) {
                        withStyle(SpanStyle(color = Lavender)) { append(word) }
                    } else {
                        append(word)
                    }
                    i = j
                } else {
                    append(ch)
                    i++
                }
            }
        }
    }
}
