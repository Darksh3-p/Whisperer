package com.darksh3ep.whisperer.ui.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.data.models.ImportError
import com.darksh3ep.whisperer.data.models.ImportState
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.StatusLine
import com.darksh3ep.whisperer.ui.components.Tone
import java.util.Locale

/** Opens Android's own file picker (no storage permission) and reports the chosen file. */
@Composable
fun rememberFilePicker(onPicked: (Uri) -> Unit): () -> Unit {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onPicked(uri)
    }
    return { launcher.launch(arrayOf("*/*")) }
}

fun formatSize(bytes: Long): String = when {
    bytes >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    bytes >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    bytes > 0 -> String.format(Locale.US, "%.0f KB", bytes / 1024.0)
    else -> "0 KB"
}

@StringRes
fun importErrorText(error: ImportError): Int = when (error) {
    ImportError.CANNOT_READ -> R.string.import_err_cannot_read
    ImportError.NOT_A_GGUF_MODEL -> R.string.import_err_not_gguf
    ImportError.NOT_A_WHISPER_MODEL -> R.string.import_err_not_whisper
    ImportError.GGUF_IN_WHISPER_SLOT -> R.string.import_err_gguf_in_whisper
    ImportError.WHISPER_IN_LLM_SLOT -> R.string.import_err_whisper_in_llm
    ImportError.NOT_AN_ARCHIVE -> R.string.import_err_not_archive
    ImportError.PACK_INCOMPLETE -> R.string.import_err_pack_incomplete
    ImportError.PACK_UNSUPPORTED -> R.string.import_err_pack_unsupported
    ImportError.NOT_ENOUGH_SPACE -> R.string.import_err_space
    ImportError.FAILED -> R.string.import_err_failed
}

/** Progress / result of the current import. Draws nothing while idle. */
@Composable
fun ImportStatusCard(state: ImportState, onCancel: () -> Unit, onDismiss: () -> Unit) {
    when (state) {
        ImportState.Idle -> Unit
        is ImportState.Working -> SectionCard {
            val label = if (state.extracting) R.string.import_unpacking else R.string.import_working
            StatusLine(stringResource(label, state.name), Tone.NEUTRAL)
            if (state.totalBytes > 0) {
                LinearProgressIndicator(
                    progress = { (state.doneBytes.toFloat() / state.totalBytes.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                )
                BodyText("${formatSize(state.doneBytes)} / ${formatSize(state.totalBytes)}")
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            BodyText(stringResource(R.string.import_keep_open))
            AppButton(stringResource(R.string.import_cancel), onCancel, kind = ButtonKind.SECONDARY)
        }
        is ImportState.Done -> SectionCard {
            StatusLine(stringResource(R.string.import_done, state.name), Tone.OK)
            AppButton(stringResource(R.string.import_ok), onDismiss, kind = ButtonKind.SECONDARY)
        }
        is ImportState.Failed -> SectionCard {
            StatusLine(stringResource(importErrorText(state.error)), Tone.ERROR)
            AppButton(stringResource(R.string.import_ok), onDismiss, kind = ButtonKind.SECONDARY)
        }
    }
}
