package com.darksh3ep.whisperer.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.darksh3ep.whisperer.MainActivity
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.WhispererApp

/**
 * Foreground service (type "microphone") that exists only while the user has an active voice session
 * with "Background voice session" enabled. It shows a persistent notification with Talk and Stop actions.
 *
 * It is NOT sticky: if Android kills the process, nothing silently restarts microphone use.
 */
class VoiceSessionService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val controller = (application as WhispererApp).container.sessionController
        when (intent?.action) {
            ACTION_STOP -> {
                controller.endSession()
                stopForegroundAndSelf()
                return START_NOT_STICKY
            }
            ACTION_TALK -> {
                promoteToForeground()
                controller.tapToTalk()
                return START_NOT_STICKY
            }
            else -> promoteToForeground()
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        (application as WhispererApp).container.sessionController.endSession()
        stopForegroundAndSelf()
        super.onTaskRemoved(rootIntent)
    }

    private fun promoteToForeground() {
        ensureChannel(this)
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopForegroundAndSelf() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this,
            REQUEST_OPEN,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val talk = PendingIntent.getService(
            this,
            REQUEST_TALK,
            Intent(this, VoiceSessionService::class.java).setAction(ACTION_TALK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this,
            REQUEST_STOP,
            Intent(this, VoiceSessionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, getString(R.string.notification_action_talk), talk)
            .addAction(0, getString(R.string.notification_action_stop), stop)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.darksh3ep.whisperer.action.STOP"
        const val ACTION_TALK = "com.darksh3ep.whisperer.action.TALK"
        private const val CHANNEL_ID = "voice_session"
        private const val NOTIFICATION_ID = 1001
        private const val REQUEST_OPEN = 1
        private const val REQUEST_TALK = 2
        private const val REQUEST_STOP = 3

        private fun ensureChannel(context: Context) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    context.getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW,
                )
                channel.description = context.getString(R.string.notification_channel_description)
                manager.createNotificationChannel(channel)
            }
        }
    }
}
