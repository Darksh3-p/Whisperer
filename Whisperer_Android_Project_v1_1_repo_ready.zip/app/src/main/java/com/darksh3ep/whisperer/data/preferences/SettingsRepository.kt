package com.darksh3ep.whisperer.data.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.darksh3ep.whisperer.domain.commands.DefaultCommands
import com.darksh3ep.whisperer.domain.commands.VoiceCommand
import com.darksh3ep.whisperer.domain.commands.WakePhraseConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

/** Persists user settings (app-private DataStore). */
class SettingsRepository(private val store: DataStore<Preferences>) {

    private object Keys {
        val onboardingComplete = booleanPreferencesKey("onboarding_complete")
        val backgroundSession = booleanPreferencesKey("background_session_enabled")
        val historyEnabled = booleanPreferencesKey("history_enabled")
        val haptics = booleanPreferencesKey("haptics_enabled")
        val speechRate = floatPreferencesKey("speech_rate")
        val voiceName = stringPreferencesKey("voice_name")
        val wake = stringPreferencesKey("wake_phrase_json")
        val commands = stringPreferencesKey("commands_json")
    }

    val settings: Flow<AppSettings> = store.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs ->
            AppSettings(
                onboardingComplete = prefs[Keys.onboardingComplete] ?: false,
                backgroundSessionEnabled = prefs[Keys.backgroundSession] ?: false,
                historyEnabled = prefs[Keys.historyEnabled] ?: true,
                hapticsEnabled = prefs[Keys.haptics] ?: false,
                speechRate = prefs[Keys.speechRate] ?: 1.0f,
                voiceName = prefs[Keys.voiceName],
                wake = SettingsCodec.decodeWake(prefs[Keys.wake]),
                commands = SettingsCodec.decodeCommands(prefs[Keys.commands]) ?: DefaultCommands.all(),
            )
        }

    suspend fun setOnboardingComplete(value: Boolean) {
        store.edit { it[Keys.onboardingComplete] = value }
    }

    suspend fun setBackgroundSessionEnabled(value: Boolean) {
        store.edit { it[Keys.backgroundSession] = value }
    }

    suspend fun setHistoryEnabled(value: Boolean) {
        store.edit { it[Keys.historyEnabled] = value }
    }

    suspend fun setHapticsEnabled(value: Boolean) {
        store.edit { it[Keys.haptics] = value }
    }

    suspend fun setSpeechRate(value: Float) {
        store.edit { it[Keys.speechRate] = value }
    }

    /** Null means "automatic". */
    suspend fun setVoiceName(value: String?) {
        store.edit {
            if (value == null) it.remove(Keys.voiceName) else it[Keys.voiceName] = value
        }
    }

    suspend fun setWake(config: WakePhraseConfig) {
        store.edit { it[Keys.wake] = SettingsCodec.encodeWake(config) }
    }

    suspend fun setCommands(commands: List<VoiceCommand>) {
        store.edit { it[Keys.commands] = SettingsCodec.encodeCommands(commands) }
    }

    suspend fun resetCommands() {
        store.edit { it.remove(Keys.commands) }
    }
}
