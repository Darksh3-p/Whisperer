package com.darksh3ep.whisperer.ui

import androidx.annotation.StringRes
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ai.speechrecognition.AsrAvailability
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsState
import com.darksh3ep.whisperer.domain.audio.AudioRoute
import com.darksh3ep.whisperer.domain.commands.CommandAction
import com.darksh3ep.whisperer.domain.conversation.Notice
import com.darksh3ep.whisperer.ui.components.Tone

/** Maps session notices to the approved copy in strings.xml. Null means "show nothing". */
@StringRes
fun noticeText(notice: Notice): Int? = when (notice) {
    Notice.NONE -> null
    Notice.MODEL_NOT_INSTALLED -> R.string.model_status_not_installed
    Notice.MODEL_RUNTIME_UNAVAILABLE -> R.string.model_status_runtime_unavailable
    Notice.MODEL_LOAD_FAILED -> R.string.error_model_failure
    Notice.ASR_UNAVAILABLE -> R.string.asr_status_unavailable
    Notice.MIC_PERMISSION_NEEDED -> R.string.status_mic_permission_needed
    Notice.RECOGNITION_FAILED -> R.string.error_recognition_failure
    Notice.TTS_FAILED -> R.string.error_speech_output_failure
    Notice.NO_VOICE -> R.string.error_no_voice
    Notice.ROUTE_DISCONNECTED -> R.string.error_audio_disconnected
    Notice.GENERIC_ERROR -> R.string.conversation_error
    Notice.INTERRUPTED -> R.string.conversation_interrupted
    Notice.NOTHING_TO_REPEAT -> R.string.notice_nothing_to_repeat
    Notice.MIC_MUTED -> R.string.notice_mic_muted
    Notice.AUDIO_INTERRUPTED -> R.string.notice_audio_interrupted
    Notice.BACKGROUND_UNAVAILABLE -> R.string.notice_background_unavailable
}

fun noticeTone(notice: Notice): Tone = when (notice) {
    Notice.NONE -> Tone.NEUTRAL
    Notice.INTERRUPTED -> Tone.OK
    Notice.MODEL_NOT_INSTALLED,
    Notice.MODEL_RUNTIME_UNAVAILABLE,
    Notice.ASR_UNAVAILABLE,
    Notice.NO_VOICE,
    Notice.ROUTE_DISCONNECTED,
    Notice.NOTHING_TO_REPEAT,
    Notice.MIC_MUTED,
    Notice.AUDIO_INTERRUPTED,
    Notice.BACKGROUND_UNAVAILABLE,
    Notice.MIC_PERMISSION_NEEDED -> Tone.WARNING
    Notice.MODEL_LOAD_FAILED,
    Notice.RECOGNITION_FAILED,
    Notice.TTS_FAILED,
    Notice.GENERIC_ERROR -> Tone.ERROR
}

@StringRes
fun routeLabel(route: AudioRoute): Int = when (route) {
    AudioRoute.PHONE_SPEAKER -> R.string.route_phone_speaker
    AudioRoute.WIRED_HEADSET -> R.string.route_wired_headset
    AudioRoute.USB_AUDIO -> R.string.route_usb_audio
    AudioRoute.BLUETOOTH -> R.string.route_bluetooth
    AudioRoute.UNKNOWN -> R.string.route_unknown
}

@StringRes
fun actionLabel(action: CommandAction): Int = when (action) {
    CommandAction.STOP -> R.string.action_cmd_stop
    CommandAction.REPEAT -> R.string.action_cmd_repeat
    CommandAction.CONTINUE -> R.string.action_cmd_continue
    CommandAction.EXPLAIN_DIFFERENTLY -> R.string.action_cmd_explain_differently
    CommandAction.SLOWER_SIMPLER -> R.string.action_cmd_slower_simpler
    CommandAction.CHECK_CODE -> R.string.action_cmd_check_code
    CommandAction.END_SESSION -> R.string.action_cmd_end_session
}

@StringRes
fun asrStatusText(availability: AsrAvailability): Int = when (availability) {
    AsrAvailability.AVAILABLE -> R.string.asr_status_ready
    AsrAvailability.OS_TOO_OLD,
    AsrAvailability.NO_ON_DEVICE_ENGINE -> R.string.asr_status_unavailable
}

@StringRes
fun asrDetailText(availability: AsrAvailability): Int? = when (availability) {
    AsrAvailability.AVAILABLE -> R.string.asr_detail_ready
    AsrAvailability.OS_TOO_OLD -> R.string.asr_detail_os_too_old
    AsrAvailability.NO_ON_DEVICE_ENGINE -> R.string.asr_detail_no_engine
}

@StringRes
fun ttsStatusText(state: TtsState): Int = when (state) {
    TtsState.INITIALIZING -> R.string.tts_status_checking
    TtsState.OFFLINE_AVAILABLE -> R.string.tts_status_available
    TtsState.NO_OFFLINE_VOICE,
    TtsState.ENGINE_UNAVAILABLE -> R.string.tts_status_unavailable
}
