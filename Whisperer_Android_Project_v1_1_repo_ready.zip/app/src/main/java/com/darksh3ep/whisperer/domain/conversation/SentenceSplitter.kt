package com.darksh3ep.whisperer.domain.conversation

/** Splits text into short chunks so speech can be paused/resumed at sentence boundaries. */
object SentenceSplitter {
    private val boundary = Regex("(?<=[.!?])\\s+|(?<=[\u3002\uFF01\uFF1F])\\s*|\\n+")

    fun split(text: String, maxLength: Int = 300): List<String> {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return emptyList()
        val out = ArrayList<String>()
        for (part in cleaned.split(boundary)) {
            var rest = part.trim()
            while (rest.length > maxLength) {
                var cut = rest.lastIndexOf(' ', maxLength)
                if (cut <= 0) cut = maxLength
                out.add(rest.substring(0, cut).trim())
                rest = rest.substring(cut).trim()
            }
            if (rest.isNotEmpty()) out.add(rest)
        }
        return out
    }
}
