package com.darksh3ep.whisperer.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsState
import com.darksh3ep.whisperer.data.models.ImportState
import com.darksh3ep.whisperer.data.models.ModelKind
import com.darksh3ep.whisperer.ui.SettingsViewModel
import com.darksh3ep.whisperer.ui.StatusViewModel
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.NoticeCard
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.StatusLine
import com.darksh3ep.whisperer.ui.components.SwitchRow
import com.darksh3ep.whisperer.ui.components.Tone
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.routeLabel
import com.darksh3ep.whisperer.ui.theme.TextPrimary
import com.darksh3ep.whisperer.ui.ttsStatusText

@Composable
fun VoiceSettingsScreen(onBack: () -> Unit) {
    val vm: SettingsViewModel = containerViewModel { SettingsViewModel(it) }
    val status: StatusViewModel = containerViewModel { StatusViewModel(it) }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val tts by status.tts.collectAsStateWithLifecycle()
    val route by status.audioRoute.collectAsStateWithLifecycle()
    val sessionActive by vm.sessionActive.collectAsStateWithLifecycle()
    val packs by status.packs.collectAsStateWithLifecycle()
    val importState by status.importState.collectAsStateWithLifecycle()
    val pickPack = rememberFilePicker { status.importModel(ModelKind.VOICE_PACK, it) }
    var playbackProblem by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { status.refresh() }

    val storedRate = settings?.speechRate ?: 1.0f
    var rate by remember(storedRate) { mutableFloatStateOf(storedRate) }
    val sample = stringResource(R.string.voice_test_sample)

    ScreenScaffold(title = stringResource(R.string.settings_voice_title), onBack = onBack) {
        BodyText(stringResource(R.string.settings_voice_desc))

        SectionCard(title = stringResource(R.string.voice_speech_output)) {
            val tone = if (tts.state == TtsState.OFFLINE_AVAILABLE) Tone.OK else Tone.WARNING
            StatusLine(stringResource(ttsStatusText(tts.state)), tone)
            if (tts.state == TtsState.NO_OFFLINE_VOICE || tts.state == TtsState.ENGINE_UNAVAILABLE) {
                BodyText(stringResource(R.string.error_no_voice))
                BodyText(stringResource(R.string.tts_install_hint))
            }
            BodyText(stringResource(R.string.tts_offline_only_note))
        }

        ImportStatusCard(importState, onCancel = { status.cancelImport() }, onDismiss = { status.dismissImport() })
        VoicePackSection(
            packs = packs,
            runtimeAvailable = status.packRuntime,
            busy = importState is ImportState.Working,
            onImport = pickPack,
            onRemove = { status.removeVoicePack(it) },
        )

        if (tts.state == TtsState.OFFLINE_AVAILABLE) {
            SectionCard(title = stringResource(R.string.voice_selection)) {
                val voices = vm.voices()
                val selected = settings?.voiceName
                VoiceChoiceRow(
                    label = stringResource(R.string.voice_automatic),
                    selected = selected == null || voices.none { it.name == selected },
                    onSelect = { vm.setVoiceName(null) },
                )
                voices.forEach { voice ->
                    VoiceChoiceRow(
                        label = voice.label,
                        selected = voice.name == selected,
                        onSelect = { vm.setVoiceName(voice.name) },
                    )
                }
            }
        }

        SectionCard(title = stringResource(R.string.voice_rate)) {
            Text(
                text = stringResource(R.string.voice_rate_value, rate),
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary,
            )
            Slider(
                value = rate,
                onValueChange = { rate = it },
                onValueChangeFinished = { vm.setSpeechRate(rate) },
                valueRange = 0.5f..2.0f,
                steps = 5,
                modifier = Modifier.heightIn(min = 48.dp),
            )
        }

        SectionCard(title = stringResource(R.string.action_audio_output)) {
            StatusLine(stringResource(R.string.audio_current, stringResource(routeLabel(route))), Tone.NEUTRAL)
            BodyText(stringResource(R.string.audio_settings_hint))
        }

        SectionCard {
            SwitchRow(
                title = stringResource(R.string.haptics_title),
                subtitle = stringResource(R.string.haptics_desc),
                checked = settings?.hapticsEnabled == true,
                onCheckedChange = { vm.setHaptics(it) },
            )
        }

        if (playbackProblem) {
            NoticeCard(stringResource(R.string.error_speech_output_failure), Tone.ERROR)
        }
        if (sessionActive) {
            BodyText(stringResource(R.string.test_session_busy))
        }
        AppButton(
            text = stringResource(R.string.voice_test),
            onClick = {
                playbackProblem = false
                vm.testVoice(sample) { playbackProblem = true }
            },
            enabled = tts.state == TtsState.OFFLINE_AVAILABLE && !sessionActive,
        )
    }
}

@Composable
private fun VoiceChoiceRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onSelect)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
    }
}
