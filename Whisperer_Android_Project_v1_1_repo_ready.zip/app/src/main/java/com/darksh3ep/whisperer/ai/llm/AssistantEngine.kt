package com.darksh3ep.whisperer.ai.llm

import com.darksh3ep.whisperer.domain.conversation.ChatMessage

/**
 * State of the local assistant model.
 *
 * READY means a valid GGUF file exists AND the native runtime is present (see [InferenceRuntime]).
 * If the model later fails to load, replies come back as [AssistantResult.Unavailable] with INVALID_FILE.
 */
enum class ModelStatus {
    NOT_INSTALLED,
    INVALID_FILE,
    RUNTIME_UNAVAILABLE,
    READY,
}

sealed interface AssistantResult {
    data class Reply(val text: String) : AssistantResult
    data class Unavailable(val status: ModelStatus) : AssistantResult
    data object Failed : AssistantResult
}

/** Provider interface for the language model. A real llama.cpp-backed engine would implement this. */
interface AssistantEngine {
    suspend fun status(): ModelStatus

    /**
     * Generate a reply for [request] given the conversation so far.
     * Implementations must never fabricate output: if no model can run, return [AssistantResult.Unavailable].
     */
    suspend fun respond(history: List<ChatMessage>, request: String): AssistantResult

    /** Load the model ahead of the first question so the first answer is faster. Safe to call repeatedly. */
    suspend fun warmUp() {}

    /** Free the model's memory (it is reloaded on demand). */
    suspend fun release() {}
}

/**
 * Run-time truth about this build: true only when the llama.cpp native library is really part of the APK
 * and loads. A build made without the GitHub workflow's native step reports false and never claims READY.
 */
object InferenceRuntime {
    val INTEGRATED: Boolean get() = LlamaNative.isAvailable
}
