package com.darksh3ep.whisperer.ai.speechrecognition

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Speech recognition through Android's on-device recognizer (API 33+).
 * It deliberately does NOT fall back to the default (possibly online) recognizer:
 * Whisperer must not send microphone audio to an online service without explicit, informed consent.
 */
class AndroidOnDeviceRecognizer(context: Context) : SpeechRecognizerProvider {
    private val appContext = context.applicationContext
    private var recognizer: SpeechRecognizer? = null
    private var callbacks: RecognitionCallbacks? = null

    override fun availability(): AsrAvailability {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return AsrAvailability.OS_TOO_OLD
        return if (SpeechRecognizer.isOnDeviceRecognitionAvailable(appContext)) {
            AsrAvailability.AVAILABLE
        } else {
            AsrAvailability.NO_ON_DEVICE_ENGINE
        }
    }

    override fun start(callbacks: RecognitionCallbacks) {
        cancelInternal()
        if (availability() != AsrAvailability.AVAILABLE) {
            callbacks.onFailure(RecognitionFailure.UNAVAILABLE)
            return
        }
        try {
            val instance = recognizer ?: SpeechRecognizer.createOnDeviceSpeechRecognizer(appContext).also {
                recognizer = it
            }
            this.callbacks = callbacks
            instance.setRecognitionListener(listener)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
            }
            instance.startListening(intent)
        } catch (e: Exception) {
            this.callbacks = null
            callbacks.onFailure(RecognitionFailure.OTHER)
        }
    }

    override fun stopListening() {
        try {
            recognizer?.stopListening()
        } catch (e: Exception) {
            // Nothing useful to do; the session will time out or be cancelled.
        }
    }

    override fun cancel() = cancelInternal()

    override fun destroy() {
        cancelInternal()
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
            // Ignore: already released.
        }
        recognizer = null
    }

    private fun cancelInternal() {
        callbacks = null
        try {
            recognizer?.cancel()
        } catch (e: Exception) {
            // Ignore: nothing to cancel.
        }
    }

    private fun deliverFailure(reason: RecognitionFailure) {
        val target = callbacks
        callbacks = null
        target?.onFailure(reason)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            callbacks?.onListening()
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            callbacks?.onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            val reason = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> RecognitionFailure.NO_SPEECH
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> RecognitionFailure.PERMISSION
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> RecognitionFailure.BUSY
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER,
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> RecognitionFailure.UNAVAILABLE
                else -> RecognitionFailure.OTHER
            }
            deliverFailure(reason)
        }

        override fun onResults(results: Bundle?) {
            val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = texts?.firstOrNull().orEmpty()
            val confidence = results
                ?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                ?.firstOrNull()
                ?.takeIf { it >= 0f }
            val target = callbacks
            callbacks = null
            if (text.isBlank()) {
                target?.onFailure(RecognitionFailure.NO_SPEECH)
            } else {
                target?.onFinal(text, confidence)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val texts = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = texts?.firstOrNull().orEmpty()
            if (text.isNotBlank()) callbacks?.onPartial(text)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
