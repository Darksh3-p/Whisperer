package com.darksh3ep.whisperer.data.models

import java.io.File

enum class ModelKind { LLM, WHISPER, VOICE_PACK }

/** Which kind of file a header belongs to. */
enum class FileMagic { GGUF, WHISPER_GGML, ZIP, BZIP2, GZIP, UNKNOWN;

    companion object {
        fun detect(head: ByteArray, length: Int = head.size): FileMagic {
            fun b(i: Int): Int = if (i < length) head[i].toInt() and 0xFF else -1
            return when {
                b(0) == 'G'.code && b(1) == 'G'.code && b(2) == 'U'.code && b(3) == 'F'.code -> GGUF
                // whisper.cpp "ggml" magic 0x67676d6c stored little-endian => bytes 6c 6d 67 67
                b(0) == 0x6c && b(1) == 0x6d && b(2) == 0x67 && b(3) == 0x67 -> WHISPER_GGML
                b(0) == 'P'.code && b(1) == 'K'.code && b(2) == 3 && b(3) == 4 -> ZIP
                b(0) == 'B'.code && b(1) == 'Z'.code && b(2) == 'h'.code -> BZIP2
                b(0) == 0x1f && b(1) == 0x8b -> GZIP
                else -> UNKNOWN
            }
        }
    }
}

/** Type of an installed voice pack (decides how the sherpa-onnx engine is configured). */
enum class VoicePackType { VITS, KOKORO, UNSUPPORTED }

data class VoicePack(
    val id: String,
    val dir: File,
    val type: VoicePackType,
    val modelFile: File,
    val tokensFile: File,
    val dataDir: File?,
    val lexiconFile: File?,
    val voicesFile: File?,
    val dictDir: File?,
) {
    val displayName: String get() = id
}

/**
 * Where imported models live (all in app-specific storage; no storage permission is required):
 *   models/llm/      *.gguf          assistant model
 *   models/whisper/  *.bin           Whisper (ggml) speech-recognition model
 *   voices/<id>/     voice packs     sherpa-onnx TTS packs (tokens.txt + .onnx [+ espeak-ng-data])
 */
class ModelStore(private val root: File) {
    val llmDir = File(root, "models/llm")
    val whisperDir = File(root, "models/whisper")
    val voicesDir = File(root, "voices")

    fun ensureDirs() {
        llmDir.mkdirs(); whisperDir.mkdirs(); voicesDir.mkdirs()
    }

    fun whisperFile(): File? = whisperDir
        .listFiles { f -> f.isFile && f.name.endsWith(".bin", ignoreCase = true) }
        ?.sortedBy { it.name }
        ?.firstOrNull { readMagic(it) == FileMagic.WHISPER_GGML }

    fun deleteLlm() = deleteAll(llmDir) { it.isFile }
    fun deleteWhisper() = deleteAll(whisperDir) { it.isFile }

    fun voicePacks(): List<VoicePack> = voicesDir
        .listFiles { f -> f.isDirectory && !f.name.startsWith(".") }
        ?.sortedBy { it.name }
        ?.mapNotNull { PackLayout.describe(it) }
        .orEmpty()

    fun deleteVoicePack(id: String): Boolean {
        val dir = File(voicesDir, id)
        return dir.parentFile == voicesDir && dir.isDirectory && dir.deleteRecursively()
    }

    /** Removes interrupted imports (".part" files and ".tmp-*" extraction folders). */
    fun cleanLeftovers() {
        listOf(llmDir, whisperDir).forEach { d ->
            d.listFiles { f -> f.name.endsWith(".part") }?.forEach { it.delete() }
        }
        voicesDir.listFiles { f -> f.name.startsWith(".tmp-") }?.forEach { it.deleteRecursively() }
    }

    private fun deleteAll(dir: File, filter: (File) -> Boolean) {
        dir.listFiles()?.filter(filter)?.forEach { it.delete() }
    }

    companion object {
        fun readMagic(file: File): FileMagic = try {
            file.inputStream().use { input ->
                val head = ByteArray(8)
                val n = input.read(head)
                FileMagic.detect(head, maxOf(n, 0))
            }
        } catch (e: Exception) {
            FileMagic.UNKNOWN
        }
    }
}

/** Understands the on-disk layout of a sherpa-onnx TTS voice pack. Pure file logic; unit-tested. */
object PackLayout {
    /** Finds the folder (the extraction root itself or a sub-folder up to 3 levels deep) that holds tokens.txt. */
    fun findRoot(extracted: File): File? {
        fun search(dir: File, depth: Int): File? {
            if (File(dir, "tokens.txt").isFile) return dir
            if (depth == 0) return null
            val children = dir.listFiles { f -> f.isDirectory && f.name != "espeak-ng-data" }?.sortedBy { it.name }.orEmpty()
            for (child in children) search(child, depth - 1)?.let { return it }
            return null
        }
        return search(extracted, 3)
    }

    fun describe(dir: File): VoicePack? {
        val tokens = File(dir, "tokens.txt").takeIf { it.isFile } ?: return null
        val onnx = dir.listFiles { f -> f.isFile && f.name.endsWith(".onnx", ignoreCase = true) }
            ?.sortedWith(compareBy({ it.name.contains("int8", ignoreCase = true) }, { it.name }))
            .orEmpty()
        val model = onnx.firstOrNull() ?: return null
        val voices = File(dir, "voices.bin").takeIf { it.isFile }
        val names = dir.listFiles()?.map { it.name.lowercase() }.orEmpty()
        val twoStage = names.any { it.contains("hifigan") || it.contains("vocos") } || onnx.size > 1 && voices == null &&
            onnx.none { it.name.contains("int8", ignoreCase = true) }
        val type = when {
            voices != null -> VoicePackType.KOKORO
            twoStage -> VoicePackType.UNSUPPORTED
            else -> VoicePackType.VITS
        }
        return VoicePack(
            id = dir.name,
            dir = dir,
            type = type,
            modelFile = model,
            tokensFile = tokens,
            dataDir = File(dir, "espeak-ng-data").takeIf { it.isDirectory },
            lexiconFile = File(dir, "lexicon.txt").takeIf { it.isFile },
            voicesFile = voices,
            dictDir = File(dir, "dict").takeIf { it.isDirectory },
        )
    }

    /** Safe single-folder name for a pack ("vits-piper-en_US-amy-low.tar.bz2" -> "vits-piper-en_US-amy-low"). */
    fun sanitizeId(raw: String): String {
        var name = raw.substringAfterLast('/').trim()
        for (suffix in listOf(".tar.bz2", ".tar.gz", ".tbz2", ".tgz", ".tar", ".zip")) {
            if (name.endsWith(suffix, ignoreCase = true)) { name = name.dropLast(suffix.length); break }
        }
        name = name.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('.', '_', '-')
        return name.ifEmpty { "voice-pack" }.take(80)
    }
}
