package com.darksh3ep.whisperer.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.connectivity.SystemPanels

/** Live "is this permission granted" state; re-checked every time the screen resumes. */
@Composable
fun rememberPermissionGranted(permission: String): State<Boolean> {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val granted = remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED)
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                granted.value =
                    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    return granted
}

/**
 * Microphone permission flow, shown only in context:
 * 1) our own explanation ("Let Whisperer hear you"), 2) the official Android dialog,
 * 3) if denied, the "Microphone access is off" explanation with an action that really opens app settings.
 *
 * [content] receives a function to call when the user wants to use the microphone; [onGranted] runs
 * once permission is available.
 */
@Composable
fun MicPermissionHost(
    onGranted: () -> Unit,
    explainFirst: Boolean = true,
    content: @Composable (requestMic: () -> Unit) -> Unit,
) {
    val context = LocalContext.current
    val latestOnGranted by rememberUpdatedState(onGranted)
    var showExplanation by remember { mutableStateOf(false) }
    var showDenied by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) latestOnGranted() else showDenied = true
    }

    content {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
            latestOnGranted()
        } else if (explainFirst) {
            showExplanation = true
        } else {
            launcher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    if (showExplanation) {
        AlertDialog(
            onDismissRequest = { showExplanation = false },
            title = { Text(stringResource(R.string.mic_permission_title)) },
            text = { Text(stringResource(R.string.mic_permission_body)) },
            confirmButton = {
                TextButton(onClick = {
                    showExplanation = false
                    launcher.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text(stringResource(R.string.action_continue)) }
            },
            dismissButton = {
                TextButton(onClick = { showExplanation = false }) { Text(stringResource(R.string.action_not_now)) }
            },
        )
    }
    if (showDenied) {
        AlertDialog(
            onDismissRequest = { showDenied = false },
            title = { Text(stringResource(R.string.mic_denied_title)) },
            text = { Text(stringResource(R.string.mic_denied_body)) },
            confirmButton = {
                TextButton(onClick = {
                    showDenied = false
                    SystemPanels.openAppSettings(context)
                }) { Text(stringResource(R.string.action_open_app_settings)) }
            },
            dismissButton = {
                TextButton(onClick = { showDenied = false }) { Text(stringResource(R.string.action_not_now)) }
            },
        )
    }
}

/**
 * Returns a handler for the "Background voice session" switch. Turning it ON requires notifications
 * (Android 13+ runtime permission), because background microphone use must show a persistent notification.
 */
@Composable
fun rememberBackgroundSessionToggle(
    onChange: (Boolean) -> Unit,
    onNotificationsUnavailable: () -> Unit,
): (Boolean) -> Unit {
    val context = LocalContext.current
    val latestChange by rememberUpdatedState(onChange)
    val latestDenied by rememberUpdatedState(onNotificationsUnavailable)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            latestChange(true)
        } else {
            latestDenied()
        }
    }
    return { enable ->
        if (!enable) {
            latestChange(false)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            latestDenied()
        } else {
            latestChange(true)
        }
    }
}
