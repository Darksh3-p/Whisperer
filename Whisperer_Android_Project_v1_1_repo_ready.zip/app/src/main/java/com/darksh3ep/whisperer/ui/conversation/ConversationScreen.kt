package com.darksh3ep.whisperer.ui.conversation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.domain.conversation.ChatMessage
import com.darksh3ep.whisperer.domain.conversation.Phase
import com.darksh3ep.whisperer.domain.conversation.SessionUiState
import com.darksh3ep.whisperer.domain.conversation.Speaker
import com.darksh3ep.whisperer.ui.SessionViewModel
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.NoticeCard
import com.darksh3ep.whisperer.ui.components.VoiceOrb
import com.darksh3ep.whisperer.ui.components.rememberHaptic
import com.darksh3ep.whisperer.ui.components.rememberReducedMotion
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.noticeText
import com.darksh3ep.whisperer.ui.noticeTone
import com.darksh3ep.whisperer.ui.routeLabel
import com.darksh3ep.whisperer.ui.theme.Lavender
import com.darksh3ep.whisperer.ui.theme.Midnight
import com.darksh3ep.whisperer.ui.theme.Surface1
import com.darksh3ep.whisperer.ui.theme.Surface2
import com.darksh3ep.whisperer.ui.theme.Teal
import com.darksh3ep.whisperer.ui.theme.TextPrimary
import com.darksh3ep.whisperer.ui.theme.TextSecondary
import com.darksh3ep.whisperer.ui.theme.TextTertiary

@Composable
fun ConversationScreen(
    onLeave: () -> Unit,
    onOpenCode: () -> Unit,
) {
    val session: SessionViewModel = containerViewModel { SessionViewModel(it) }
    val state by session.state.collectAsStateWithLifecycle()
    val level by session.level.collectAsStateWithLifecycle()
    val settings by session.settings.collectAsStateWithLifecycle()
    val haptic = rememberHaptic(settings?.hapticsEnabled == true)
    val reducedMotion = rememberReducedMotion()
    var showAudioDialog by remember { mutableStateOf(false) }

    // Back ends the conversation, so the microphone never stays on out of sight.
    BackHandler {
        session.endSession()
        onLeave()
    }
    // The session can also end from the notification's Stop action or because the app left the foreground.
    LaunchedEffect(state.sessionActive) {
        if (!state.sessionActive) onLeave()
    }

    val listState = rememberLazyListState()
    val hasPartial = state.phase == Phase.LISTENING && state.partialTranscript.isNotBlank()
    val itemCount = state.messages.size + if (hasPartial) 1 else 0
    LaunchedEffect(itemCount) {
        if (itemCount > 0) {
            if (reducedMotion) listState.scrollToItem(itemCount - 1) else listState.animateScrollToItem(itemCount - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Midnight)
            .safeDrawingPadding()
            .padding(horizontal = 20.dp),
    ) {
        // ---- top row: identity, session + microphone indicators, end ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    modifier = Modifier.semantics { heading() },
                )
                Text(
                    text = stringResource(R.string.session_active_indicator),
                    style = MaterialTheme.typography.labelMedium,
                    color = Teal,
                )
                Text(
                    text = stringResource(
                        if (state.micActive) R.string.mic_indicator_on else R.string.mic_indicator_off
                    ),
                    style = MaterialTheme.typography.labelMedium,
                    color = if (state.micActive) Teal else TextSecondary,
                    modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
                )
                if (state.backgroundActive) {
                    Text(
                        text = stringResource(R.string.session_background_indicator),
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                    )
                }
            }
            IconButton(
                onClick = {
                    session.endSession()
                    onLeave()
                },
                modifier = Modifier.size(48.dp),
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_close),
                    contentDescription = stringResource(R.string.action_end_conversation),
                    tint = TextPrimary,
                )
            }
        }

        // ---- orb and state ----
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            VoiceOrb(
                phase = state.phase,
                level = level,
                contentDescription = stringResource(R.string.conversation_orb_description),
                onClick = {
                    haptic()
                    session.tapToTalk()
                },
                size = 168.dp,
                muted = state.micMuted,
            )
            val (label, sub) = phaseTexts(state)
            Text(
                text = stringResource(label),
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
            )
            Text(
                text = stringResource(sub),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center,
            )
        }

        val noticeRes = noticeText(state.notice)
        if (noticeRes != null) {
            NoticeCard(
                text = stringResource(noticeRes),
                tone = noticeTone(state.notice),
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .semantics { liveRegion = LiveRegionMode.Polite },
            )
        }

        // ---- transcript (secondary to voice) ----
        Box(Modifier.weight(1f)) {
            if (state.messages.isEmpty() && !hasPartial) {
                Text(
                    text = stringResource(R.string.conversation_empty_transcript),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextTertiary,
                    modifier = Modifier.align(Alignment.Center),
                )
            } else {
                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(state.messages, key = { it.id }) { message -> MessageCard(message) }
                    if (hasPartial) {
                        item(key = "partial") {
                            PartialCard(state.partialTranscript)
                        }
                    }
                }
            }
        }

        if (state.codeSnippet != null) {
            Spacer(Modifier.height(8.dp))
            AppButton(
                text = stringResource(R.string.conversation_view_code),
                onClick = onOpenCode,
                kind = ButtonKind.SECONDARY,
            )
        }

        // ---- controls ----
        Spacer(Modifier.height(12.dp))
        val speechActive = state.phase == Phase.SPEAKING || state.phase == Phase.SPEECH_PAUSED
        val canInterrupt = speechActive || state.phase == Phase.THINKING
        val compact = LocalDensity.current.fontScale > 1.3f

        val muteButton: @Composable (Modifier) -> Unit = { modifier ->
            AppButton(
                text = stringResource(if (state.micMuted) R.string.action_unmute else R.string.action_mute),
                onClick = { session.setMuted(!state.micMuted) },
                modifier = modifier,
                kind = ButtonKind.SECONDARY,
            )
        }
        val interruptButton: @Composable (Modifier) -> Unit = { modifier ->
            AppButton(
                text = stringResource(R.string.action_interrupt),
                onClick = {
                    haptic()
                    session.interrupt()
                },
                modifier = modifier,
                enabled = canInterrupt,
            )
        }
        val endButton: @Composable (Modifier) -> Unit = { modifier ->
            AppButton(
                text = stringResource(R.string.action_end),
                onClick = {
                    session.endSession()
                    onLeave()
                },
                modifier = modifier,
                kind = ButtonKind.DANGER,
            )
        }

        if (compact) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                muteButton(Modifier)
                interruptButton(Modifier)
                endButton(Modifier)
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                muteButton(Modifier.weight(1f))
                interruptButton(Modifier.weight(1f))
                endButton(Modifier.weight(1f))
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            if (speechActive) {
                TextButton(
                    onClick = { if (state.phase == Phase.SPEAKING) session.pauseSpeech() else session.resumeSpeech() },
                    modifier = Modifier.height(48.dp),
                ) {
                    Text(
                        stringResource(if (state.phase == Phase.SPEAKING) R.string.action_pause else R.string.action_resume),
                        color = Lavender,
                    )
                }
            } else {
                Spacer(Modifier.width(1.dp))
            }
            TextButton(onClick = { showAudioDialog = true }, modifier = Modifier.height(48.dp)) {
                Text(
                    text = stringResource(R.string.audio_label, stringResource(routeLabel(state.audioRoute))),
                    color = TextSecondary,
                )
            }
        }
    }

    if (showAudioDialog) {
        AudioOutputDialog(session = session, state = state, onDismiss = { showAudioDialog = false })
    }
}

private fun phaseTexts(state: SessionUiState): Pair<Int, Int> = when (state.phase) {
    Phase.LISTENING -> R.string.state_listening to R.string.conversation_listening
    Phase.THINKING -> R.string.state_thinking to R.string.conversation_thinking
    Phase.SPEAKING -> R.string.state_speaking to R.string.conversation_speaking
    Phase.SPEECH_PAUSED -> R.string.state_paused to R.string.conversation_paused
    Phase.IDLE ->
        if (state.micMuted) R.string.state_muted to R.string.conversation_muted_hint
        else R.string.state_ready to R.string.conversation_idle_hint
}

@Composable
private fun MessageCard(message: ChatMessage) {
    val isUser = message.speaker == Speaker.USER
    val label = when (message.speaker) {
        Speaker.USER -> stringResource(R.string.speaker_you)
        Speaker.ASSISTANT -> stringResource(R.string.speaker_whisperer)
        Speaker.SYSTEM -> stringResource(R.string.speaker_status)
    }
    val body = if (message.speaker == Speaker.SYSTEM) {
        noticeText(message.notice)?.let { stringResource(it) }.orEmpty()
    } else {
        message.text
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = if (isUser) Surface1 else Surface2),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = Lavender)
            Text(body, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
        }
    }
}

@Composable
private fun PartialCard(text: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Surface1),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(stringResource(R.string.speaker_you), style = MaterialTheme.typography.labelSmall, color = Lavender)
            Text(
                text,
                style = MaterialTheme.typography.bodyLarge,
                color = TextSecondary,
                fontStyle = FontStyle.Italic,
            )
        }
    }
}

@Composable
private fun AudioOutputDialog(session: SessionViewModel, state: SessionUiState, onDismiss: () -> Unit) {
    val outputs = remember { session.audioOutputs() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.action_audio_output)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.audio_current, stringResource(routeLabel(state.audioRoute))),
                    color = TextPrimary,
                )
                if (outputs.isEmpty()) {
                    Text(stringResource(R.string.audio_automatic_only), color = TextSecondary)
                } else {
                    Text(stringResource(R.string.audio_best_effort), color = TextSecondary)
                    TextButton(
                        onClick = {
                            session.selectAudioOutput(null)
                            onDismiss()
                        },
                        modifier = Modifier.height(48.dp),
                    ) { Text(stringResource(R.string.audio_automatic)) }
                    outputs.forEach { option ->
                        TextButton(
                            onClick = {
                                session.selectAudioOutput(option.id)
                                onDismiss()
                            },
                            modifier = Modifier.height(48.dp),
                        ) {
                            Text(
                                text = stringResource(routeLabel(option.route)) +
                                    if (option.name.isNotBlank()) " \u00B7 " + option.name else "",
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) }
        },
    )
}
