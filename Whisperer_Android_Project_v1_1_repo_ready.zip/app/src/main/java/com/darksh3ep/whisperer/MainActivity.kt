package com.darksh3ep.whisperer

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.darksh3ep.whisperer.ui.WhispererRoot
import com.darksh3ep.whisperer.ui.theme.WhispererTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            WhispererTheme {
                WhispererRoot()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Without a visible foreground-service session, the microphone must not stay in use in the background.
        if (!isChangingConfigurations) {
            (application as WhispererApp).container.onAppBackgrounded()
        }
    }
}
