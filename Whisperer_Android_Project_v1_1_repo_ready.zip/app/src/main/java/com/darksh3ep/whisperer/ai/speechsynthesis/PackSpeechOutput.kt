package com.darksh3ep.whisperer.ai.speechsynthesis

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import com.darksh3ep.whisperer.data.models.ModelStore
import com.darksh3ep.whisperer.data.models.VoicePack
import com.darksh3ep.whisperer.data.models.VoicePackType
import com.darksh3ep.whisperer.domain.conversation.SentenceSplitter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

const val PACK_VOICE_PREFIX = "pack:"

/**
 * Speech output from imported neural voice packs. Sentence by sentence: synthesize, stream to an AudioTrack,
 * continue. Fully offline. Must be called from the main thread; synthesis runs on a worker thread.
 */
class PackSpeechOutput(private val store: ModelStore) : SpeechOutput {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "whisperer-tts").apply { isDaemon = true } }
    private val generation = AtomicInteger(0)

    private var packs: List<VoicePack> = emptyList()
    private var selectedId: String? = null
    private var rate = 1.0f

    @Volatile private var paused = false
    @Volatile private var track: AudioTrack? = null
    @Volatile private var speaking = false

    // Worker thread only.
    private var backend: PackTtsBackend? = null
    private var loadedId: String? = null

    private val _capability = MutableStateFlow(TtsCapability(TtsState.NO_OFFLINE_VOICE, 0))
    override val capability: StateFlow<TtsCapability> = _capability.asStateFlow()

    init {
        refreshCapability()
    }

    fun hasVoice(voiceName: String?): Boolean =
        voiceName != null && voiceName.startsWith(PACK_VOICE_PREFIX) &&
            packs.any { it.id == voiceName.removePrefix(PACK_VOICE_PREFIX) }

    override fun voices(): List<VoiceOption> =
        packs.map { VoiceOption(PACK_VOICE_PREFIX + it.id, "Voice pack \u00B7 ${it.id}") }

    override fun refreshCapability() {
        packs = store.voicePacks().filter { it.type != VoicePackType.UNSUPPORTED }
        _capability.value = if (PackTtsRuntime.isAvailable && packs.isNotEmpty()) {
            TtsCapability(TtsState.OFFLINE_AVAILABLE, packs.size)
        } else {
            TtsCapability(TtsState.NO_OFFLINE_VOICE, 0)
        }
    }

    override fun applySettings(rate: Float, voiceName: String?) {
        this.rate = rate
        selectedId = voiceName?.takeIf { it.startsWith(PACK_VOICE_PREFIX) }?.removePrefix(PACK_VOICE_PREFIX)
    }

    private fun currentPack(): VoicePack? = packs.firstOrNull { it.id == selectedId } ?: packs.firstOrNull()

    override fun speak(text: String, listener: SpeechListener) {
        val pack = currentPack()
        if (pack == null || !PackTtsRuntime.isAvailable) {
            main.post { listener.onError(SpeechError.NO_VOICE) }
            return
        }
        stopInternal()
        val chunks = SentenceSplitter.split(text)
        if (chunks.isEmpty()) {
            main.post { listener.onDone() }
            return
        }
        val gen = generation.incrementAndGet()
        paused = false
        speaking = true
        val speed = rate
        worker.execute { play(gen, pack, chunks, speed, listener) }
    }

    private fun current(gen: Int) = generation.get() == gen

    private fun play(gen: Int, pack: VoicePack, chunks: List<String>, speed: Float, listener: SpeechListener) {
        var audio: AudioTrack? = null
        try {
            if (backend == null) backend = PackTtsRuntime.create()
            val engine = backend
            if (engine == null) {
                fail(gen, listener, SpeechError.NO_VOICE)
                return
            }
            if (loadedId != pack.id) {
                loadedId = null
                if (!engine.load(pack)) {
                    fail(gen, listener, SpeechError.ENGINE_ERROR)
                    return
                }
                loadedId = pack.id
            }
            if (!current(gen)) return

            val sampleRate = engine.sampleRate
            val minBytes = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
            audio = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(maxOf(minBytes, sampleRate * 4)) // about one second
                .build()
            track = audio
            audio.play()

            var frames = 0L
            for (chunk in chunks) {
                if (!current(gen)) return
                val samples = engine.generate(chunk, speed)
                if (samples == null) {
                    fail(gen, listener, SpeechError.ENGINE_ERROR)
                    return
                }
                if (!current(gen)) return
                var offset = 0
                while (offset < samples.size) {
                    if (!current(gen)) return
                    val written = audio.write(samples, offset, samples.size - offset, AudioTrack.WRITE_BLOCKING)
                    if (written <= 0) {
                        if (!current(gen)) return
                        fail(gen, listener, SpeechError.ENGINE_ERROR)
                        return
                    }
                    offset += written
                }
                frames += samples.size
            }

            // Let the queued audio finish playing before reporting "done".
            audio.stop()
            val deadline = System.currentTimeMillis() + frames * 1000L / sampleRate + 2000L
            while (current(gen) && audio.playbackHeadPosition < frames && System.currentTimeMillis() < deadline) {
                Thread.sleep(40)
            }
            if (current(gen)) {
                speaking = false
                main.post { if (current(gen)) listener.onDone() }
            }
        } catch (t: Throwable) {
            if (current(gen)) fail(gen, listener, SpeechError.ENGINE_ERROR)
        } finally {
            try { audio?.release() } catch (e: Exception) { /* ignore */ }
            if (track === audio) track = null
        }
    }

    private fun fail(gen: Int, listener: SpeechListener, error: SpeechError) {
        speaking = false
        main.post { if (current(gen)) listener.onError(error) }
    }

    override fun stop() = stopInternal()

    private fun stopInternal() {
        generation.incrementAndGet()
        speaking = false
        paused = false
        val t = track
        if (t != null) {
            try { t.pause(); t.flush() } catch (e: Exception) { /* ignore */ }
        }
    }

    override fun pause(): Boolean {
        if (!speaking || paused) return false
        val t = track ?: return false
        return try {
            t.pause()
            paused = true
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun resume() {
        if (!paused) return
        paused = false
        try { track?.play() } catch (e: Exception) { /* ignore */ }
    }

    override fun shutdown() {
        stopInternal()
        worker.execute {
            backend?.release()
            backend = null
            loadedId = null
        }
    }
}
