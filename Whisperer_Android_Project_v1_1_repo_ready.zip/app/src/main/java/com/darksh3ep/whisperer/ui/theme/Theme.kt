package com.darksh3ep.whisperer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val WhispererColors = darkColorScheme(
    primary = Violet,
    // Navy on violet is 5.3:1 (white on violet is only 3.5:1), so filled buttons use navy text.
    onPrimary = Midnight,
    primaryContainer = Surface2,
    onPrimaryContainer = TextPrimary,
    secondary = Lavender,
    onSecondary = Midnight,
    tertiary = Teal,
    onTertiary = Midnight,
    background = Midnight,
    onBackground = TextPrimary,
    surface = Surface1,
    onSurface = TextPrimary,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextSecondary,
    surfaceContainer = Surface1,
    surfaceContainerHigh = Surface2,
    surfaceContainerHighest = Surface2,
    outline = Outline,
    outlineVariant = Outline,
    error = Coral,
    onError = Midnight,
    errorContainer = Color(0xFF4A2530),
    onErrorContainer = TextPrimary,
)

/** Whisperer is dark by default (see UI_DESIGN_SPEC.md); the palette does not follow the system light theme. */
@Composable
fun WhispererTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = WhispererColors,
        typography = WhispererTypography,
        content = content,
    )
}
