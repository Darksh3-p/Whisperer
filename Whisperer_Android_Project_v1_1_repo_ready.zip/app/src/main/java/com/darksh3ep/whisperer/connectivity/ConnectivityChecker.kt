package com.darksh3ep.whisperer.connectivity

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/** What Android currently reports about internet connectivity. Read-only; never changes anything. */
data class NetworkSnapshot(
    val connected: Boolean,
    val viaWifi: Boolean,
    val viaMobileData: Boolean,
) {
    companion object {
        val OFFLINE = NetworkSnapshot(connected = false, viaWifi = false, viaMobileData = false)
    }
}

class ConnectivityChecker(context: Context) {
    private val manager = context.applicationContext
        .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    fun current(): NetworkSnapshot = snapshotOf(manager.activeNetwork)

    fun observe(): Flow<NetworkSnapshot> = callbackFlow {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(snapshotOf(network))
            }

            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                trySend(snapshotOf(network))
            }

            override fun onLost(network: Network) {
                trySend(current())
            }
        }
        trySend(current())
        manager.registerDefaultNetworkCallback(callback)
        awaitClose { manager.unregisterNetworkCallback(callback) }
    }.distinctUntilChanged()

    private fun snapshotOf(network: Network?): NetworkSnapshot {
        if (network == null) return NetworkSnapshot.OFFLINE
        val caps = manager.getNetworkCapabilities(network) ?: return NetworkSnapshot.OFFLINE
        val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        return NetworkSnapshot(
            connected = hasInternet,
            viaWifi = hasInternet && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI),
            viaMobileData = hasInternet && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR),
        )
    }
}
