package com.darksh3ep.whisperer.ui.consent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind
import com.darksh3ep.whisperer.domain.connectivity.ConsentState
import com.darksh3ep.whisperer.domain.connectivity.DeclineReason
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.NoticeCard
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.StatusLine
import com.darksh3ep.whisperer.ui.components.Tone
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.settings.networkStatusText
import com.darksh3ep.whisperer.ui.theme.TextPrimary
import com.darksh3ep.whisperer.ui.theme.TextSecondary

/**
 * Screen 5: connectivity consent. The assistant asks ALOUD; only a clear spoken "yes" enables
 * "Continue to Android settings". Whisperer never changes Wi-Fi or mobile data itself.
 */
@Composable
fun ConsentScreen(kind: ConnectionKind, onDone: () -> Unit) {
    val vm: ConsentViewModel = containerViewModel { ConsentViewModel(it, kind) }
    val state by vm.state.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    val listening by vm.listening.collectAsStateWithLifecycle()
    val blocked by vm.blocked.collectAsStateWithLifecycle()
    val snapshot by vm.snapshot.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val prompt = stringResource(
        when (kind) {
            ConnectionKind.WIFI -> R.string.consent_prompt_wifi
            ConnectionKind.MOBILE_DATA -> R.string.consent_prompt_mobile
            ConnectionKind.ANY -> R.string.consent_prompt_any
        }
    )
    val reprompt = stringResource(R.string.consent_reprompt, prompt)

    LaunchedEffect(Unit) { vm.begin(prompt, reprompt) }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { vm.onPaused() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.onResumed() }
    BackHandler {
        vm.onNotNow()
        onDone()
    }

    val title = stringResource(
        when (kind) {
            ConnectionKind.WIFI -> R.string.consent_title_wifi
            ConnectionKind.MOBILE_DATA -> R.string.consent_title_mobile
            ConnectionKind.ANY -> R.string.consent_title_any
        }
    )

    ScreenScaffold(
        title = title,
        onBack = {
            vm.onNotNow()
            onDone()
        },
    ) {
        Text(
            text = prompt,
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
        )

        SectionCard(title = stringResource(R.string.consent_why_title)) {
            BodyText(stringResource(R.string.consent_why_body))
            if (kind != ConnectionKind.WIFI) {
                BodyText(stringResource(R.string.network_mobile_data_note))
            }
        }

        val block = blocked
        if (block != null) {
            NoticeCard(
                text = stringResource(
                    when (block) {
                        ConsentBlock.NO_SPEECH_OUTPUT -> R.string.consent_blocked_no_speech_output
                        ConsentBlock.NO_RECOGNITION -> R.string.consent_blocked_no_recognition
                        ConsentBlock.SESSION_ACTIVE -> R.string.consent_blocked_session
                        ConsentBlock.SPEECH_FAILED -> R.string.error_speech_output_failure
                        ConsentBlock.PANEL_FAILED -> R.string.consent_panel_failed
                    }
                ),
                tone = Tone.WARNING,
            )
        }

        when (val current = state) {
            is ConsentState.AwaitingApproval -> {
                SectionCard {
                    when {
                        speaking -> StatusLine(stringResource(R.string.consent_state_asking), Tone.NEUTRAL)
                        listening -> StatusLine(stringResource(R.string.consent_state_listening), Tone.OK)
                        else -> StatusLine(stringResource(R.string.consent_state_waiting), Tone.NEUTRAL)
                    }
                    if (current.unclearCount > 0) {
                        BodyText(stringResource(R.string.consent_state_unclear))
                    }
                }
            }
            is ConsentState.Approved -> {
                NoticeCard(stringResource(R.string.consent_state_approved), Tone.OK)
            }
            is ConsentState.Declined -> {
                NoticeCard(
                    text = stringResource(
                        if (current.reason == DeclineReason.USER_DECLINED) R.string.consent_state_declined
                        else R.string.consent_state_not_understood
                    ),
                    tone = Tone.NEUTRAL,
                )
            }
            is ConsentState.AwaitingSystemPanel -> {
                NoticeCard(stringResource(R.string.consent_state_in_panel), Tone.NEUTRAL)
            }
            is ConsentState.Verified -> {
                SectionCard {
                    Text(
                        text = stringResource(R.string.consent_status_after, networkStatusText(snapshot)),
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                    )
                    if (!snapshot.connected) BodyText(stringResource(R.string.consent_state_not_connected_hint))
                }
            }
            ConsentState.Idle -> Unit
        }

        val canContinue = state is ConsentState.Approved
        val finished = state is ConsentState.Declined || state is ConsentState.Verified || blocked != null

        if (state is ConsentState.AwaitingSystemPanel) {
            AppButton(
                text = stringResource(R.string.consent_check_connection),
                onClick = { vm.verify() },
            )
        } else if (state is ConsentState.Verified) {
            AppButton(
                text = stringResource(R.string.consent_check_again),
                onClick = { vm.recheck() },
                kind = ButtonKind.SECONDARY,
            )
        } else if (!finished || state is ConsentState.Approved) {
            AppButton(
                text = stringResource(R.string.consent_continue),
                onClick = { vm.onContinueToAndroid(context) },
                enabled = canContinue,
            )
        }

        if (finished && state !is ConsentState.Approved && state !is ConsentState.AwaitingSystemPanel) {
            AppButton(
                text = stringResource(R.string.action_done),
                onClick = onDone,
            )
        } else if (state !is ConsentState.AwaitingSystemPanel) {
            AppButton(
                text = stringResource(R.string.action_not_now),
                onClick = {
                    vm.onNotNow()
                    onDone()
                },
                kind = ButtonKind.SECONDARY,
            )
        }

        Text(
            text = stringResource(R.string.consent_footer),
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
        )
    }
}
