package com.darksh3ep.whisperer.ai.speechrecognition

import java.io.File
import kotlin.math.max
import kotlin.math.sqrt

/** Pure helpers for the Whisper recognizer (kept free of Android types so they are unit-testable). */
object WhisperText {
    private val bracketed = Regex("""[\[(][^\])]{0,40}[\])]""")

    /**
     * Whisper writes non-speech as "[BLANK_AUDIO]", "(silence)", "[Music]" and similar.
     * Those are removed; an empty result means "nothing was said".
     */
    fun clean(raw: String): String =
        raw.replace(bracketed, " ").replace(Regex("\\s+"), " ").trim()

    /** English-only models (…en.bin) must be told "en"; multilingual models get the device language. */
    fun languageFor(modelFile: File, deviceLanguage: String): String {
        val name = modelFile.name.lowercase()
        return if (Regex("""[.\-_]en([.\-_]|$)""").containsMatchIn(name)) "en" else deviceLanguage.ifBlank { "auto" }
    }
}

/**
 * Energy-based end-of-utterance detector fed with 30 ms frames of 16 kHz audio.
 * Speech starts after a few loud frames and ends after [endSilenceMs] of quiet. Nothing is sent anywhere;
 * this only decides when to stop recording.
 */
class UtteranceDetector(
    private val frameMs: Int = 30,
    private val endSilenceMs: Int = 1200,
    private val noSpeechTimeoutMs: Int = 8000,
    private val maxMs: Int = 45_000,
) {
    enum class Verdict { CONTINUE, END_OF_SPEECH, NO_SPEECH, TOO_LONG }

    private var elapsedMs = 0
    private var noiseFloor = -1.0
    private var loudFrames = 0
    private var quietMs = 0
    var speechStarted = false
        private set

    fun onFrame(rms: Double): Verdict {
        elapsedMs += frameMs
        // Learn the room noise during the first ~300 ms.
        if (elapsedMs <= 300) {
            noiseFloor = if (noiseFloor < 0) rms else (noiseFloor * 0.7 + rms * 0.3)
            return Verdict.CONTINUE
        }
        val threshold = max(noiseFloor * 3.0, 0.015)
        val loud = rms >= threshold
        if (!speechStarted) {
            loudFrames = if (loud) loudFrames + 1 else 0
            if (loudFrames >= 3) {
                speechStarted = true
                quietMs = 0
            } else if (elapsedMs >= noSpeechTimeoutMs) {
                return Verdict.NO_SPEECH
            }
        } else {
            quietMs = if (loud) 0 else quietMs + frameMs
            if (quietMs >= endSilenceMs) return Verdict.END_OF_SPEECH
        }
        return if (elapsedMs >= maxMs) Verdict.TOO_LONG else Verdict.CONTINUE
    }

    companion object {
        /** Root-mean-square level of 16-bit samples, 0.0 – 1.0. */
        fun rms(frame: ShortArray, count: Int): Double {
            if (count <= 0) return 0.0
            var sum = 0.0
            for (i in 0 until count) {
                val v = frame[i] / 32768.0
                sum += v * v
            }
            return sqrt(sum / count)
        }
    }
}
