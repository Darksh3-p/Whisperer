package com.darksh3ep.whisperer

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.darksh3ep.whisperer.ai.llm.AssistantEngine
import com.darksh3ep.whisperer.ai.llm.ModelLocator
import com.darksh3ep.whisperer.ai.llm.LlamaAssistantEngine
import com.darksh3ep.whisperer.ai.speechrecognition.AndroidOnDeviceRecognizer
import com.darksh3ep.whisperer.ai.speechrecognition.HybridRecognizer
import com.darksh3ep.whisperer.ai.speechrecognition.SpeechRecognizerProvider
import com.darksh3ep.whisperer.ai.speechrecognition.WhisperRecognizer
import com.darksh3ep.whisperer.ai.speechsynthesis.AndroidSpeechOutput
import com.darksh3ep.whisperer.ai.speechsynthesis.PackSpeechOutput
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechRouter
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechOutput
import com.darksh3ep.whisperer.ai.wake.UnavailableWakePhraseDetector
import com.darksh3ep.whisperer.ai.wake.WakePhraseDetector
import com.darksh3ep.whisperer.audio.AudioRouteManager
import com.darksh3ep.whisperer.connectivity.ConnectivityChecker
import com.darksh3ep.whisperer.data.history.FileHistoryStore
import com.darksh3ep.whisperer.data.models.ImportState
import com.darksh3ep.whisperer.data.models.ModelImporter
import com.darksh3ep.whisperer.data.models.ModelKind
import com.darksh3ep.whisperer.data.models.ModelStore
import com.darksh3ep.whisperer.data.history.HistoryStore
import com.darksh3ep.whisperer.data.preferences.AppSettings
import com.darksh3ep.whisperer.data.preferences.SettingsRepository
import com.darksh3ep.whisperer.domain.commands.CommandMatcher
import com.darksh3ep.whisperer.domain.commands.DefaultCommands
import com.darksh3ep.whisperer.service.AndroidSessionHost
import com.darksh3ep.whisperer.session.SessionSettings
import com.darksh3ep.whisperer.session.VoiceSessionController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "whisperer_settings")

/** Hand-wired dependencies (kept simple on purpose; no DI framework). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val settingsRepository = SettingsRepository(appContext.settingsDataStore)

    /** null until the first DataStore read completes. */
    val settings: StateFlow<AppSettings?> =
        settingsRepository.settings.stateIn(scope, SharingStarted.Eagerly, null)

    /** Imported models live in app-specific storage (no storage permission needed). */
    val modelStore = ModelStore(appContext.getExternalFilesDir(null) ?: appContext.filesDir).also {
        it.ensureDirs()
        it.cleanLeftovers()
    }
    val modelImporter = ModelImporter(appContext, modelStore, scope)

    val modelLocator = ModelLocator(modelStore.llmDir)
    val assistantEngine: AssistantEngine = LlamaAssistantEngine(modelLocator)
    val wakeDetector: WakePhraseDetector = UnavailableWakePhraseDetector

    val historyStore: HistoryStore = FileHistoryStore(File(appContext.filesDir, "history/conversations.json"))
    val connectivity = ConnectivityChecker(appContext)
    val commandMatcher = CommandMatcher()

    private val whisperRecognizer by lazy { WhisperRecognizer(appContext) { modelStore.whisperFile() } }
    private val hybridRecognizer by lazy { HybridRecognizer(whisperRecognizer, AndroidOnDeviceRecognizer(appContext)) }
    val recognizer: SpeechRecognizerProvider get() = hybridRecognizer

    /** True when a Whisper model is imported and the native runtime is present (Whisper is then used for listening). */
    fun whisperActive(): Boolean = whisperRecognizer.isReady()

    val speechOutput: SpeechOutput by lazy {
        SpeechRouter(AndroidSpeechOutput(appContext), PackSpeechOutput(modelStore), scope).also { output ->
            scope.launch {
                settings.filterNotNull().collect { output.applySettings(it.speechRate, it.voiceName) }
            }
        }
    }
    val audioRoutes: AudioRouteManager by lazy { AudioRouteManager(appContext) }

    private val sessionControllerLazy = lazy {
        VoiceSessionController(
            scope = scope,
            recognizer = recognizer,
            speech = speechOutput,
            assistant = assistantEngine,
            audio = audioRoutes,
            host = AndroidSessionHost(appContext),
            history = historyStore,
            matcher = commandMatcher,
            settings = {
                val current = settings.value
                if (current == null) {
                    SessionSettings(DefaultCommands.all(), backgroundEnabled = false, historyEnabled = true)
                } else {
                    SessionSettings(current.commands, current.backgroundSessionEnabled, current.historyEnabled)
                }
            },
        ).also { controller ->
            scope.launch { audioRoutes.route.collect { controller.onRouteChanged(it) } }
        }
    }
    val sessionController: VoiceSessionController get() = sessionControllerLazy.value

    init {
        scope.launch {
            modelImporter.state.collect { state -> if (state is ImportState.Done) onModelsChanged(state.kind) }
        }
    }

    /** A model file was added or removed: drop anything loaded from the old file so the new one is used. */
    fun onModelsChanged(kind: ModelKind) {
        when (kind) {
            ModelKind.LLM -> scope.launch { assistantEngine.release() }
            ModelKind.WHISPER -> hybridRecognizer.release()
            ModelKind.VOICE_PACK -> speechOutput.refreshCapability()
        }
    }

    /** Frees model memory when Android asks for it and no conversation is running. Models reload on demand. */
    fun onMemoryPressure() {
        if (sessionControllerLazy.isInitialized() && sessionController.state.value.sessionActive) return
        scope.launch { assistantEngine.release() }
        if (recognizer === hybridRecognizer) hybridRecognizer.release()
    }

    /** Called when the app leaves the foreground; does nothing if no session machinery was ever created. */
    fun onAppBackgrounded() {
        if (sessionControllerLazy.isInitialized()) sessionControllerLazy.value.onAppBackgrounded()
    }
}
