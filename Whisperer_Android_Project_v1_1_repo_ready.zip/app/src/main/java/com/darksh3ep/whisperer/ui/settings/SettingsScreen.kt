package com.darksh3ep.whisperer.ui.settings

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ui.components.NavRow
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard

class SettingsDestinations(
    val onVoice: () -> Unit,
    val onWake: () -> Unit,
    val onCommands: () -> Unit,
    val onModel: () -> Unit,
    val onPrivacy: () -> Unit,
    val onNetwork: () -> Unit,
    val onAbout: () -> Unit,
)

@Composable
fun SettingsScreen(destinations: SettingsDestinations, onBack: () -> Unit) {
    ScreenScaffold(title = stringResource(R.string.settings_title), onBack = onBack) {
        SectionCard {
            NavRow(
                title = stringResource(R.string.settings_voice_title),
                subtitle = stringResource(R.string.settings_voice_desc),
                onClick = destinations.onVoice,
            )
            NavRow(
                title = stringResource(R.string.settings_wake_title),
                subtitle = stringResource(R.string.settings_wake_desc),
                onClick = destinations.onWake,
            )
            NavRow(
                title = stringResource(R.string.settings_commands_title),
                subtitle = stringResource(R.string.settings_commands_desc),
                onClick = destinations.onCommands,
            )
            NavRow(
                title = stringResource(R.string.settings_model_title),
                subtitle = stringResource(R.string.settings_model_desc),
                onClick = destinations.onModel,
            )
            NavRow(
                title = stringResource(R.string.settings_privacy_title),
                subtitle = stringResource(R.string.settings_privacy_desc),
                onClick = destinations.onPrivacy,
            )
            NavRow(
                title = stringResource(R.string.settings_network_title),
                subtitle = stringResource(R.string.settings_network_desc),
                onClick = destinations.onNetwork,
            )
            NavRow(
                title = stringResource(R.string.settings_about_title),
                subtitle = stringResource(R.string.settings_about_desc),
                onClick = destinations.onAbout,
            )
        }
    }
}
