package com.darksh3ep.whisperer.domain.connectivity

import com.darksh3ep.whisperer.domain.commands.PhraseText

enum class Approval { YES, NO, UNCLEAR }

/**
 * Interprets a spoken answer to a consent question. It is deliberately conservative:
 * anything that is not a clear "yes" is NOT approval. Any negation wins over any affirmation.
 *
 * Limitation: the approval vocabulary is English only in this release (the assistant's default language).
 */
object ApprovalParser {
    private val affirmative = setOf(
        "yes", "yeah", "yep", "yup", "sure", "okay", "ok", "absolutely", "definitely",
        "approved", "go ahead", "do it", "please do", "yes please", "sure thing",
        "i agree", "i approve", "yes go ahead", "yes do it", "okay go ahead", "you can",
    )
    private val leadingYes = setOf("yes", "yeah", "yep", "yup", "sure", "okay", "ok")
    private val negativeTokens = setOf(
        "no", "nope", "nah", "not", "never", "dont", "don", "cancel", "stop",
        "decline", "refuse", "later", "wait", "t",
    )
    private val hedgeTokens = setOf(
        "maybe", "perhaps", "unsure", "guess", "possibly", "probably", "think",
        "hmm", "um", "uh", "depends", "dunno", "idk", "sorry", "what", "why",
    )

    fun parse(text: String): Approval {
        val normalized = PhraseText.normalize(text)
        if (normalized.isEmpty()) return Approval.UNCLEAR

        if (normalized.contains("not sure")) return Approval.UNCLEAR
        val tokens = normalized.split(' ')
        if (tokens.any { it in negativeTokens }) return Approval.NO
        if (tokens.any { it in hedgeTokens }) return Approval.UNCLEAR
        if (normalized in affirmative) return Approval.YES
        if (tokens.first() in leadingYes && tokens.size <= 4) return Approval.YES
        return Approval.UNCLEAR
    }
}
