package com.darksh3ep.whisperer.ai.speechrecognition

/** JNI surface of the whisper.cpp bridge (libwhisperer_whisper.so). [isAvailable] is false without the native build. */
object WhisperNative {
    val isAvailable: Boolean by lazy {
        try {
            System.loadLibrary("whisperer_whisper")
            true
        } catch (t: Throwable) {
            false
        }
    }

    @JvmStatic external fun nativeLoad(path: String): Long
    @JvmStatic external fun nativeTranscribe(handle: Long, samples: FloatArray, language: String, threads: Int): ByteArray?
    @JvmStatic external fun nativeAbort(handle: Long)
    @JvmStatic external fun nativeFree(handle: Long)
}
