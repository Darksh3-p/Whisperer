package com.darksh3ep.whisperer.ai.llm

import com.darksh3ep.whisperer.domain.conversation.ChatMessage
import com.darksh3ep.whisperer.domain.conversation.Speaker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import kotlin.coroutines.resume

/**
 * Local assistant backed by llama.cpp. All native work runs on one dedicated thread (the model is not
 * thread-safe and loading/generation must never overlap). Never fabricates output: when the runtime or
 * model is missing it returns [AssistantResult.Unavailable].
 */
class LlamaAssistantEngine(
    private val locator: ModelLocator,
    private val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
) : AssistantEngine {

    private val executor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "whisperer-llama").apply { isDaemon = true }
    }
    private val dispatcher = executor.asCoroutineDispatcher()

    // Touched only from the executor thread.
    private var handle = 0L
    private var loadedPath: String? = null

    override suspend fun status(): ModelStatus = withContext(Dispatchers.IO) { locator.locate().status }

    override suspend fun warmUp() {
        if (!InferenceRuntime.INTEGRATED) return
        val file = withContext(Dispatchers.IO) { locator.activeFile() } ?: return
        withContext(dispatcher) { ensureLoaded(file) }
    }

    override suspend fun release() {
        withContext(dispatcher) { unload() }
    }

    override suspend fun respond(history: List<ChatMessage>, request: String): AssistantResult {
        val info = withContext(Dispatchers.IO) { locator.locate() }
        if (info.status != ModelStatus.READY) return AssistantResult.Unavailable(info.status)
        val file = withContext(Dispatchers.IO) { locator.activeFile() }
            ?: return AssistantResult.Unavailable(ModelStatus.NOT_INSTALLED)

        val (roles, contents) = buildPrompt(history, request)
        return suspendCancellableCoroutine { continuation ->
            var activeHandle = 0L
            executor.execute {
                val outcome: AssistantResult = try {
                    val h = ensureLoaded(file)
                    if (h == 0L) {
                        AssistantResult.Unavailable(ModelStatus.INVALID_FILE)
                    } else {
                        activeHandle = h
                        if (!continuation.isActive) return@execute
                        val bytes = LlamaNative.nativeChat(h, roles, contents, MAX_NEW_TOKENS, TEMPERATURE)
                        when {
                            bytes == null -> AssistantResult.Failed
                            else -> {
                                val text = String(bytes, Charsets.UTF_8).trim()
                                if (text.isEmpty()) AssistantResult.Failed else AssistantResult.Reply(text)
                            }
                        }
                    }
                } catch (t: Throwable) {
                    AssistantResult.Failed
                }
                if (continuation.isActive) continuation.resume(outcome)
            }
            continuation.invokeOnCancellation {
                // Ask the native loop to stop; the executor thread then frees up for the next request.
                if (activeHandle != 0L) LlamaNative.nativeCancel(activeHandle)
            }
        }
    }

    // ---- executor thread only ----

    private fun ensureLoaded(file: File): Long {
        if (handle != 0L && loadedPath == file.absolutePath) return handle
        unload()
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
        val h = LlamaNative.nativeLoad(file.absolutePath, CONTEXT_TOKENS, threads)
        if (h != 0L) {
            handle = h
            loadedPath = file.absolutePath
        }
        return h
    }

    private fun unload() {
        if (handle != 0L) LlamaNative.nativeFree(handle)
        handle = 0L
        loadedPath = null
    }

    companion object {
        const val CONTEXT_TOKENS = 4096
        const val MAX_NEW_TOKENS = 640
        const val TEMPERATURE = 0.4f
        private const val MAX_HISTORY = 12

        const val DEFAULT_SYSTEM_PROMPT =
            "You are Whisperer, a friendly voice assistant that runs entirely on the user's phone. " +
                "Your replies are read aloud, so answer in short, natural spoken sentences. " +
                "Do not use markdown, headings, bullet lists or emojis in spoken text. " +
                "Be accurate, and say so when you are not sure. " +
                "When the user asks for code, put the code in a single fenced code block that names the language, " +
                "and keep the spoken explanation to one or two sentences."

        /**
         * Builds role/content byte arrays for the native chat template.
         * The controller already stored the newest user utterance in [history]; it is replaced by [request]
         * (which differs for commands such as "continue") instead of being sent twice.
         */
        fun buildPrompt(history: List<ChatMessage>, request: String, system: String = DEFAULT_SYSTEM_PROMPT):
            Pair<Array<ByteArray>, Array<ByteArray>> {
            val turns = history.filter { it.speaker != Speaker.SYSTEM && it.text.isNotBlank() }.toMutableList()
            if (turns.lastOrNull()?.speaker == Speaker.USER) turns.removeAt(turns.lastIndex)
            val recent = turns.takeLast(MAX_HISTORY)

            val roles = ArrayList<ByteArray>()
            val contents = ArrayList<ByteArray>()
            fun add(role: String, text: String) {
                roles.add(role.toByteArray(Charsets.UTF_8))
                contents.add(text.toByteArray(Charsets.UTF_8))
            }
            add("system", system)
            recent.forEach { add(if (it.speaker == Speaker.USER) "user" else "assistant", it.text) }
            add("user", request)
            return roles.toTypedArray() to contents.toTypedArray()
        }
    }
}
