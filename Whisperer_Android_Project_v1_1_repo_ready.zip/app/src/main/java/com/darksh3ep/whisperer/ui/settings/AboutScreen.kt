package com.darksh3ep.whisperer.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.darksh3ep.whisperer.BuildConfig
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.WhispererLogo
import com.darksh3ep.whisperer.ui.theme.Lavender
import com.darksh3ep.whisperer.ui.theme.TextPrimary
import com.darksh3ep.whisperer.ui.theme.TextTertiary

@Composable
fun AboutScreen(onBack: () -> Unit) {
    ScreenScaffold(title = stringResource(R.string.about_title), onBack = onBack) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            WhispererLogo(size = 72.dp, contentDescription = stringResource(R.string.about_logo_description))
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                )
                Text(
                    text = stringResource(R.string.about_version, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Lavender,
                )
            }
        }

        BodyText(stringResource(R.string.about_description), color = TextPrimary)

        SectionCard(title = stringResource(R.string.about_can_do_title)) {
            listOf(
                R.string.about_can_do_1,
                R.string.about_can_do_2,
                R.string.about_can_do_3,
                R.string.about_can_do_4,
                R.string.about_can_do_5,
            ).forEach { item ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("\u2022", color = Lavender)
                    Text(stringResource(item), style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                }
            }
        }

        SectionCard(title = stringResource(R.string.about_voice_title)) {
            BodyText(stringResource(R.string.about_voice_body), color = TextPrimary)
        }

        SectionCard {
            Row {
                Text(
                    text = stringResource(R.string.about_developer_label),
                    style = MaterialTheme.typography.titleMedium,
                    color = Lavender,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.about_developer_name),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                )
            }
        }

        SectionCard(title = stringResource(R.string.about_licenses_title)) {
            BodyText(stringResource(R.string.about_licenses_body))
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.about_footer),
            style = MaterialTheme.typography.bodyMedium,
            color = TextTertiary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(16.dp))
    }
}
