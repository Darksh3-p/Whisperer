package com.darksh3ep.whisperer.ai.llm

import java.io.File

data class ModelFileInfo(
    val status: ModelStatus,
    val fileName: String?,
    val sizeBytes: Long,
)

/**
 * Looks for a developer- or user-provided GGUF model in the app-private models folder.
 * Files get there through the in-app "Import model" button (see ModelImporter); no storage permission is needed.
 * Expected target model: Qwen2.5-Coder-3B-Instruct, Q6_K GGUF (about 2.5 GB, not bundled).
 */
class ModelLocator(private val modelsDir: File) {

    /** The GGUF file that [locate] would use, or null. */
    fun activeFile(): File? = modelsDir
        .listFiles { file -> file.isFile && file.name.endsWith(".gguf", ignoreCase = true) }
        ?.sortedBy { it.name }
        ?.firstOrNull { looksLikeGguf(it) }

    fun locate(): ModelFileInfo {
        val candidates = modelsDir
            .listFiles { file -> file.isFile && file.name.endsWith(".gguf", ignoreCase = true) }
            ?.sortedBy { it.name }
            .orEmpty()
        if (candidates.isEmpty()) return ModelFileInfo(ModelStatus.NOT_INSTALLED, null, 0L)

        val valid = candidates.firstOrNull { looksLikeGguf(it) }
            ?: return ModelFileInfo(ModelStatus.INVALID_FILE, candidates.first().name, candidates.first().length())

        val status = if (InferenceRuntime.INTEGRATED) ModelStatus.READY else ModelStatus.RUNTIME_UNAVAILABLE
        return ModelFileInfo(status, valid.name, valid.length())
    }

    companion object {
        /** GGUF files begin with the ASCII magic "GGUF". */
        fun looksLikeGguf(file: File): Boolean = try {
            file.inputStream().use { input ->
                val header = ByteArray(4)
                input.read(header) == 4 &&
                    header[0] == 'G'.code.toByte() &&
                    header[1] == 'G'.code.toByte() &&
                    header[2] == 'U'.code.toByte() &&
                    header[3] == 'F'.code.toByte()
            }
        } catch (e: Exception) {
            false
        }
    }
}
