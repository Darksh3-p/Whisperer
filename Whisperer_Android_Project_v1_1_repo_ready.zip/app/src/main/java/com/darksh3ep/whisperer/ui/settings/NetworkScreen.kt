package com.darksh3ep.whisperer.ui.settings

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.connectivity.NetworkSnapshot
import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind
import com.darksh3ep.whisperer.ui.StatusViewModel
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.MicPermissionHost
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.StatusLine
import com.darksh3ep.whisperer.ui.components.Tone
import com.darksh3ep.whisperer.ui.containerViewModel

/** Accurate text for a network snapshot (also used after returning from Android's panel). */
@Composable
fun networkStatusText(snapshot: NetworkSnapshot): String = stringResource(
    when {
        snapshot.viaWifi -> R.string.net_status_wifi
        snapshot.viaMobileData -> R.string.net_status_mobile
        snapshot.connected -> R.string.net_status_connected
        else -> R.string.net_status_not_connected
    }
)

@Composable
fun NetworkScreen(
    onBack: () -> Unit,
    onRequestConsent: (ConnectionKind) -> Unit,
) {
    val status: StatusViewModel = containerViewModel { StatusViewModel(it) }
    val network by status.network.collectAsStateWithLifecycle()
    var pending by remember { mutableStateOf<ConnectionKind?>(null) }

    ScreenScaffold(title = stringResource(R.string.settings_network_title), onBack = onBack) {
        BodyText(stringResource(R.string.settings_network_desc))

        SectionCard(title = stringResource(R.string.network_current_title)) {
            StatusLine(networkStatusText(network), if (network.connected) Tone.OK else Tone.NEUTRAL)
            if (!network.connected) BodyText(stringResource(R.string.error_no_internet))
        }

        SectionCard(title = stringResource(R.string.network_consent_title)) {
            BodyText(stringResource(R.string.network_consent_body))
            BodyText(stringResource(R.string.network_mobile_data_note))
        }

        SectionCard(title = stringResource(R.string.network_online_title)) {
            BodyText(stringResource(R.string.network_online_disclosure))
            BodyText(stringResource(R.string.network_no_provider))
        }

        SectionCard(title = stringResource(R.string.network_setup_title)) {
            BodyText(stringResource(R.string.network_setup_body))
            MicPermissionHost(onGranted = { pending?.let(onRequestConsent) }) { requestMic ->
                AppButton(
                    text = stringResource(R.string.network_setup_wifi),
                    onClick = {
                        pending = ConnectionKind.WIFI
                        requestMic()
                    },
                    kind = ButtonKind.SECONDARY,
                )
                AppButton(
                    text = stringResource(R.string.network_setup_mobile),
                    onClick = {
                        pending = ConnectionKind.MOBILE_DATA
                        requestMic()
                    },
                    kind = ButtonKind.SECONDARY,
                )
            }
        }
    }
}
