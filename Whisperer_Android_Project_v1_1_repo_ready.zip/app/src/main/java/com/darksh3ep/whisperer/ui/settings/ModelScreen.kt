package com.darksh3ep.whisperer.ui.settings

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ai.llm.ModelStatus
import com.darksh3ep.whisperer.ai.speechrecognition.AsrAvailability
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsState
import com.darksh3ep.whisperer.data.models.ImportState
import com.darksh3ep.whisperer.data.models.ModelKind
import com.darksh3ep.whisperer.data.models.VoicePackType
import com.darksh3ep.whisperer.domain.conversation.CodeSnippet
import com.darksh3ep.whisperer.ui.SettingsViewModel
import com.darksh3ep.whisperer.ui.StatusViewModel
import com.darksh3ep.whisperer.ui.asrDetailText
import com.darksh3ep.whisperer.ui.asrStatusText
import com.darksh3ep.whisperer.ui.components.AppButton
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.ButtonKind
import com.darksh3ep.whisperer.ui.components.ScreenScaffold
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.StatusLine
import com.darksh3ep.whisperer.ui.components.Tone
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.ttsStatusText

/** Honest status of every AI component. A status is only shown after checking the real runtime state. */
@Composable
fun ModelScreen(onBack: () -> Unit, onOpenCodePreview: () -> Unit) {
    val status: StatusViewModel = containerViewModel { StatusViewModel(it) }
    val settingsVm: SettingsViewModel = containerViewModel { SettingsViewModel(it) }
    val model by status.model.collectAsStateWithLifecycle()
    val asr by status.asr.collectAsStateWithLifecycle()
    val tts by status.tts.collectAsStateWithLifecycle()
    val whisper by status.whisper.collectAsStateWithLifecycle()
    val packs by status.packs.collectAsStateWithLifecycle()
    val importState by status.importState.collectAsStateWithLifecycle()
    val busy = importState is ImportState.Working

    val pickLlm = rememberFilePicker { status.importModel(ModelKind.LLM, it) }
    val pickWhisper = rememberFilePicker { status.importModel(ModelKind.WHISPER, it) }
    val pickPack = rememberFilePicker { status.importModel(ModelKind.VOICE_PACK, it) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { status.refresh() }

    ScreenScaffold(title = stringResource(R.string.settings_model_title), onBack = onBack) {
        BodyText(stringResource(R.string.settings_model_desc))
        ImportStatusCard(importState, onCancel = { status.cancelImport() }, onDismiss = { status.dismissImport() })

        SectionCard(title = stringResource(R.string.model_assistant_title)) {
            val info = model
            if (info == null) {
                StatusLine(stringResource(R.string.model_loading), Tone.NEUTRAL)
            } else {
                when (info.status) {
                    ModelStatus.NOT_INSTALLED ->
                        StatusLine(stringResource(R.string.model_status_not_installed), Tone.WARNING)
                    ModelStatus.INVALID_FILE ->
                        StatusLine(stringResource(R.string.error_model_failure), Tone.ERROR)
                    ModelStatus.RUNTIME_UNAVAILABLE ->
                        StatusLine(stringResource(R.string.model_status_runtime_unavailable), Tone.WARNING)
                    ModelStatus.READY ->
                        StatusLine(stringResource(R.string.model_status_ready), Tone.OK)
                }
            }
            if (info?.fileName != null) {
                BodyText(stringResource(R.string.model_installed_file, info.fileName, formatSize(info.sizeBytes)))
            }
            if (!status.llmRuntime) StatusLine(stringResource(R.string.runtime_missing_note), Tone.WARNING)
            BodyText(stringResource(R.string.model_target))
            BodyText(stringResource(R.string.model_license_note))
            BodyText(stringResource(R.string.model_download_unavailable))
            BodyText(stringResource(R.string.model_developer_setup))
            AppButton(stringResource(R.string.model_import_llm), onClick = pickLlm, enabled = !busy)
            if (info?.fileName != null) {
                AppButton(
                    stringResource(R.string.model_remove),
                    onClick = { status.removeModel(ModelKind.LLM) },
                    kind = ButtonKind.DANGER,
                    enabled = !busy,
                )
            }
        }

        SectionCard(title = stringResource(R.string.model_asr_title)) {
            if (!status.whisperActive()) {
                StatusLine(
                    stringResource(asrStatusText(asr)),
                    if (asr == AsrAvailability.AVAILABLE) Tone.OK else Tone.WARNING,
                )
                val detail = asrDetailText(asr)
                if (detail != null) BodyText(stringResource(detail))
            }
            val whisperInfo = whisper
            when {
                whisperInfo?.fileName == null -> StatusLine(stringResource(R.string.whisper_status_missing), Tone.WARNING)
                !status.whisperRuntime -> StatusLine(stringResource(R.string.whisper_status_runtime), Tone.WARNING)
                else -> StatusLine(stringResource(R.string.whisper_status_ready), Tone.OK)
            }
            if (whisperInfo?.fileName != null) {
                BodyText(stringResource(R.string.model_installed_file, whisperInfo.fileName, formatSize(whisperInfo.sizeBytes)))
            }
            BodyText(
                stringResource(
                    if (status.whisperActive()) R.string.asr_whisper_active else R.string.asr_whisper_inactive
                )
            )
            BodyText(stringResource(R.string.model_whisper_not_included))
            AppButton(stringResource(R.string.model_import_whisper), onClick = pickWhisper, enabled = !busy)
            if (whisperInfo?.fileName != null) {
                AppButton(
                    stringResource(R.string.model_remove),
                    onClick = { status.removeModel(ModelKind.WHISPER) },
                    kind = ButtonKind.DANGER,
                    enabled = !busy,
                )
            }
        }

        SectionCard(title = stringResource(R.string.model_tts_title)) {
            StatusLine(
                stringResource(ttsStatusText(tts.state)),
                if (tts.state == TtsState.OFFLINE_AVAILABLE) Tone.OK else Tone.WARNING,
            )
            if (tts.state == TtsState.NO_OFFLINE_VOICE || tts.state == TtsState.ENGINE_UNAVAILABLE) {
                BodyText(stringResource(R.string.tts_install_hint))
            }
        }

        VoicePackSection(
            packs = packs,
            runtimeAvailable = status.packRuntime,
            busy = busy,
            onImport = pickPack,
            onRemove = { status.removeVoicePack(it) },
        )

        SectionCard(title = stringResource(R.string.model_wake_title)) {
            StatusLine(stringResource(R.string.model_wake_not_available), Tone.WARNING)
            BodyText(stringResource(R.string.model_wake_detail))
        }

        SectionCard(title = stringResource(R.string.code_panel_title)) {
            BodyText(stringResource(R.string.model_code_preview_hint))
            AppButton(
                text = stringResource(R.string.model_code_preview),
                onClick = {
                    settingsVm.showSampleCode(
                        CodeSnippet(
                            language = "python",
                            code = "for number in range(5):\n    print(number)",
                        )
                    )
                    onOpenCodePreview()
                },
                kind = ButtonKind.SECONDARY,
            )
        }
    }
}

/** Installed voice packs with import / remove. Shared by the AI-model and voice screens. */
@Composable
fun VoicePackSection(
    packs: List<com.darksh3ep.whisperer.data.models.VoicePack>,
    runtimeAvailable: Boolean,
    busy: Boolean,
    onImport: () -> Unit,
    onRemove: (String) -> Unit,
) {
    SectionCard(title = stringResource(R.string.packs_title)) {
        BodyText(stringResource(R.string.packs_desc))
        if (packs.isEmpty()) {
            StatusLine(stringResource(R.string.packs_none), Tone.NEUTRAL)
        } else {
            if (!runtimeAvailable) StatusLine(stringResource(R.string.packs_runtime_missing), Tone.WARNING)
            packs.forEach { pack ->
                val unsupported = pack.type == VoicePackType.UNSUPPORTED
                StatusLine(
                    if (unsupported) stringResource(R.string.pack_unsupported, pack.id) else pack.id,
                    if (unsupported) Tone.WARNING else Tone.OK,
                )
                AppButton(
                    text = stringResource(R.string.model_remove) + " " + pack.id,
                    onClick = { onRemove(pack.id) },
                    kind = ButtonKind.DANGER,
                    enabled = !busy,
                )
            }
        }
        AppButton(stringResource(R.string.model_import_pack), onClick = onImport, enabled = !busy)
    }
}
