package com.darksh3ep.whisperer.domain.conversation

/**
 * Extracts fenced code blocks (```lang ... ```) from an assistant reply so they can be shown in the
 * compact code panel, and produces the text that should be spoken (code is not read aloud).
 * Whisperer only displays code; it never runs it.
 */
object CodeBlockParser {
    const val SPOKEN_CODE_NOTE = "The code is on your screen."

    private data class Segment(val isCode: Boolean, val language: String?, val body: String)

    fun parse(text: String): List<CodeSnippet> =
        segments(text)
            .filter { it.isCode && it.body.isNotBlank() }
            .map { CodeSnippet(it.language, it.body) }

    fun spokenText(text: String): String {
        val pieces = ArrayList<String>()
        var lastWasCode = false
        for (segment in segments(text)) {
            if (segment.isCode) {
                if (!lastWasCode) pieces.add(SPOKEN_CODE_NOTE)
                lastWasCode = true
            } else {
                val cleaned = segment.body.replace(Regex("[*`#]+"), "").trim()
                if (cleaned.isNotEmpty()) {
                    pieces.add(cleaned)
                    lastWasCode = false
                }
            }
        }
        return pieces.joinToString(" ")
    }

    private fun segments(text: String): List<Segment> {
        val out = ArrayList<Segment>()
        val prose = StringBuilder()
        val code = StringBuilder()
        var inCode = false
        var language: String? = null

        for (line in text.lines()) {
            val trimmed = line.trimStart()
            if (trimmed.startsWith("```")) {
                if (!inCode) {
                    if (prose.isNotBlank()) out.add(Segment(false, null, prose.toString().trim()))
                    prose.clear()
                    code.clear()
                    val tag = trimmed.removePrefix("```").trim().split(' ').firstOrNull().orEmpty()
                    language = tag.ifEmpty { null }
                    inCode = true
                } else {
                    out.add(Segment(true, language, code.toString().trimEnd('\n')))
                    code.clear()
                    language = null
                    inCode = false
                }
            } else if (inCode) {
                code.append(line).append('\n')
            } else {
                prose.append(line).append('\n')
            }
        }
        if (inCode) {
            out.add(Segment(true, language, code.toString().trimEnd('\n')))
        } else if (prose.isNotBlank()) {
            out.add(Segment(false, null, prose.toString().trim()))
        }
        return out
    }
}
