package com.darksh3ep.whisperer.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.domain.conversation.Phase
import com.darksh3ep.whisperer.ui.theme.Surface2
import com.darksh3ep.whisperer.ui.theme.Violet
import com.darksh3ep.whisperer.ui.theme.VioletDeep
import kotlin.math.PI
import kotlin.math.sin

/**
 * The voice orb. State is always also shown as text next to it by the screens.
 * With reduced motion enabled, the orb and waveform are drawn static.
 */
@Composable
fun VoiceOrb(
    phase: Phase,
    level: Float,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 200.dp,
    muted: Boolean = false,
) {
    val reduced = rememberReducedMotion()
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 1800, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse",
    )
    val showBars = phase == Phase.LISTENING || phase == Phase.SPEAKING

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .semantics { this.contentDescription = contentDescription }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(size)) {
            val c = center
            val r = this.size.minDimension / 2f
            val glow = if (reduced) 0.5f else 0.35f + 0.25f * (0.5f + 0.5f * sin(pulse * 2f * PI.toFloat())) + 0.3f * level
            drawCircle(color = Violet.copy(alpha = 0.12f), radius = r * (0.78f + 0.22f * glow), center = c)
            drawCircle(color = Surface2, radius = r * 0.74f, center = c)
            drawCircle(
                color = Violet.copy(alpha = 0.8f),
                radius = r * 0.74f,
                center = c,
                style = Stroke(width = 2.dp.toPx()),
            )
            val orbRadius = r * 0.56f
            drawCircle(
                brush = Brush.linearGradient(
                    colors = listOf(Violet, VioletDeep),
                    start = Offset(c.x - orbRadius, c.y - orbRadius),
                    end = Offset(c.x + orbRadius, c.y + orbRadius),
                ),
                radius = orbRadius,
                center = c,
            )
            if (showBars) {
                val count = 7
                val gap = orbRadius * 0.24f
                val barWidth = orbRadius * 0.13f
                for (i in 0 until count) {
                    val x = c.x + (i - count / 2) * gap
                    val wave = if (reduced) 0.6f else 0.5f + 0.5f * sin(pulse * 2f * PI.toFloat() + i * 0.9f)
                    val amplitude = if (phase == Phase.LISTENING) 0.25f + 0.75f * level else 0.65f
                    val half = orbRadius * (0.12f + 0.55f * amplitude * wave)
                    drawLine(
                        color = Color.White,
                        start = Offset(x, c.y - half),
                        end = Offset(x, c.y + half),
                        strokeWidth = barWidth,
                        cap = StrokeCap.Round,
                    )
                }
            }
        }
        if (!showBars) {
            Icon(
                painter = painterResource(if (muted) R.drawable.ic_mic_off else R.drawable.ic_mic),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(size * 0.24f),
            )
        }
    }
}
