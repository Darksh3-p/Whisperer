package com.darksh3ep.whisperer.connectivity

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind

/**
 * Opens ONLY Android's own supported connectivity panels / settings screens.
 * No hidden APIs, no root, no accessibility or device-admin tricks: the user completes the change in Android's UI.
 */
object SystemPanels {

    /** Returns true if a system screen was opened. */
    fun openConnectivity(context: Context, kind: ConnectionKind): Boolean {
        val panelAction = when (kind) {
            ConnectionKind.WIFI -> Settings.Panel.ACTION_WIFI
            // Android has no dedicated mobile-data panel; the internet connectivity panel contains the toggle.
            ConnectionKind.MOBILE_DATA, ConnectionKind.ANY -> Settings.Panel.ACTION_INTERNET_CONNECTIVITY
        }
        val fallbackAction = when (kind) {
            ConnectionKind.WIFI -> Settings.ACTION_WIFI_SETTINGS
            ConnectionKind.MOBILE_DATA, ConnectionKind.ANY -> Settings.ACTION_WIRELESS_SETTINGS
        }
        return start(context, Intent(panelAction)) || start(context, Intent(fallbackAction))
    }

    /** Opens this app's own page in Android Settings (to re-enable the microphone permission). */
    fun openAppSettings(context: Context): Boolean {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.fromParts("package", context.packageName, null))
        return start(context, intent)
    }

    private fun start(context: Context, intent: Intent): Boolean = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}
