package com.darksh3ep.whisperer.ui.home

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.ai.llm.ModelStatus
import com.darksh3ep.whisperer.domain.conversation.Phase
import com.darksh3ep.whisperer.ui.SessionViewModel
import com.darksh3ep.whisperer.ui.StatusViewModel
import com.darksh3ep.whisperer.ui.components.BodyText
import com.darksh3ep.whisperer.ui.components.MicPermissionHost
import com.darksh3ep.whisperer.ui.components.SectionCard
import com.darksh3ep.whisperer.ui.components.StatusLine
import com.darksh3ep.whisperer.ui.components.Tone
import com.darksh3ep.whisperer.ui.components.VoiceOrb
import com.darksh3ep.whisperer.ui.components.WhispererLogo
import com.darksh3ep.whisperer.ui.components.rememberHaptic
import com.darksh3ep.whisperer.ui.components.rememberPermissionGranted
import com.darksh3ep.whisperer.ui.containerViewModel
import com.darksh3ep.whisperer.ui.theme.Midnight
import com.darksh3ep.whisperer.ui.theme.TextPrimary
import com.darksh3ep.whisperer.ui.theme.TextSecondary
import com.darksh3ep.whisperer.ui.theme.TextTertiary

@Composable
fun HomeScreen(
    onOpenSettings: () -> Unit,
    onOpenConversation: () -> Unit,
) {
    val session: SessionViewModel = containerViewModel { SessionViewModel(it) }
    val status: StatusViewModel = containerViewModel { StatusViewModel(it) }

    val sessionState by session.state.collectAsStateWithLifecycle()
    val settings by session.settings.collectAsStateWithLifecycle()
    val network by status.network.collectAsStateWithLifecycle()
    val model by status.model.collectAsStateWithLifecycle()
    val asr by status.asr.collectAsStateWithLifecycle()
    val tts by status.tts.collectAsStateWithLifecycle()
    val micGranted by rememberPermissionGranted(Manifest.permission.RECORD_AUDIO)
    val haptic = rememberHaptic(settings?.hapticsEnabled == true)

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { status.refresh() }

    val primary = HomeStatusResolver.primary(micGranted, sessionState.sessionActive, model?.status)
    val connectivity = HomeStatusResolver.connectivity(network, model?.status, asr, tts.state)

    MicPermissionHost(
        onGranted = {
            session.startAndListen()
            onOpenConversation()
        },
    ) { requestMic ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Midnight)
                .safeDrawingPadding(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 8.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                WhispererLogo(size = 40.dp)
                Spacer(Modifier.width(12.dp))
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    modifier = Modifier
                        .weight(1f)
                        .semantics { heading() },
                )
                IconButton(onClick = onOpenSettings, modifier = Modifier.size(48.dp)) {
                    Icon(
                        painter = painterResource(R.drawable.ic_settings),
                        contentDescription = stringResource(R.string.action_settings),
                        tint = TextSecondary,
                    )
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Spacer(Modifier.height(16.dp))
                Text(
                    text = stringResource(R.string.home_greeting),
                    style = MaterialTheme.typography.headlineLarge,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                )
                Text(
                    text = stringResource(R.string.home_subtitle),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(24.dp))
                VoiceOrb(
                    phase = Phase.IDLE,
                    level = 0f,
                    contentDescription = stringResource(
                        if (sessionState.sessionActive) R.string.home_return_to_conversation else R.string.home_tap_to_talk
                    ),
                    onClick = {
                        haptic()
                        if (sessionState.sessionActive) onOpenConversation() else requestMic()
                    },
                    size = 220.dp,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = stringResource(
                        if (sessionState.sessionActive) R.string.home_return_to_conversation else R.string.home_tap_to_talk
                    ),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                )
                Spacer(Modifier.height(24.dp))

                SectionCard {
                    when (primary) {
                        PrimaryStatus.MIC_PERMISSION_NEEDED -> {
                            StatusLine(stringResource(R.string.status_mic_permission_needed), Tone.WARNING)
                        }
                        PrimaryStatus.SESSION_ACTIVE -> {
                            StatusLine(stringResource(R.string.home_session_active), Tone.OK)
                        }
                        PrimaryStatus.CHECKING -> {
                            StatusLine(stringResource(R.string.model_loading), Tone.NEUTRAL)
                        }
                        PrimaryStatus.MODEL_NOT_INSTALLED -> {
                            StatusLine(stringResource(R.string.status_model_not_installed), Tone.WARNING)
                            BodyText(stringResource(R.string.model_status_not_installed))
                        }
                        PrimaryStatus.MODEL_FILE_INVALID -> {
                            StatusLine(stringResource(R.string.error_model_failure), Tone.ERROR)
                        }
                        PrimaryStatus.MODEL_RUNTIME_UNAVAILABLE -> {
                            StatusLine(stringResource(R.string.status_model_runtime_unavailable), Tone.WARNING)
                            BodyText(stringResource(R.string.model_status_runtime_unavailable))
                        }
                        PrimaryStatus.READY -> {
                            StatusLine(stringResource(R.string.status_ready), Tone.OK)
                        }
                    }
                    when (connectivity) {
                        ConnectivityStatus.INTERNET_AVAILABLE ->
                            StatusLine(stringResource(R.string.status_internet_available), Tone.OK)
                        ConnectivityStatus.INTERNET_UNAVAILABLE -> {
                            StatusLine(stringResource(R.string.status_internet_unavailable), Tone.NEUTRAL)
                            BodyText(stringResource(R.string.error_no_internet))
                        }
                        ConnectivityStatus.OFFLINE_MODE ->
                            StatusLine(stringResource(R.string.status_offline_mode), Tone.OK)
                    }
                }
            }

            Text(
                text = stringResource(R.string.home_privacy_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = TextTertiary,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
            )
        }
    }
}
