package com.darksh3ep.whisperer.ui.theme

import androidx.compose.ui.graphics.Color

// Palette from UI_DESIGN_SPEC.md
val Midnight = Color(0xFF0B1020)
val Surface1 = Color(0xFF151D32)
val Surface2 = Color(0xFF1C2740)
val Violet = Color(0xFF8875F5)
val VioletDeep = Color(0xFF5745C8)
val Lavender = Color(0xFFB8AEFF)
val Teal = Color(0xFF48C7B0)
val TextPrimary = Color(0xFFF5F6FF)
val TextSecondary = Color(0xFFA8B0C7)
val TextTertiary = Color(0xFF8A93AD)
val Amber = Color(0xFFF4B860)
val Coral = Color(0xFFF07878)
val Outline = Color(0xFF293653)
val CodeBackground = Color(0xFF0D1425)
