package com.darksh3ep.whisperer.domain.commands

import java.util.UUID

/** The only in-app actions a spoken command can trigger. No device control, no launching other apps. */
enum class CommandAction {
    STOP,
    REPEAT,
    CONTINUE,
    EXPLAIN_DIFFERENTLY,
    SLOWER_SIMPLER,
    CHECK_CODE,
    END_SESSION,
}

data class VoiceCommand(
    val id: String,
    val action: CommandAction,
    val phrases: List<String>,
    val enabled: Boolean = true,
) {
    companion object {
        fun newId(): String = "cmd-" + UUID.randomUUID().toString()
    }
}

/** User-defined wake phrase (any language) plus aliases. Empty by default: nothing is hard-coded. */
data class WakePhraseConfig(
    val enabled: Boolean = false,
    val phrase: String = "",
    val aliases: List<String> = emptyList(),
) {
    val allPhrases: List<String>
        get() = (listOf(phrase) + aliases).map { it.trim() }.filter { it.isNotEmpty() }
}

/**
 * Starter command phrases. They are ordinary user data: every one can be edited, disabled or deleted,
 * and the user can add phrases in any language.
 */
object DefaultCommands {
    fun all(): List<VoiceCommand> = listOf(
        VoiceCommand("default-stop", CommandAction.STOP, listOf("stop", "be quiet")),
        VoiceCommand("default-repeat", CommandAction.REPEAT, listOf("repeat", "say that again")),
        VoiceCommand("default-continue", CommandAction.CONTINUE, listOf("continue", "go on")),
        VoiceCommand("default-explain", CommandAction.EXPLAIN_DIFFERENTLY, listOf("explain differently")),
        VoiceCommand("default-simpler", CommandAction.SLOWER_SIMPLER, listOf("slower and simpler", "explain it simply")),
        VoiceCommand("default-check-code", CommandAction.CHECK_CODE, listOf("check this code")),
        VoiceCommand("default-end", CommandAction.END_SESSION, listOf("end conversation", "end session")),
    )
}
