package com.darksh3ep.whisperer.ai.llm

/**
 * JNI surface of the llama.cpp bridge (libwhisperer_llama.so, built by the GitHub workflow).
 * [isAvailable] is false when the library is not part of this build; nothing else may be called then.
 */
object LlamaNative {
    val isAvailable: Boolean by lazy {
        try {
            System.loadLibrary("whisperer_llama")
            true
        } catch (t: Throwable) {
            false
        }
    }

    @JvmStatic external fun nativeLoad(path: String, nCtx: Int, nThreads: Int): Long
    @JvmStatic external fun nativeChat(
        handle: Long,
        roles: Array<ByteArray>,
        contents: Array<ByteArray>,
        maxNew: Int,
        temperature: Float,
    ): ByteArray?
    @JvmStatic external fun nativeCancel(handle: Long)
    @JvmStatic external fun nativeFree(handle: Long)
}
