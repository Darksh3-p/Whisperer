package com.darksh3ep.whisperer.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.darksh3ep.whisperer.domain.audio.AudioOutputOption
import com.darksh3ep.whisperer.domain.audio.AudioRoute
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Android implementation of audio focus + routing using only public APIs.
 * Route selection is best effort and must be verified on real headsets (see docs/DEVICE_TEST_CHECKLIST.md).
 */
class AudioRouteManager(context: Context) : AudioSessionControl {
    private val audioManager = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val main = Handler(Looper.getMainLooper())

    private val _route = MutableStateFlow(AudioRoute.PHONE_SPEAKER)
    override val route: StateFlow<AudioRoute> = _route.asStateFlow()

    private var focusRequest: AudioFocusRequest? = null
    private var onFocusLost: (() -> Unit)? = null

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            refreshRoute()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            refreshRoute()
        }
    }

    init {
        refreshRoute()
        audioManager.registerAudioDeviceCallback(deviceCallback, main)
    }

    private fun refreshRoute() {
        _route.value = currentRoute()
    }

    private fun currentRoute(): AudioRoute {
        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        val communication = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            audioManager.communicationDevice
        } else {
            null
        }
        if (communication != null) {
            val chosen = toRoute(communication.type)
            if (chosen != AudioRoute.UNKNOWN && chosen != AudioRoute.PHONE_SPEAKER) return chosen
        }
        outputs.firstOrNull { toRoute(it.type) == AudioRoute.BLUETOOTH }?.let { return AudioRoute.BLUETOOTH }
        outputs.firstOrNull { toRoute(it.type) == AudioRoute.WIRED_HEADSET }?.let { return AudioRoute.WIRED_HEADSET }
        outputs.firstOrNull { toRoute(it.type) == AudioRoute.USB_AUDIO }?.let { return AudioRoute.USB_AUDIO }
        return AudioRoute.PHONE_SPEAKER
    }

    private fun toRoute(type: Int): AudioRoute = when (type) {
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_BLE_SPEAKER,
        AudioDeviceInfo.TYPE_HEARING_AID -> AudioRoute.BLUETOOTH
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> AudioRoute.WIRED_HEADSET
        AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_USB_DEVICE,
        AudioDeviceInfo.TYPE_USB_ACCESSORY -> AudioRoute.USB_AUDIO
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER,
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> AudioRoute.PHONE_SPEAKER
        else -> AudioRoute.UNKNOWN
    }

    override fun requestFocus(onLost: () -> Unit): Boolean {
        abandonFocus()
        onFocusLost = onLost
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(attributes)
            .setOnAudioFocusChangeListener({ change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    onFocusLost?.invoke()
                }
            }, main)
            .build()
        focusRequest = request
        return audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    override fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
        onFocusLost = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            audioManager.clearCommunicationDevice()
            refreshRoute()
        }
    }

    override fun selectableOutputs(): List<AudioOutputOption> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return emptyList()
        return audioManager.availableCommunicationDevices.map { device ->
            AudioOutputOption(
                id = device.id,
                route = toRoute(device.type),
                name = device.productName?.toString().orEmpty(),
            )
        }
    }

    override fun selectOutput(id: Int?): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        if (id == null) {
            audioManager.clearCommunicationDevice()
            refreshRoute()
            return true
        }
        val device = audioManager.availableCommunicationDevices.firstOrNull { it.id == id } ?: return false
        val ok = audioManager.setCommunicationDevice(device)
        refreshRoute()
        return ok
    }
}
