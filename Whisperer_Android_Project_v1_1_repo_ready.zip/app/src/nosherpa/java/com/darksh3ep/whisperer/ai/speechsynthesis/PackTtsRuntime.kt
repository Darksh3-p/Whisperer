package com.darksh3ep.whisperer.ai.speechsynthesis

/**
 * Used when the build does NOT contain the sherpa-onnx runtime (for example a local build in Code on the Go).
 * Voice packs can still be imported, but they cannot be played until the APK from the GitHub workflow is used.
 */
object PackTtsRuntime {
    val isAvailable: Boolean = false
    fun create(): PackTtsBackend? = null
}
