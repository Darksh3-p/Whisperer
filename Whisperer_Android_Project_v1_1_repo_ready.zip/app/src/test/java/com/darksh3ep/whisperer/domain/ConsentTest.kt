package com.darksh3ep.whisperer.domain

import com.darksh3ep.whisperer.domain.connectivity.Approval
import com.darksh3ep.whisperer.domain.connectivity.ApprovalParser
import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind
import com.darksh3ep.whisperer.domain.connectivity.ConsentEvent
import com.darksh3ep.whisperer.domain.connectivity.ConsentReducer
import com.darksh3ep.whisperer.domain.connectivity.ConsentState
import com.darksh3ep.whisperer.domain.connectivity.DeclineReason
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConsentTest {
    private val wifi = ConnectionKind.WIFI

    private fun run(vararg events: ConsentEvent): ConsentState =
        events.fold(ConsentState.Idle as ConsentState) { state, event -> ConsentReducer.reduce(state, event) }

    @Test
    fun clearYesIsApproval() {
        listOf("yes", "Yes, please", "go ahead", "sure", "okay", "Yeah!").forEach {
            assertEquals(it, Approval.YES, ApprovalParser.parse(it))
        }
    }

    @Test
    fun noAndNegationsAreNotApproval() {
        listOf("no", "nope", "no thanks", "not now", "don't", "yes but wait", "yes no").forEach {
            assertEquals(it, Approval.NO, ApprovalParser.parse(it))
        }
    }

    @Test
    fun ambiguousSpeechIsNotApproval() {
        listOf("", "hmm", "maybe", "I'm not sure", "what", "the weather is nice", "I guess so").forEach {
            assertEquals(it, Approval.UNCLEAR, ApprovalParser.parse(it))
        }
    }

    @Test
    fun spokenYesApprovesAndOnlyThenThePanelCanOpen() {
        val asking = run(ConsentEvent.Begin(wifi))
        assertTrue(asking is ConsentState.AwaitingApproval)
        // Tapping Continue before approval does nothing.
        assertEquals(asking, ConsentReducer.reduce(asking, ConsentEvent.TappedContinue))

        val approved = ConsentReducer.reduce(asking, ConsentEvent.Heard("yes please"))
        assertEquals(ConsentState.Approved(wifi), approved)
        assertEquals(ConsentState.AwaitingSystemPanel(wifi), ConsentReducer.reduce(approved, ConsentEvent.TappedContinue))
    }

    @Test
    fun silenceIsNeverApprovalAndStopsAfterTwoUnclearAnswers() {
        val first = run(ConsentEvent.Begin(wifi), ConsentEvent.HeardNothing)
        assertEquals(ConsentState.AwaitingApproval(wifi, 1), first)
        val second = ConsentReducer.reduce(first, ConsentEvent.Heard("umm maybe"))
        assertEquals(ConsentState.Declined(wifi, DeclineReason.NOT_UNDERSTOOD), second)
    }

    @Test
    fun refusalEndsTheFlowAndDoesNotReprompt() {
        val declined = run(ConsentEvent.Begin(wifi), ConsentEvent.Heard("no"))
        assertEquals(ConsentState.Declined(wifi, DeclineReason.USER_DECLINED), declined)
        // Later speech cannot revive it.
        assertEquals(declined, ConsentReducer.reduce(declined, ConsentEvent.Heard("yes")))
        assertEquals(declined, ConsentReducer.reduce(declined, ConsentEvent.TappedContinue))
    }

    @Test
    fun notNowDeclines() {
        val declined = run(ConsentEvent.Begin(wifi), ConsentEvent.TappedNotNow)
        assertEquals(ConsentState.Declined(wifi, DeclineReason.USER_DECLINED), declined)
    }

    @Test
    fun successIsOnlyReportedFromVerificationAfterThePanel() {
        val inPanel = run(ConsentEvent.Begin(wifi), ConsentEvent.Heard("yes"), ConsentEvent.TappedContinue)
        // Returning without ever opening the panel changes nothing.
        val approvedOnly = run(ConsentEvent.Begin(wifi), ConsentEvent.Heard("yes"))
        assertEquals(approvedOnly, ConsentReducer.reduce(approvedOnly, ConsentEvent.ReturnedFromSettings(true)))

        assertEquals(ConsentState.Verified(wifi, true), ConsentReducer.reduce(inPanel, ConsentEvent.ReturnedFromSettings(true)))
        assertEquals(ConsentState.Verified(wifi, false), ConsentReducer.reduce(inPanel, ConsentEvent.ReturnedFromSettings(false)))
    }
}
