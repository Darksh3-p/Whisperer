package com.darksh3ep.whisperer.domain

import com.darksh3ep.whisperer.domain.commands.CommandAction
import com.darksh3ep.whisperer.domain.commands.CommandMatcher
import com.darksh3ep.whisperer.domain.commands.DefaultCommands
import com.darksh3ep.whisperer.domain.commands.MatchOutcome
import com.darksh3ep.whisperer.domain.commands.PhraseText
import com.darksh3ep.whisperer.domain.commands.SuppressReason
import com.darksh3ep.whisperer.domain.commands.VoiceCommand
import com.darksh3ep.whisperer.domain.commands.WakePhraseConfig
import com.darksh3ep.whisperer.domain.commands.WakePhraseMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandMatcherTest {
    private var now = 1_000L
    private val matcher = CommandMatcher(cooldownMillis = 1_500L, clock = { now })
    private val commands = DefaultCommands.all()

    @Test
    fun exactPhraseMatches() {
        val outcome = matcher.match("Stop", commands)
        assertTrue(outcome is MatchOutcome.Matched)
        assertEquals(CommandAction.STOP, (outcome as MatchOutcome.Matched).command.action)
    }

    @Test
    fun punctuationAndCaseAreIgnored() {
        val outcome = matcher.match("  Say THAT again!  ", commands)
        assertEquals(CommandAction.REPEAT, (outcome as MatchOutcome.Matched).command.action)
    }

    @Test
    fun stopInsideALongSentenceDoesNotTrigger() {
        val outcome = matcher.match("please stop the loop when the index reaches three", commands)
        assertEquals(MatchOutcome.NoMatch, outcome)
    }

    @Test
    fun cooldownSuppressesRapidRepeat() {
        assertTrue(matcher.match("stop", commands) is MatchOutcome.Matched)
        now += 500
        val second = matcher.match("stop", commands)
        assertTrue(second is MatchOutcome.Suppressed)
        assertEquals(SuppressReason.COOLDOWN, (second as MatchOutcome.Suppressed).reason)
        now += 2_000
        assertTrue(matcher.match("stop", commands) is MatchOutcome.Matched)
    }

    @Test
    fun lowRecognizerConfidenceIsSuppressed() {
        val outcome = matcher.match("stop", commands, asrConfidence = 0.1f)
        assertTrue(outcome is MatchOutcome.Suppressed)
        assertEquals(SuppressReason.LOW_ASR_CONFIDENCE, (outcome as MatchOutcome.Suppressed).reason)
    }

    @Test
    fun disabledCommandsDoNotMatch() {
        val disabled = commands.map { if (it.action == CommandAction.STOP) it.copy(enabled = false) else it }
        assertEquals(MatchOutcome.NoMatch, matcher.match("stop", disabled))
    }

    @Test
    fun conflictingCommandsRunNothing() {
        val clash = listOf(
            VoiceCommand("a", CommandAction.STOP, listOf("hold on")),
            VoiceCommand("b", CommandAction.END_SESSION, listOf("hold on")),
        )
        val outcome = matcher.match("hold on", clash)
        assertTrue(outcome is MatchOutcome.Ambiguous)
    }

    @Test
    fun phrasesInOtherLanguagesMatch() {
        val custom = listOf(
            VoiceCommand("jp", CommandAction.STOP, listOf("\u6B62\u3081\u3066")),
            VoiceCommand("es", CommandAction.REPEAT, listOf("repite eso")),
        )
        val jp = matcher.match("\u6B62\u3081\u3066", custom)
        assertEquals(CommandAction.STOP, (jp as MatchOutcome.Matched).command.action)
        val es = matcher.match("Repite eso.", custom)
        assertEquals(CommandAction.REPEAT, (es as MatchOutcome.Matched).command.action)
    }

    @Test
    fun classifyDoesNotConsumeCooldown() {
        matcher.classify("stop", commands)
        assertTrue(matcher.match("stop", commands) is MatchOutcome.Matched)
    }

    @Test
    fun similarityBasics() {
        assertEquals(1.0, PhraseText.similarity("Hello!", "hello"), 0.0001)
        assertEquals(0.0, PhraseText.similarity("", "hello"), 0.0001)
        assertEquals(3, PhraseText.levenshtein("kitten", "sitting"))
    }

    @Test
    fun wakePhraseMatcherUsesPhraseAndAliases() {
        val config = WakePhraseConfig(true, "hey whisper", listOf("okay whisper"))
        assertNotNull(WakePhraseMatcher.match("Hey, whisper!", config))
        assertNotNull(WakePhraseMatcher.match("okay whisper", config))
        assertNull(WakePhraseMatcher.match("good morning", config))
    }
}
