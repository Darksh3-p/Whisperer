package com.darksh3ep.whisperer.domain

import com.darksh3ep.whisperer.domain.conversation.CodeBlockParser
import com.darksh3ep.whisperer.domain.conversation.SentenceSplitter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CodeAndTextTest {
    private val reply = """
        Here is a loop.
        ```python
        for number in range(5):
            print(number)
        ```
        It prints zero to four.
    """.trimIndent()

    @Test
    fun extractsCodeWithStatedLanguage() {
        val snippets = CodeBlockParser.parse(reply)
        assertEquals(1, snippets.size)
        assertEquals("python", snippets[0].language)
        assertTrue(snippets[0].code.startsWith("for number in range(5):"))
        assertTrue(snippets[0].code.contains("    print(number)"))
    }

    @Test
    fun languageIsNotGuessedWhenFenceHasNoTag() {
        val snippets = CodeBlockParser.parse("```\nx = 1\n```")
        assertNull(snippets[0].language)
    }

    @Test
    fun unclosedFenceIsStillCode() {
        val snippets = CodeBlockParser.parse("```kotlin\nval a = 1")
        assertEquals("val a = 1", snippets[0].code)
    }

    @Test
    fun spokenTextSkipsCode() {
        val spoken = CodeBlockParser.spokenText(reply)
        assertFalse(spoken.contains("print(number)"))
        assertTrue(spoken.contains(CodeBlockParser.SPOKEN_CODE_NOTE))
        assertTrue(spoken.startsWith("Here is a loop."))
        assertTrue(spoken.endsWith("It prints zero to four."))
    }

    @Test
    fun plainTextHasNoCode() {
        assertTrue(CodeBlockParser.parse("Just words.").isEmpty())
        assertEquals("Just words.", CodeBlockParser.spokenText("Just words."))
    }

    @Test
    fun sentenceSplitterSplitsAndBoundsLength() {
        assertEquals(listOf("One.", "Two!", "Three?"), SentenceSplitter.split("One. Two! Three?"))
        assertTrue(SentenceSplitter.split("   ").isEmpty())
        val long = "word ".repeat(200)
        assertTrue(SentenceSplitter.split(long, maxLength = 100).all { it.length <= 100 })
    }
}
