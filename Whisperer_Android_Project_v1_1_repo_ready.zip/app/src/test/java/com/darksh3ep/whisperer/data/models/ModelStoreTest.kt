package com.darksh3ep.whisperer.data.models

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ModelStoreTest {
    @get:Rule
    val folder = TemporaryFolder()

    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    @Test
    fun detectsFileTypesFromTheirFirstBytes() {
        assertEquals(FileMagic.GGUF, FileMagic.detect("GGUF".toByteArray()))
        assertEquals(FileMagic.WHISPER_GGML, FileMagic.detect(bytes(0x6c, 0x6d, 0x67, 0x67, 0, 0)))
        assertEquals(FileMagic.ZIP, FileMagic.detect(bytes('P'.code, 'K'.code, 3, 4)))
        assertEquals(FileMagic.BZIP2, FileMagic.detect("BZh9".toByteArray()))
        assertEquals(FileMagic.GZIP, FileMagic.detect(bytes(0x1f, 0x8b, 8, 0)))
        assertEquals(FileMagic.UNKNOWN, FileMagic.detect("hello".toByteArray()))
        assertEquals(FileMagic.UNKNOWN, FileMagic.detect(ByteArray(0)))
    }

    @Test
    fun whisperFileIsFoundOnlyWithTheRightHeader() {
        val store = ModelStore(folder.root).also { it.ensureDirs() }
        File(store.whisperDir, "fake.bin").writeText("not a model")
        assertNull(store.whisperFile())
        File(store.whisperDir, "ggml-tiny.bin").writeBytes(bytes(0x6c, 0x6d, 0x67, 0x67, 1, 2, 3, 4))
        assertEquals("ggml-tiny.bin", store.whisperFile()?.name)
    }

    @Test
    fun cleanLeftoversRemovesInterruptedImports() {
        val store = ModelStore(folder.root).also { it.ensureDirs() }
        val part = File(store.llmDir, "x.gguf.part").apply { writeText("partial") }
        val tmp = File(store.voicesDir, ".tmp-1").apply { mkdirs() }
        store.cleanLeftovers()
        assertTrue(!part.exists())
        assertTrue(!tmp.exists())
    }

    private fun makePiperPack(dir: File) {
        dir.mkdirs()
        File(dir, "tokens.txt").writeText("a 1")
        File(dir, "en_US-amy-low.onnx").writeText("onnx")
        File(dir, "espeak-ng-data").mkdirs()
    }

    @Test
    fun describesAPiperStylePack() {
        val dir = File(folder.root, "vits-piper-en_US-amy-low")
        makePiperPack(dir)
        val pack = PackLayout.describe(dir)
        assertNotNull(pack)
        assertEquals(VoicePackType.VITS, pack!!.type)
        assertEquals("en_US-amy-low.onnx", pack.modelFile.name)
        assertNotNull(pack.dataDir)
    }

    @Test
    fun voicesBinMeansKokoro() {
        val dir = File(folder.root, "kokoro").apply { mkdirs() }
        File(dir, "tokens.txt").writeText("a 1")
        File(dir, "model.onnx").writeText("x")
        File(dir, "voices.bin").writeText("v")
        assertEquals(VoicePackType.KOKORO, PackLayout.describe(dir)!!.type)
    }

    @Test
    fun twoStagePacksAreMarkedUnsupported() {
        val dir = File(folder.root, "matcha").apply { mkdirs() }
        File(dir, "tokens.txt").writeText("a 1")
        File(dir, "model-steps-3.onnx").writeText("x")
        File(dir, "hifigan_v2.onnx").writeText("x")
        assertEquals(VoicePackType.UNSUPPORTED, PackLayout.describe(dir)!!.type)
    }

    @Test
    fun incompletePackIsRejected() {
        val dir = File(folder.root, "broken").apply { mkdirs() }
        File(dir, "tokens.txt").writeText("a 1")
        assertNull(PackLayout.describe(dir))
    }

    @Test
    fun findsPackRootInsideAnExtractedFolder() {
        val extracted = folder.newFolder("extracted")
        makePiperPack(File(extracted, "vits-piper-en_US-amy-low"))
        assertEquals("vits-piper-en_US-amy-low", PackLayout.findRoot(extracted)?.name)
        assertNull(PackLayout.findRoot(folder.newFolder("empty")))
    }

    @Test
    fun sanitizesPackNames() {
        assertEquals("vits-piper-en_US-amy-low", PackLayout.sanitizeId("vits-piper-en_US-amy-low.tar.bz2"))
        assertEquals("my_voice", PackLayout.sanitizeId("my voice.zip"))
        assertEquals("voice-pack", PackLayout.sanitizeId("..."))
    }

    @Test
    fun archiveEntriesCannotEscapeTheTargetFolder() {
        val root = folder.newFolder("target")
        assertEquals(File(root, "a/b.txt").canonicalPath, ModelImporter.safeChild(root, "a/b.txt").canonicalPath)
        assertThrows(Exception::class.java) { ModelImporter.safeChild(root, "../evil.txt") }
        assertThrows(Exception::class.java) { ModelImporter.safeChild(root, "a/../../evil.txt") }
    }
}
