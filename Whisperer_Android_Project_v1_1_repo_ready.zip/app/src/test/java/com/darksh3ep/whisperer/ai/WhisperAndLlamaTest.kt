package com.darksh3ep.whisperer.ai

import com.darksh3ep.whisperer.ai.llm.LlamaAssistantEngine
import com.darksh3ep.whisperer.ai.speechrecognition.UtteranceDetector
import com.darksh3ep.whisperer.ai.speechrecognition.WhisperText
import com.darksh3ep.whisperer.domain.conversation.ChatMessage
import com.darksh3ep.whisperer.domain.conversation.Speaker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class WhisperAndLlamaTest {

    @Test
    fun removesWhisperNonSpeechMarkers() {
        assertEquals("", WhisperText.clean(" [BLANK_AUDIO] "))
        assertEquals("", WhisperText.clean("(silence)"))
        assertEquals("hello there", WhisperText.clean("[Music] hello   there"))
        assertEquals("what is two plus two", WhisperText.clean("what is two plus two"))
    }

    @Test
    fun englishOnlyModelsForceEnglish() {
        assertEquals("en", WhisperText.languageFor(File("ggml-tiny.en.bin"), "fr"))
        assertEquals("fr", WhisperText.languageFor(File("ggml-tiny.bin"), "fr"))
        assertEquals("auto", WhisperText.languageFor(File("ggml-tiny.bin"), ""))
    }

    @Test
    fun detectorEndsAfterSilenceFollowingSpeech() {
        val d = UtteranceDetector()
        var verdict = UtteranceDetector.Verdict.CONTINUE
        repeat(12) { d.onFrame(0.002) }               // room noise (calibration)
        repeat(20) { verdict = d.onFrame(0.1) }       // speech
        assertTrue(d.speechStarted)
        assertEquals(UtteranceDetector.Verdict.CONTINUE, verdict)
        repeat(60) { if (verdict == UtteranceDetector.Verdict.CONTINUE) verdict = d.onFrame(0.002) }
        assertEquals(UtteranceDetector.Verdict.END_OF_SPEECH, verdict)
    }

    @Test
    fun detectorGivesUpWhenNobodySpeaks() {
        val d = UtteranceDetector()
        var verdict = UtteranceDetector.Verdict.CONTINUE
        repeat(400) { if (verdict == UtteranceDetector.Verdict.CONTINUE) verdict = d.onFrame(0.002) }
        assertEquals(UtteranceDetector.Verdict.NO_SPEECH, verdict)
        assertFalse(d.speechStarted)
    }

    private fun msg(id: Long, who: Speaker, text: String) = ChatMessage(id, who, text, 0L)

    @Test
    fun promptReplacesTheLatestUserTurnWithTheRequestAndNeverSendsItTwice() {
        val history = listOf(
            msg(1, Speaker.USER, "hi"),
            msg(2, Speaker.ASSISTANT, "Hello!"),
            msg(3, Speaker.USER, "continue"),
        )
        val (roles, contents) = LlamaAssistantEngine.buildPrompt(history, "Please continue.", system = "SYS")
        val r = roles.map { String(it) }
        val c = contents.map { String(it) }
        assertEquals(listOf("system", "user", "assistant", "user"), r)
        assertEquals(listOf("SYS", "hi", "Hello!", "Please continue."), c)
    }
}
