package com.darksh3ep.whisperer.ai

import com.darksh3ep.whisperer.ai.llm.InferenceRuntime
import com.darksh3ep.whisperer.ai.llm.ModelLocator
import com.darksh3ep.whisperer.ai.llm.ModelStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ModelLocatorTest {
    @get:Rule
    val folder = TemporaryFolder()

    @Test
    fun missingFolderMeansNotInstalled() {
        val info = ModelLocator(File(folder.root, "models")).locate()
        assertEquals(ModelStatus.NOT_INSTALLED, info.status)
        assertNull(info.fileName)
    }

    @Test
    fun fileWithoutGgufHeaderIsInvalid() {
        val dir = folder.newFolder("models")
        File(dir, "broken.gguf").writeText("this is not a model")
        assertEquals(ModelStatus.INVALID_FILE, ModelLocator(dir).locate().status)
    }

    @Test
    fun validHeaderIsFoundButNeverReportedReadyWithoutARuntime() {
        val dir = folder.newFolder("models")
        File(dir, "qwen.gguf").writeBytes(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte(), 3, 0, 0, 0))
        val info = ModelLocator(dir).locate()
        assertEquals("qwen.gguf", info.fileName)
        // This build ships no inference runtime, so the status must not claim the model is ready.
        assertFalse(InferenceRuntime.INTEGRATED)
        assertEquals(ModelStatus.RUNTIME_UNAVAILABLE, info.status)
    }
}
