package com.darksh3ep.whisperer.domain

import com.darksh3ep.whisperer.domain.commands.CommandAction
import com.darksh3ep.whisperer.domain.commands.DefaultCommands
import com.darksh3ep.whisperer.domain.commands.PhraseCheck
import com.darksh3ep.whisperer.domain.commands.PhraseOwner
import com.darksh3ep.whisperer.domain.commands.PhraseValidator
import com.darksh3ep.whisperer.domain.commands.WakePhraseConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PhraseValidatorTest {
    private val commands = DefaultCommands.all()
    private val wake = WakePhraseConfig(true, "hey whisper", emptyList())

    @Test
    fun emptyAndTooShortAreRejected() {
        assertEquals(PhraseCheck.Empty, PhraseValidator.checkAll(listOf("  "), null, wake, commands))
        assertEquals(PhraseCheck.TooShort, PhraseValidator.checkAll(listOf("a"), null, wake, commands))
    }

    @Test
    fun duplicateOfExistingCommandIsAConflict() {
        val check = PhraseValidator.checkAll(listOf("Stop!"), null, wake, commands)
        assertTrue(check is PhraseCheck.Conflict)
        val owner = (check as PhraseCheck.Conflict).owner
        assertTrue(owner is PhraseOwner.Command && owner.action == CommandAction.STOP)
    }

    @Test
    fun commandPhraseCannotEqualTheWakePhrase() {
        val check = PhraseValidator.checkAll(listOf("hey whisper"), null, wake, commands)
        assertTrue(check is PhraseCheck.Conflict && check.owner == PhraseOwner.Wake)
    }

    @Test
    fun editingOwnPhrasesDoesNotConflictWithItself() {
        val stop = commands.first { it.action == CommandAction.STOP }
        val owner = PhraseOwner.Command(stop.id, stop.action)
        assertEquals(PhraseCheck.Ok, PhraseValidator.checkAll(stop.phrases, owner, wake, commands))
    }

    @Test
    fun wakePhraseCanBeResavedUnchanged() {
        assertEquals(PhraseCheck.Ok, PhraseValidator.checkAll(listOf("hey whisper"), PhraseOwner.Wake, wake, commands))
    }

    @Test
    fun repeatedPhrasesInTheSameListAreRejected() {
        val check = PhraseValidator.checkAll(listOf("wake up now", "Wake up, now"), null, wake, commands)
        assertEquals(PhraseCheck.RepeatedInList, check)
    }

    @Test
    fun anyLanguageIsAccepted() {
        assertEquals(PhraseCheck.Ok, PhraseValidator.checkAll(listOf("\u3053\u3093\u306B\u3061\u306F\u30A6\u30A3\u30B9\u30D1\u30FC"), null, wake, commands))
    }
}
