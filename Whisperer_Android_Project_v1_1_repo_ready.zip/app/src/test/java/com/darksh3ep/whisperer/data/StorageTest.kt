package com.darksh3ep.whisperer.data

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.darksh3ep.whisperer.data.history.ConversationRecord
import com.darksh3ep.whisperer.data.history.FileHistoryStore
import com.darksh3ep.whisperer.data.preferences.SettingsCodec
import com.darksh3ep.whisperer.data.preferences.SettingsRepository
import com.darksh3ep.whisperer.domain.commands.CommandAction
import com.darksh3ep.whisperer.domain.commands.DefaultCommands
import com.darksh3ep.whisperer.domain.commands.VoiceCommand
import com.darksh3ep.whisperer.domain.commands.WakePhraseConfig
import com.darksh3ep.whisperer.domain.conversation.ChatMessage
import com.darksh3ep.whisperer.domain.conversation.Speaker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class StorageTest {
    @get:Rule
    val folder = TemporaryFolder()

    @Test
    fun commandsRoundTripIncludingOtherLanguages() {
        val original = listOf(
            VoiceCommand("1", CommandAction.STOP, listOf("stop", "\u6B62\u3081\u3066"), true),
            VoiceCommand("2", CommandAction.REPEAT, listOf("repite eso"), false),
        )
        assertEquals(original, SettingsCodec.decodeCommands(SettingsCodec.encodeCommands(original)))
    }

    @Test
    fun badCommandJsonFallsBackToNull() {
        assertNull(SettingsCodec.decodeCommands("not json"))
        assertNull(SettingsCodec.decodeCommands(null))
    }

    @Test
    fun wakeRoundTrip() {
        val wake = WakePhraseConfig(true, "hey whisper", listOf("ok whisper"))
        assertEquals(wake, SettingsCodec.decodeWake(SettingsCodec.encodeWake(wake)))
        assertEquals(WakePhraseConfig(), SettingsCodec.decodeWake("garbage"))
    }

    @Test
    fun settingsPersistThroughDataStore() = runBlocking {
        val file = File(folder.newFolder(), "settings.preferences_pb")
        val store = PreferenceDataStoreFactory.create(produceFile = { file })
        val repo = SettingsRepository(store)

        val defaults = repo.settings.first()
        assertEquals(false, defaults.onboardingComplete)
        assertEquals(false, defaults.backgroundSessionEnabled)
        assertEquals(true, defaults.historyEnabled)
        assertEquals(DefaultCommands.all(), defaults.commands)
        assertEquals("", defaults.wake.phrase)

        repo.setOnboardingComplete(true)
        repo.setBackgroundSessionEnabled(true)
        repo.setSpeechRate(1.5f)
        repo.setVoiceName("en-us-x-test-local")
        repo.setWake(WakePhraseConfig(true, "hey whisper", emptyList()))
        repo.setCommands(listOf(VoiceCommand("x", CommandAction.CHECK_CODE, listOf("check it"), true)))

        val saved = repo.settings.first()
        assertTrue(saved.onboardingComplete)
        assertTrue(saved.backgroundSessionEnabled)
        assertEquals(1.5f, saved.speechRate, 0.0001f)
        assertEquals("en-us-x-test-local", saved.voiceName)
        assertEquals("hey whisper", saved.wake.phrase)
        assertEquals(1, saved.commands.size)

        repo.setVoiceName(null)
        repo.resetCommands()
        val reset = repo.settings.first()
        assertNull(reset.voiceName)
        assertEquals(DefaultCommands.all(), reset.commands)
    }

    @Test
    fun historyStoresLoadsTrimsAndClears() = runBlocking {
        val file = File(folder.newFolder(), "history/conversations.json")
        val store = FileHistoryStore(file, maxRecords = 2, io = Dispatchers.Unconfined)
        assertTrue(store.load().isEmpty())

        fun record(n: Int) = ConversationRecord(
            id = "c$n",
            startedAtMillis = n * 1000L,
            messages = listOf(ChatMessage(1, Speaker.USER, "question $n", n * 1000L)),
        )
        store.append(record(1))
        store.append(record(2))
        store.append(record(3))

        val loaded = store.load()
        assertEquals(listOf("c3", "c2"), loaded.map { it.id })
        assertEquals("question 3", loaded[0].messages[0].text)

        store.clear()
        assertTrue(store.load().isEmpty())
        assertTrue(!file.exists())
    }

    @Test
    fun corruptHistoryFileLoadsAsEmpty() = runBlocking {
        val file = File(folder.newFolder(), "conversations.json")
        file.writeText("{broken")
        val store = FileHistoryStore(file, io = Dispatchers.Unconfined)
        assertNotNull(store.load())
        assertTrue(store.load().isEmpty())
    }
}
