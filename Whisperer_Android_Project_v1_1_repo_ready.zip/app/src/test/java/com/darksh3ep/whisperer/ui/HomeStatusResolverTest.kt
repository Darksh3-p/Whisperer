package com.darksh3ep.whisperer.ui

import com.darksh3ep.whisperer.ai.llm.ModelStatus
import com.darksh3ep.whisperer.ai.speechrecognition.AsrAvailability
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsState
import com.darksh3ep.whisperer.connectivity.NetworkSnapshot
import com.darksh3ep.whisperer.ui.home.ConnectivityStatus
import com.darksh3ep.whisperer.ui.home.HomeStatusResolver
import com.darksh3ep.whisperer.ui.home.PrimaryStatus
import org.junit.Assert.assertEquals
import org.junit.Test

class HomeStatusResolverTest {
    private val online = NetworkSnapshot(connected = true, viaWifi = true, viaMobileData = false)

    @Test
    fun microphoneNeededWinsOverEverything() {
        assertEquals(
            PrimaryStatus.MIC_PERMISSION_NEEDED,
            HomeStatusResolver.primary(micGranted = false, sessionActive = true, model = ModelStatus.READY),
        )
    }

    @Test
    fun modelStatesMapHonestly() {
        assertEquals(PrimaryStatus.MODEL_NOT_INSTALLED, HomeStatusResolver.primary(true, false, ModelStatus.NOT_INSTALLED))
        assertEquals(PrimaryStatus.MODEL_FILE_INVALID, HomeStatusResolver.primary(true, false, ModelStatus.INVALID_FILE))
        assertEquals(PrimaryStatus.MODEL_RUNTIME_UNAVAILABLE, HomeStatusResolver.primary(true, false, ModelStatus.RUNTIME_UNAVAILABLE))
        assertEquals(PrimaryStatus.READY, HomeStatusResolver.primary(true, false, ModelStatus.READY))
        assertEquals(PrimaryStatus.CHECKING, HomeStatusResolver.primary(true, false, null))
        assertEquals(PrimaryStatus.SESSION_ACTIVE, HomeStatusResolver.primary(true, true, ModelStatus.NOT_INSTALLED))
    }

    @Test
    fun offlineModeIsOnlyClaimedWhenEverythingWorksLocally() {
        val offline = NetworkSnapshot.OFFLINE
        assertEquals(
            ConnectivityStatus.OFFLINE_MODE,
            HomeStatusResolver.connectivity(offline, ModelStatus.READY, AsrAvailability.AVAILABLE, TtsState.OFFLINE_AVAILABLE),
        )
        assertEquals(
            ConnectivityStatus.INTERNET_UNAVAILABLE,
            HomeStatusResolver.connectivity(offline, ModelStatus.RUNTIME_UNAVAILABLE, AsrAvailability.AVAILABLE, TtsState.OFFLINE_AVAILABLE),
        )
        assertEquals(
            ConnectivityStatus.INTERNET_UNAVAILABLE,
            HomeStatusResolver.connectivity(offline, ModelStatus.READY, AsrAvailability.OS_TOO_OLD, TtsState.OFFLINE_AVAILABLE),
        )
        assertEquals(
            ConnectivityStatus.INTERNET_AVAILABLE,
            HomeStatusResolver.connectivity(online, ModelStatus.NOT_INSTALLED, AsrAvailability.NO_ON_DEVICE_ENGINE, TtsState.NO_OFFLINE_VOICE),
        )
    }
}
