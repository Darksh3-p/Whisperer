package com.darksh3ep.whisperer.ai.speechsynthesis

import com.darksh3ep.whisperer.data.models.VoicePack
import com.darksh3ep.whisperer.data.models.VoicePackType
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig

/** Real engine: sherpa-onnx (prebuilt native libraries + its Kotlin API, fetched by the GitHub workflow). */
object PackTtsRuntime {
    val isAvailable: Boolean by lazy {
        try {
            System.loadLibrary("sherpa-onnx-jni")
            true
        } catch (t: Throwable) {
            false
        }
    }

    fun create(): PackTtsBackend? = if (isAvailable) SherpaBackend() else null
}

private class SherpaBackend : PackTtsBackend {
    private var tts: OfflineTts? = null
    private var rate = 22_050

    override val sampleRate: Int get() = rate

    override fun load(pack: VoicePack): Boolean {
        release()
        return try {
            val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
            val modelConfig = when (pack.type) {
                VoicePackType.KOKORO -> OfflineTtsModelConfig(
                    kokoro = OfflineTtsKokoroModelConfig(
                        model = pack.modelFile.absolutePath,
                        voices = pack.voicesFile?.absolutePath ?: "",
                        tokens = pack.tokensFile.absolutePath,
                        dataDir = pack.dataDir?.absolutePath ?: "",
                    ),
                    numThreads = threads,
                    debug = false,
                    provider = "cpu",
                )
                else -> OfflineTtsModelConfig(
                    vits = OfflineTtsVitsModelConfig(
                        model = pack.modelFile.absolutePath,
                        lexicon = pack.lexiconFile?.absolutePath ?: "",
                        tokens = pack.tokensFile.absolutePath,
                        dataDir = pack.dataDir?.absolutePath ?: "",
                        dictDir = pack.dictDir?.absolutePath ?: "",
                    ),
                    numThreads = threads,
                    debug = false,
                    provider = "cpu",
                )
            }
            val engine = OfflineTts(config = OfflineTtsConfig(model = modelConfig))
            rate = engine.sampleRate()
            tts = engine
            true
        } catch (t: Throwable) {
            tts = null
            false
        }
    }

    override fun generate(text: String, speed: Float): FloatArray? = try {
        tts?.generate(text = text, sid = 0, speed = speed)?.samples
    } catch (t: Throwable) {
        null
    }

    override fun release() {
        try { tts?.release() } catch (t: Throwable) { /* already released */ }
        tts = null
    }
}
