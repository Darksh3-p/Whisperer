# Whisperer branding

`whisperer-logo.svg` is the canonical vector for **Concept 1: The Whisper Wave** (rounded square `#111A32`,
W-shaped wave with `#B8AEFF` → `#48C7B0` gradient, white inner accent `#F5F6FF`).

It is used, unchanged in geometry, as:

| Use | File |
|---|---|
| Adaptive launcher icon foreground (scaled 0.1547 into the 66 dp safe zone) | `app/src/main/res/drawable/ic_launcher_foreground.xml` |
| Themed (monochrome) launcher icon, Android 13+ | `app/src/main/res/drawable/ic_launcher_monochrome.xml` |
| Adaptive icon background | `app/src/main/res/values/ic_launcher_background.xml` (`#111A32`) |
| In-app mark (onboarding, home, About) | `app/src/main/res/drawable/whisperer_logo.xml` |

The wordmark "Whisperer" is rendered as text in the UI and is not baked into the icon.
minSdk is 29, so adaptive icons are always available and no rasterised PNG fallbacks are needed.
If you change the SVG, update the three vector drawables with the same path data.
