plugins {
    id("com.android.library")
}

android {
    namespace = "com.darksh3ep.whisperer.llama"
    compileSdk = 36
    ndkVersion = "28.2.13676358"

    defaultConfig {
        minSdk = 29
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake {
                val dir = rootProject.file("third_party/llama.cpp").absolutePath
                // Baseline for 2021+ arm64 phones (Dimensity 8350 Ultimate has all of these).
                // Add +i8mm only after checking your CPU supports it; a wrong flag crashes with SIGILL.
                val arch = providers.gradleProperty("whisperer.armArch").getOrElse("armv8.2-a+dotprod+fp16")
                arguments += listOf("-DUPSTREAM_DIR=$dir", "-DGGML_CPU_ARM_ARCH=$arch", "-DANDROID_STL=c++_static")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.31.6"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
