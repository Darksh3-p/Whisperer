// JNI bridge: llama.cpp <-> com.darksh3ep.whisperer.ai.llm.LlamaNative
// Text crosses the boundary as UTF-8 byte arrays (NewStringUTF only accepts *modified* UTF-8 and can abort on emoji).
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>
#include <algorithm>
#include "llama.h"

#define TAG "WhispererLlama"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

struct Session {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    int n_ctx = 0;
    int n_batch = 512;
    std::atomic<bool> cancel{false};
    std::mutex mu;
};

std::once_flag g_backend_once;

void log_cb(enum ggml_log_level level, const char *text, void *) {
    int prio = level == GGML_LOG_LEVEL_ERROR ? ANDROID_LOG_ERROR
             : level == GGML_LOG_LEVEL_WARN  ? ANDROID_LOG_WARN : ANDROID_LOG_DEBUG;
    __android_log_print(prio, TAG, "%s", text);
}

std::string to_std(JNIEnv *env, jstring s) {
    if (!s) return {};
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

// Strings from Kotlin arrive as byte arrays (UTF-8).
std::string bytes_to_std(JNIEnv *env, jbyteArray arr) {
    if (!arr) return {};
    jsize n = env->GetArrayLength(arr);
    std::string out(static_cast<size_t>(n), '\0');
    if (n > 0) env->GetByteArrayRegion(arr, 0, n, reinterpret_cast<jbyte *>(&out[0]));
    return out;
}

jbyteArray to_bytes(JNIEnv *env, const std::string &s) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(s.size()));
    if (arr && !s.empty()) env->SetByteArrayRegion(arr, 0, static_cast<jsize>(s.size()), reinterpret_cast<const jbyte *>(s.data()));
    return arr;
}

struct Msg { std::string role, content; };

std::string apply_template(Session *s, const std::vector<Msg> &msgs, size_t from) {
    std::vector<llama_chat_message> chat;
    // Keep a leading system message, then everything from `from`.
    if (!msgs.empty() && msgs[0].role == "system") chat.push_back({"system", msgs[0].content.c_str()});
    for (size_t i = std::max<size_t>(from, chat.empty() ? 0 : 1); i < msgs.size(); i++)
        chat.push_back({msgs[i].role.c_str(), msgs[i].content.c_str()});

    const char *tmpl = llama_model_chat_template(s->model, nullptr);
    std::vector<char> buf(8192);
    int32_t n = llama_chat_apply_template(tmpl, chat.data(), chat.size(), true, buf.data(), (int32_t) buf.size());
    if (n < 0) {  // template not understood: fall back to ChatML (Qwen, many others)
        n = llama_chat_apply_template("chatml", chat.data(), chat.size(), true, buf.data(), (int32_t) buf.size());
        tmpl = "chatml";
    }
    if (n < 0) return {};
    if (n > (int32_t) buf.size()) {
        buf.resize(n);
        n = llama_chat_apply_template(tmpl, chat.data(), chat.size(), true, buf.data(), (int32_t) buf.size());
        if (n < 0) return {};
    }
    return std::string(buf.data(), n);
}

std::vector<llama_token> tokenize(Session *s, const std::string &text) {
    int n = -llama_tokenize(s->vocab, text.c_str(), (int32_t) text.size(), nullptr, 0, true, true);
    if (n <= 0) return {};
    std::vector<llama_token> toks(n);
    int got = llama_tokenize(s->vocab, text.c_str(), (int32_t) text.size(), toks.data(), n, true, true);
    if (got < 0) return {};
    toks.resize(got);
    return toks;
}

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_darksh3ep_whisperer_ai_llm_LlamaNative_nativeLoad(JNIEnv *env, jclass, jstring jpath, jint nCtx, jint nThreads) {
    std::call_once(g_backend_once, [] {
        llama_log_set(log_cb, nullptr);
        llama_backend_init();
    });
    std::string path = to_std(env, jpath);
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = true;
    llama_model *model = llama_model_load_from_file(path.c_str(), mp);
    if (!model) { LOGE("model load failed: %s", path.c_str()); return 0; }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) nCtx;
    cp.n_batch = 512;
    cp.n_ubatch = 512;
    cp.n_threads = nThreads;
    cp.n_threads_batch = nThreads;
    llama_context *ctx = llama_init_from_model(model, cp);
    if (!ctx) { LOGE("context creation failed"); llama_model_free(model); return 0; }

    auto *s = new Session();
    s->model = model;
    s->ctx = ctx;
    s->vocab = llama_model_get_vocab(model);
    s->n_ctx = (int) llama_n_ctx(ctx);
    s->n_batch = 512;
    LOGI("loaded %s (n_ctx=%d, threads=%d)", path.c_str(), s->n_ctx, (int) nThreads);
    return reinterpret_cast<jlong>(s);
}

JNIEXPORT void JNICALL
Java_com_darksh3ep_whisperer_ai_llm_LlamaNative_nativeCancel(JNIEnv *, jclass, jlong handle) {
    if (auto *s = reinterpret_cast<Session *>(handle)) s->cancel.store(true);
}

JNIEXPORT void JNICALL
Java_com_darksh3ep_whisperer_ai_llm_LlamaNative_nativeFree(JNIEnv *, jclass, jlong handle) {
    auto *s = reinterpret_cast<Session *>(handle);
    if (!s) return;
    s->cancel.store(true);
    {
        std::lock_guard<std::mutex> lock(s->mu);  // wait for a running chat to finish
        if (s->ctx) llama_free(s->ctx);
        if (s->model) llama_model_free(s->model);
    }
    delete s;  // NOTE: caller guarantees no further calls with this handle
}

/** roles/contents: parallel arrays of UTF-8 byte arrays. Returns UTF-8 reply bytes, or null on failure. */
JNIEXPORT jbyteArray JNICALL
Java_com_darksh3ep_whisperer_ai_llm_LlamaNative_nativeChat(JNIEnv *env, jclass, jlong handle,
        jobjectArray roles, jobjectArray contents, jint maxNew, jfloat temperature) {
    auto *s = reinterpret_cast<Session *>(handle);
    if (!s) return nullptr;
    std::lock_guard<std::mutex> lock(s->mu);
    s->cancel.store(false);

    std::vector<Msg> msgs;
    jsize count = env->GetArrayLength(roles);
    for (jsize i = 0; i < count; i++) {
        auto r = (jbyteArray) env->GetObjectArrayElement(roles, i);
        auto c = (jbyteArray) env->GetObjectArrayElement(contents, i);
        msgs.push_back({bytes_to_std(env, r), bytes_to_std(env, c)});
        env->DeleteLocalRef(r);
        env->DeleteLocalRef(c);
    }
    if (msgs.empty()) return nullptr;

    // Fit the prompt into the context: drop the oldest non-system messages first.
    const int budget = s->n_ctx - (int) maxNew - 8;
    std::vector<llama_token> tokens;
    size_t from = (msgs[0].role == "system") ? 1 : 0;
    while (true) {
        std::string prompt = apply_template(s, msgs, from);
        if (prompt.empty()) { LOGE("chat template failed"); return nullptr; }
        tokens = tokenize(s, prompt);
        if (tokens.empty()) { LOGE("tokenize failed"); return nullptr; }
        if ((int) tokens.size() <= budget) break;
        if (from + 1 >= msgs.size()) { LOGE("prompt too long (%zu tokens)", tokens.size()); return nullptr; }
        from++;
    }

    llama_memory_clear(llama_get_memory(s->ctx), true);

    for (size_t i = 0; i < tokens.size(); i += (size_t) s->n_batch) {
        if (s->cancel.load()) return to_bytes(env, "");
        int32_t n = (int32_t) std::min<size_t>((size_t) s->n_batch, tokens.size() - i);
        llama_batch batch = llama_batch_get_one(tokens.data() + i, n);
        if (llama_decode(s->ctx, batch) != 0) { LOGE("prompt decode failed"); return nullptr; }
    }

    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    std::string out;
    char piece[256];
    int produced = 0;
    while (produced < (int) maxNew && !s->cancel.load()) {
        llama_token tok = llama_sampler_sample(smpl, s->ctx, -1);
        if (llama_vocab_is_eog(s->vocab, tok)) break;
        int n = llama_token_to_piece(s->vocab, tok, piece, sizeof(piece), 0, true);
        if (n > 0) out.append(piece, (size_t) n);
        produced++;
        llama_batch batch = llama_batch_get_one(&tok, 1);
        if (llama_decode(s->ctx, batch) != 0) { LOGE("decode failed mid-reply"); break; }
    }
    llama_sampler_free(smpl);
    return to_bytes(env, out);
}

}  // extern "C"
