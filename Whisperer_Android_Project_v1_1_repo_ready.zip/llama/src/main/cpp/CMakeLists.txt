cmake_minimum_required(VERSION 3.22)
project(whisperer_llama LANGUAGES C CXX)

if(NOT EXISTS "${UPSTREAM_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "llama.cpp sources not found at '${UPSTREAM_DIR}'. Clone them into third_party/llama.cpp.")
endif()

# Always optimise: Gradle's debug variant would otherwise build llama.cpp at -O0 (unusably slow).
set(CMAKE_C_FLAGS_DEBUG   "-O3 -DNDEBUG")
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG")
set(CMAKE_C_VISIBILITY_PRESET hidden)
set(CMAKE_CXX_VISIBILITY_PRESET hidden)

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON   OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER   OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL           OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP          OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE          OFF CACHE BOOL "" FORCE)

add_subdirectory(${UPSTREAM_DIR} llama_build)

add_library(whisperer_llama SHARED llama_jni.cpp)
target_link_libraries(whisperer_llama PRIVATE llama log android)
target_link_options(whisperer_llama PRIVATE -Wl,--exclude-libs,ALL -Wl,--gc-sections -Wl,-z,max-page-size=16384 -s)
