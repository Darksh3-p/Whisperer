# Device test checklist — TECNO POVA 7 Ultra 5G (LJ9)

Record the actual Android version, build number and results. **Do not invent numbers**: leave a field blank until measured.

Device: ______  Android: ______  Whisperer version: ______  Date: ______

## Install and launch
- [ ] Debug APK installs and launches; first-run flow completes
- [ ] Launcher icon shows the Whisper Wave mark (and themed icon on Android 13+)

## Permissions
- [ ] Microphone: explanation → system dialog; denial shows "Microphone access is off"; "Open app settings" opens the app's Android settings
- [ ] No storage/file/media permission appears anywhere (check Android Settings → Apps → Whisperer → Permissions)
- [ ] Notification permission requested only when enabling Background voice session

## Voice
- [ ] Tap to talk: on-device recognition works (or honestly reports unavailable). Android version: ______
- [ ] States Listening / Thinking / Speaking visible; microphone indicator matches reality
- [ ] With no model: reply is the "not installed" notice — no fake answer
- [ ] After a response the app waits (no auto-listening)
- [ ] Interrupt, mute, pause/resume (use Settings → Test voice or Repeat) behave
- [ ] Commands: "stop", "repeat", "end conversation" work; "stop the loop at index three" does not trigger stop; cooldown holds
- [ ] Wake phrase: save/edit/delete/test works with an English and a non-English phrase; then switch on "Always listen for wake phrase": notification appears, saying the phrase (alone and followed by a question) starts a turn with the screen on and off, other speech is ignored, Stop in the notification turns it off

## Speech output
- [ ] Offline English voice listed; Test voice speaks with network OFF
- [ ] With no offline voice installed: text-only + install guidance (no network voice)

## Audio routes
- [ ] Phone speaker · wired / USB-C headset · Bluetooth headset: label correct
- [ ] Unplug / Bluetooth disconnect mid-session → notice shown, audio continues on phone
- [ ] Incoming call / other app taking audio focus → session stops and waits
- [ ] Audio output picker (Android 12+) — does it really move audio and microphone? Notes: ______

## Background session
- [ ] Enable background session → notification with Talk / Stop appears during a session
- [ ] Lock the screen: session survives; Talk from notification starts listening; Stop ends everything
- [ ] Without background session: leaving the app ends the session
- [ ] Swipe app away → session ends; no silent restart
- [ ] Battery saver / OEM task killer behaviour: ______

## Connectivity consent
- [ ] Wi-Fi OFF → Settings → Network → Set up Wi-Fi: asks aloud, silence ≠ approval, "no" ends, "yes" enables the button
- [ ] Android Wi-Fi panel opens; after returning the displayed status matches the real state
- [ ] Mobile data: states that Android may not switch it directly
- [ ] Auto-tap: enable "Whisperer auto-tap" in Accessibility; say "turn on Wi-Fi" and "turn on mobile data" (with them off, phone unlocked) — switch is tapped, panel closes, spoken result matches reality; with the service off the panel opens and the reply tells you to tap

## Model (optional)
- [ ] Copy a GGUF to the models folder → "file found, runtime unavailable" shown; truncated/invalid file → "couldn't be loaded"

## Benchmarks (only once a real runtime exists)
Memory ______  First-token latency ______  Thermals ______  Battery per hour ______  ASR + LLM + TTS together ______

## Accessibility
- [ ] TalkBack reads orb, controls and states · font scale 200% usable · "Remove animations" respected
