# Architecture

```
ui (Compose)  ──►  ViewModels (SessionViewModel, StatusViewModel, SettingsViewModel, PhraseViewModel, ConsentViewModel)
                        │
                        ▼
              AppContainer (hand-wired singletons)
   ┌────────────┬───────────────┬───────────────┬──────────────┬───────────────┐
   session      ai (providers)  audio           connectivity   data
   Voice-       llm / asr /     AudioRoute-     Connectivity-  DataStore +
   Session-     tts / wake      Manager         Checker,       JSON history
   Controller                                   SystemPanels
        ▲
   domain (pure Kotlin): commands, phrase matching, consent state machine, code parsing
   service: VoiceSessionService (foreground, type=microphone, START_NOT_STICKY)
```

## Voice turn (VoiceSessionController)
`IDLE → LISTENING → (command? run it : THINKING) → SPEAKING → IDLE (wait)`.
The controller never starts listening on its own. Failures also return to `IDLE` with a notice.
`SessionUiState.micActive` is true only while the recognizer is capturing.

## Provider interfaces (where real AI plugs in)
- `AssistantEngine` (`ai/llm`) — implement with llama.cpp (JNI) and return `AssistantResult.Reply`. Until then `UnavailableAssistantEngine`
  returns `Unavailable(status)`. Set `InferenceRuntime.INTEGRATED = true` only together with a tested engine.
  Verify before integrating: exact GGUF, chat template (ChatML for Qwen2.5), tokenizer, memory (≈2.5 GB weights + KV cache on a 12 GB phone
  shared with ASR/TTS), thermals. **Do not quote performance numbers before measuring on the target device.**
- `SpeechRecognizerProvider` (`ai/speechrecognition`) — current: Android on-device. Whisper Tiny (e.g. whisper.cpp) can be added behind the same interface with VAD + chunking.
- `SpeechOutput` (`ai/speechsynthesis`) — current: Android TTS restricted to installed offline English voices.
- `WakeListener` (`session`) — always-on wake listening built on the same `SpeechRecognizerProvider`; see below.

## Always-on wake listening
`WakeListener` runs inside `VoiceSessionService` (foreground, type `microphone`, partial wake lock, notification with Talk/Stop).
It owns the microphone only while the session is idle: it asks the recognizer (Whisper if a model is imported, otherwise Android's
on-device recognizer) for one utterance at a time and passes it to `WakePhraseMatcher.findAtStart`. Speech that does not start with the
wake phrase is discarded; a match calls `VoiceSessionController.startFromWake(trailing)` (trailing text is handled as the request,
otherwise the microphone opens once). After a turn the controller returns to IDLE and the listener re-arms, so the next
"wake phrase + request" works hands-free. Failures back off (never a tight loop); missing permission / recognizer stops it and shows why.
Stop (notification) or the switch turns it off; it is never restarted after reboot or from the background (Android 14+ rules) — it resumes when the app is opened.
Known limits: it is continuous speech recognition, not a dedicated low-power keyword spotter, so it uses real battery; a short gap exists between recordings; Whisper may transcribe nearby speech/TV before discarding it.

## Voice-controlled connectivity (auto-tap)
`ConnectivityIntent` (pure Kotlin) recognises short English requests to switch Wi-Fi / mobile data / the internet ON. In
`VoiceSessionController.handleUtterance` this runs before command matching and the assistant, and delegates to `ConnectivityActions`
(`AndroidConnectivityActions`). If the opt-in `AutoTapService` accessibility service is connected it opens Android's panel
(`SystemPanels`), polls the panel window for ~12 s for a switch labelled Wi-Fi / mobile data, taps it, presses Back to close the
panel, then waits for `ConnectivityChecker` to confirm; otherwise it only opens the panel. The reply is shown and spoken from the real
result. The service subscribes to no useful events, reads the screen only during such a request, only in settings/system-UI windows,
and never taps airplane mode, hotspot, Bluetooth, data saver or roaming. While the panel is open the controller ignores
`onAppBackgrounded()` so the session survives to give the answer.

## Consent flow
`ConsentReducer` (pure) → states `AwaitingApproval → Approved → AwaitingSystemPanel → Verified` or `Declined`.
`ConsentViewModel` speaks the question (offline TTS), listens once per attempt, and only opens `Settings.Panel`
(Wi-Fi / internet connectivity) after a clear spoken yes; after returning it reads `ConnectivityManager` and reports the real state.

## Background microphone rules followed
Foreground service type `microphone`, permissions `FOREGROUND_SERVICE_MICROPHONE` + `RECORD_AUDIO`, started only from the visible app,
persistent notification with Stop, not sticky, ended on task removal. No promise is made across force-stop, reboot, battery saver, OEM task killers or permission revocation.
