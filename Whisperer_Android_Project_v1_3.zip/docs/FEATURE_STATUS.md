# Feature status

Legend — **A** Implemented in code, testable now (not yet device-verified) · **B** Needs a downloaded model / voice asset ·
**C** Constrained by Android; needs user/system action · **D** Not implemented / explicitly deferred.

| Feature | Status | Notes |
|---|---|---|
| First-run flow (welcome, mic, background session, wake phrase, offline voice check, model status, network) | A | No storage/file permission is ever requested |
| Home screen, tap-to-talk orb, accurate status lines | A | Only verified states are shown ("Offline mode" is never shown in this build) |
| Active conversation UI (orb/waveform, states, transcript, mute, interrupt, end, pause/resume, audio output) | A | Microphone indicator is driven by the recognizer actually capturing |
| Turn-taking: wait for user after each response | A | Unit-tested with fakes |
| Interrupt speech | A | Button / orb tap. **Voice barge-in while speaking is not implemented** (would need echo handling) |
| Follow-up context | A (plumbing) / B | History is passed to `AssistantEngine`; no engine produces answers yet |
| Speech recognition | C | Android on-device recognizer only (API 33+ and an installed engine). Older Android → reported unavailable. Language = device language |
| Whisper ASR (whisper.cpp) | B + C | `WhisperRecognizer`: mic capture, silence detection, on-device transcription. Needs imported ggml model + GitHub-built APK. Not yet run on a device |
| Local LLM (llama.cpp, any chat GGUF) | B + C | `LlamaAssistantEngine` + JNI bridge; chat template from the GGUF (ChatML fallback). Needs imported model + GitHub-built APK. READY = valid file + runtime present; load failures surface as "model couldn't be loaded". Not yet run on a device |
| Offline TTS | B | Android installed offline English voices, **or imported voice packs** (sherpa-onnx, VITS/Piper + Kokoro). Never a network voice |
| Model / voice-pack import | A | File picker → copy into app-private storage with progress, header validation, zip-slip protection. Not device-verified |
| Code panel (copy, language label, safety note) | A | Fed by fenced code in assistant replies; only a labelled fixed sample can be previewed today |
| Wake phrase: add/edit/delete/enable/test, aliases, any language | A | Test uses the speech recognizer + fuzzy match |
| **Always-on wake listening** | A + B + C | Optional switch in Settings → Wake phrase. A foreground microphone service (notification with Talk/Stop, partial wake lock) repeatedly listens with the normal recognizer (Whisper if imported, else Android on-device) and reacts only when speech **starts with** the wake phrase; anything else is discarded. Pauses during conversations, tests and the consent question. Needs notifications + mic permission; started only while the app is visible (resumes when the app is opened again, never after reboot). Extra battery use. Not yet device-verified |
| Custom commands: add/edit/delete/enable/test, conflicts, threshold, cooldown | A | STOP, REPEAT, END work locally; CONTINUE / EXPLAIN / SLOWER / CHECK_CODE are forwarded to the engine (unavailable today) |
| Connectivity consent (ask aloud → clear spoken yes → Android panel → verify) | A + C | English approval vocabulary only. Blocked (not bypassed) if TTS or on-device ASR is missing. Android may require the user to complete the change |
| Direct Wi-Fi / mobile-data toggling | D (by design) | Android forbids it for ordinary apps; no hidden APIs, root or device-admin |
| **Voice-controlled Wi-Fi / mobile-data on (auto-tap)** | A + B + C | Short English requests ("turn on Wi-Fi", "turn on mobile data", "turn on the internet") are handled before the assistant. With the opt-in `AutoTapService` accessibility service the app opens Android's panel and taps the matching switch (never airplane mode, hotspot, Bluetooth, data saver…), then reports the real network state; without it, it only opens the panel. Needs the phone unlocked; matches English switch labels; turning OFF is not supported; Android 13+ may require "Allow restricted settings" for a sideloaded APK. Not yet device-verified |
| Internet research | D | No online provider; nothing sends text or audio online |
| Background voice session (microphone foreground service, Talk/Stop notification) | A + C | Must be started from the visible app; subject to OEM/battery limits. **Unverified on target device**; not sticky |
| Audio focus, route label, device callbacks, output picker | A + C | Output selection is best effort (`setCommunicationDevice`, Android 12+) — verify with real headsets |
| Conversation history (local file, disable, clear) | A | |
| Settings persistence (DataStore) | A | |
| Accessibility: 48 dp targets, text + colour state, live regions, font-scale layouts, reduced motion | A | Not audited with TalkBack |
| File manager / storage permission / app launching / reminders / notes / calendar / messaging / terminal / code execution | D (excluded) | Intentionally absent |
