plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

// ---- Optional native AI runtimes -------------------------------------------------------------
// Present only after the GitHub workflow (or you) fetched the upstream sources / prebuilt libs.
// Without them the app still compiles; AI features report "runtime not included" honestly.
val nativeAiSources = rootProject.file("third_party/llama.cpp/CMakeLists.txt").exists() &&
    rootProject.file("third_party/whisper.cpp/CMakeLists.txt").exists()
val sherpaKotlinDir = rootProject.file("third_party/sherpa-onnx-kotlin")
val sherpaReady = sherpaKotlinDir.resolve("Tts.kt").exists() &&
    file("src/main/jniLibs/arm64-v8a/libsherpa-onnx-jni.so").exists()

android {
    namespace = "com.darksh3ep.whisperer"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.darksh3ep.whisperer"
        // minSdk 29: Settings.Panel connectivity panels need API 29; on-device speech
        // recognition needs API 33 and is reported as unavailable on older versions.
        minSdk = 29
        targetSdk = 36
        versionCode = 3
        versionName = "1.3.0"
        // The native AI libraries are built for 64-bit ARM phones only (e.g. TECNO POVA 7 Ultra).
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // A fixed debug key (committed on purpose; debug builds only) so every GitHub build can be installed
    // OVER the previous one. Without it each CI run has a new random key and you would have to uninstall
    // first, which deletes your imported models.
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("app/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    sourceSets {
        getByName("main") {
            // Real sherpa-onnx TTS wrapper + its Kotlin API, or an "unavailable" stub.
            java.srcDir(if (sherpaReady) "src/sherpa/java" else "src/nosherpa/java")
            if (sherpaReady) java.srcDir(sherpaKotlinDir)
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.06.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.1")
    implementation("androidx.navigation:navigation-compose:2.9.1")
    implementation("androidx.datastore:datastore-preferences:1.1.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    // Voice-pack import: .tar.bz2 / .tar.gz archives (sherpa-onnx voice packs are distributed as .tar.bz2).
    implementation("org.apache.commons:commons-compress:1.27.1")

    if (nativeAiSources) {
        implementation(project(":llama"))
        implementation(project(":whisper"))
    }

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")
    // android.jar stubs of org.json throw on the JVM; use the real implementation for unit tests.
    testImplementation("org.json:json:20240303")
}
