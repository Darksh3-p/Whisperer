package com.darksh3ep.whisperer.domain

import com.darksh3ep.whisperer.domain.commands.WakePhraseConfig
import com.darksh3ep.whisperer.domain.commands.WakePhraseMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class WakeAtStartTest {
    private val config = WakePhraseConfig(true, "hey whisperer", listOf("okay whisperer"))

    @Test
    fun findsThePhraseAndReturnsWhatFollows() {
        val hit = WakePhraseMatcher.findAtStart("Hey whisperer, what time is it?", config)
        assertNotNull(hit)
        assertEquals("what time is it?", hit!!.trailing)
    }

    @Test
    fun phraseAloneHasAnEmptyTrailingPart() {
        val hit = WakePhraseMatcher.findAtStart("hey whisperer", config)
        assertNotNull(hit)
        assertEquals("", hit!!.trailing)
    }

    @Test
    fun aliasesCountToo() {
        val hit = WakePhraseMatcher.findAtStart("Okay whisperer explain loops", config)
        assertNotNull(hit)
        assertEquals("explain loops", hit!!.trailing)
    }

    @Test
    fun toleratesASmallRecognitionError() {
        val hit = WakePhraseMatcher.findAtStart("hey whisper what is recursion", config)
        assertNotNull(hit)
        assertEquals("what is recursion", hit!!.trailing)
    }

    @Test
    fun ignoresSpeechThatDoesNotStartWithThePhrase() {
        assertNull(WakePhraseMatcher.findAtStart("good morning everyone", config))
        assertNull(WakePhraseMatcher.findAtStart("I told her hey whisperer yesterday", config))
        assertNull(WakePhraseMatcher.findAtStart("", config))
    }

    @Test
    fun noPhraseConfiguredNeverMatches() {
        assertNull(WakePhraseMatcher.findAtStart("hey whisperer", WakePhraseConfig()))
    }
}
