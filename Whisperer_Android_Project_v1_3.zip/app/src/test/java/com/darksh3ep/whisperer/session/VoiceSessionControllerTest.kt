package com.darksh3ep.whisperer.session

import com.darksh3ep.whisperer.ai.llm.AssistantEngine
import com.darksh3ep.whisperer.ai.llm.AssistantResult
import com.darksh3ep.whisperer.ai.llm.ModelStatus
import com.darksh3ep.whisperer.ai.speechrecognition.AsrAvailability
import com.darksh3ep.whisperer.ai.speechrecognition.RecognitionCallbacks
import com.darksh3ep.whisperer.ai.speechrecognition.RecognitionFailure
import com.darksh3ep.whisperer.ai.speechrecognition.SpeechRecognizerProvider
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechListener
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechOutput
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsCapability
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsState
import com.darksh3ep.whisperer.ai.speechsynthesis.VoiceOption
import com.darksh3ep.whisperer.audio.AudioSessionControl
import com.darksh3ep.whisperer.data.history.ConversationRecord
import com.darksh3ep.whisperer.data.history.HistoryStore
import com.darksh3ep.whisperer.domain.audio.AudioOutputOption
import com.darksh3ep.whisperer.domain.audio.AudioRoute
import com.darksh3ep.whisperer.domain.commands.CommandMatcher
import com.darksh3ep.whisperer.domain.commands.DefaultCommands
import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind
import com.darksh3ep.whisperer.domain.connectivity.ConnectivityActions
import com.darksh3ep.whisperer.domain.connectivity.ConnectivityResult
import com.darksh3ep.whisperer.domain.conversation.ChatMessage
import com.darksh3ep.whisperer.domain.conversation.Notice
import com.darksh3ep.whisperer.domain.conversation.Phase
import com.darksh3ep.whisperer.domain.conversation.Speaker
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeRecognizer : SpeechRecognizerProvider {
    var available = AsrAvailability.AVAILABLE
    var startCount = 0
    var cancelCount = 0
    var stopListeningCount = 0
    var callbacks: RecognitionCallbacks? = null

    override fun availability() = available
    override fun start(callbacks: RecognitionCallbacks) {
        startCount++
        this.callbacks = callbacks
    }

    override fun stopListening() { stopListeningCount++ }
    override fun cancel() { cancelCount++ }
    override fun destroy() {}
}

private class FakeSpeech : SpeechOutput {
    override val capability = MutableStateFlow(TtsCapability(TtsState.OFFLINE_AVAILABLE, 1))
    val spoken = ArrayList<String>()
    var stopCount = 0
    var listener: SpeechListener? = null
    var pauseResult = true
    var resumeCount = 0

    override fun voices(): List<VoiceOption> = emptyList()
    override fun applySettings(rate: Float, voiceName: String?) {}
    override fun refreshCapability() {}
    override fun speak(text: String, listener: SpeechListener) {
        spoken.add(text)
        this.listener = listener
    }

    override fun stop() { stopCount++ }
    override fun pause() = pauseResult
    override fun resume() { resumeCount++ }
    override fun shutdown() {}
}

private class FakeAssistant(var result: AssistantResult) : AssistantEngine {
    var calls = ArrayList<String>()
    override suspend fun status(): ModelStatus = ModelStatus.NOT_INSTALLED
    override suspend fun respond(history: List<ChatMessage>, request: String): AssistantResult {
        calls.add(request)
        return result
    }
}

private class FakeAudio : AudioSessionControl {
    override val route = MutableStateFlow(AudioRoute.PHONE_SPEAKER)
    var focusRequests = 0
    var abandoned = 0
    var onLost: (() -> Unit)? = null
    override fun requestFocus(onLost: () -> Unit): Boolean {
        focusRequests++
        this.onLost = onLost
        return true
    }

    override fun abandonFocus() { abandoned++ }
    override fun selectableOutputs(): List<AudioOutputOption> = emptyList()
    override fun selectOutput(id: Int?) = true
}

private class FakeHost : SessionHost {
    var started = 0
    var stopped = 0
    var startResult = true
    override fun startBackgroundSession(): Boolean {
        started++
        return startResult
    }

    override fun stopBackgroundSession() { stopped++ }
}

private class FakeHistory : HistoryStore {
    val saved = ArrayList<ConversationRecord>()
    override suspend fun load() = saved.toList()
    override suspend fun append(record: ConversationRecord) { saved.add(record) }
    override suspend fun clear() { saved.clear() }
}

private class FakeConnectivity(var result: ConnectivityResult) : ConnectivityActions {
    val calls = ArrayList<ConnectionKind>()
    override suspend fun enable(kind: ConnectionKind): ConnectivityResult {
        calls.add(kind)
        return result
    }

    override fun describe(kind: ConnectionKind, result: ConnectivityResult) = "result:" + result.name
}

@OptIn(ExperimentalCoroutinesApi::class)
class VoiceSessionControllerTest {
    private val recognizer = FakeRecognizer()
    private val speech = FakeSpeech()
    private val assistant = FakeAssistant(AssistantResult.Unavailable(ModelStatus.NOT_INSTALLED))
    private val audio = FakeAudio()
    private val host = FakeHost()
    private val history = FakeHistory()
    private var backgroundEnabled = false
    private var historyEnabled = true
    private var now = 10_000L

    private val controller = VoiceSessionController(
        scope = TestScope(UnconfinedTestDispatcher()),
        recognizer = recognizer,
        speech = speech,
        assistant = assistant,
        audio = audio,
        host = host,
        history = history,
        matcher = CommandMatcher(clock = { now }),
        settings = { SessionSettings(DefaultCommands.all(), backgroundEnabled, historyEnabled) },
        clock = { now },
    )

    private fun hear(text: String, confidence: Float? = null) {
        recognizer.callbacks!!.onFinal(text, confidence)
    }

    @Test
    fun startAndListenShowsListeningAndMicrophoneIndicator() {
        controller.startAndListen()
        val state = controller.state.value
        assertTrue(state.sessionActive)
        assertEquals(Phase.LISTENING, state.phase)
        assertTrue(state.micActive)
        assertEquals(1, recognizer.startCount)
        assertEquals(1, audio.focusRequests)
    }

    @Test
    fun missingModelShowsHonestNoticeAndNeverFakesAnAnswer() {
        controller.startAndListen()
        hear("How does a loop work?")

        val state = controller.state.value
        assertEquals(Phase.IDLE, state.phase)
        assertFalse(state.micActive)
        assertEquals(listOf(Speaker.USER, Speaker.SYSTEM), state.messages.map { it.speaker })
        assertEquals(Notice.MODEL_NOT_INSTALLED, state.messages.last().notice)
        assertTrue(state.messages.none { it.speaker == Speaker.ASSISTANT })
        assertTrue(speech.spoken.isEmpty())
        assertEquals(listOf("How does a loop work?"), assistant.calls)
    }

    @Test
    fun runtimeMissingAndLoadFailureMapToTheirOwnNotices() {
        assistant.result = AssistantResult.Unavailable(ModelStatus.RUNTIME_UNAVAILABLE)
        controller.startAndListen()
        hear("hello there")
        assertEquals(Notice.MODEL_RUNTIME_UNAVAILABLE, controller.state.value.messages.last().notice)

        assistant.result = AssistantResult.Unavailable(ModelStatus.INVALID_FILE)
        controller.tapToTalk()
        hear("another question please")
        assertEquals(Notice.MODEL_LOAD_FAILED, controller.state.value.messages.last().notice)
    }

    @Test
    fun waitsForTheUserAfterAReplyAndNeverAutoListens() {
        assistant.result = AssistantResult.Reply("A loop repeats steps. It stops when a condition fails.")
        controller.startAndListen()
        hear("explain loops")

        assertEquals(Phase.SPEAKING, controller.state.value.phase)
        assertEquals(1, speech.spoken.size)

        speech.listener!!.onDone()

        assertEquals(Phase.IDLE, controller.state.value.phase)
        assertFalse(controller.state.value.micActive)
        assertEquals("microphone must not restart by itself", 1, recognizer.startCount)
    }

    @Test
    fun replyWithCodeOpensSnippetAndDoesNotSpeakTheCode() {
        assistant.result = AssistantResult.Reply("Try this.\n```python\nprint('hi')\n```\nDone.")
        controller.startAndListen()
        hear("show me hello world")

        val snippet = controller.state.value.codeSnippet
        assertNotNull(snippet)
        assertEquals("python", snippet!!.language)
        assertEquals("print('hi')", snippet.code)
        assertFalse(speech.spoken.single().contains("print"))
    }

    @Test
    fun interruptStopsSpeechAndListens() {
        assistant.result = AssistantResult.Reply("A long answer. With two sentences.")
        controller.startAndListen()
        hear("tell me something")
        assertEquals(Phase.SPEAKING, controller.state.value.phase)

        controller.interrupt()

        assertEquals(1, speech.stopCount)
        assertEquals(Phase.LISTENING, controller.state.value.phase)
        assertEquals(Notice.INTERRUPTED, controller.state.value.notice)
        assertEquals(2, recognizer.startCount)
    }

    @Test
    fun pauseAndResumeSpeech() {
        assistant.result = AssistantResult.Reply("One. Two.")
        controller.startAndListen()
        hear("go")
        controller.pauseSpeech()
        assertEquals(Phase.SPEECH_PAUSED, controller.state.value.phase)
        controller.resumeSpeech()
        assertEquals(Phase.SPEAKING, controller.state.value.phase)
        assertEquals(1, speech.resumeCount)
    }

    @Test
    fun stopCommandStopsWithoutAskingTheAssistant() {
        controller.startAndListen()
        hear("stop")
        assertEquals(Phase.IDLE, controller.state.value.phase)
        assertTrue(assistant.calls.isEmpty())
        assertEquals(1, speech.stopCount)
    }

    @Test
    fun repeatCommandRespeaksTheLastReply() {
        assistant.result = AssistantResult.Reply("The answer is four.")
        controller.startAndListen()
        hear("what is two plus two")
        speech.listener!!.onDone()

        controller.tapToTalk()
        now += 5_000
        hear("repeat")

        assertEquals(listOf("The answer is four.", "The answer is four."), speech.spoken)
        assertEquals("repeat must not reach the assistant", 1, assistant.calls.size)
    }

    @Test
    fun repeatWithNothingToRepeatSaysSo() {
        controller.startAndListen()
        hear("repeat")
        assertEquals(Notice.NOTHING_TO_REPEAT, controller.state.value.messages.last().notice)
        assertEquals(Phase.IDLE, controller.state.value.phase)
    }

    @Test
    fun commandsThatNeedTheModelGoThroughTheAssistantEngine() {
        controller.startAndListen()
        hear("explain differently")
        assertEquals(listOf(VoiceSessionController.PROMPT_EXPLAIN_DIFFERENTLY), assistant.calls)
        assertEquals(Notice.MODEL_NOT_INSTALLED, controller.state.value.messages.last().notice)
    }

    @Test
    fun endConversationCommandEndsTheSessionAndSavesHistory() {
        controller.startAndListen()
        hear("end conversation")

        assertFalse(controller.state.value.sessionActive)
        assertEquals(1, audio.abandoned)
        assertEquals(1, host.stopped)
        assertEquals(1, history.saved.size)
        assertEquals(listOf(Speaker.USER), history.saved[0].messages.map { it.speaker })
    }

    @Test
    fun historyIsNotSavedWhenDisabled() {
        historyEnabled = false
        controller.startAndListen()
        hear("hello world")
        controller.endSession()
        assertTrue(history.saved.isEmpty())
    }

    @Test
    fun recognitionFailureWaitsForTheUser() {
        controller.startAndListen()
        recognizer.callbacks!!.onFailure(RecognitionFailure.NO_SPEECH)

        val state = controller.state.value
        assertEquals(Phase.IDLE, state.phase)
        assertEquals(Notice.RECOGNITION_FAILED, state.notice)
        assertFalse(state.micActive)
        assertEquals(1, recognizer.startCount)
    }

    @Test
    fun unavailableRecognizerIsReportedNotFaked() {
        recognizer.available = AsrAvailability.OS_TOO_OLD
        controller.startAndListen()
        assertEquals(Notice.ASR_UNAVAILABLE, controller.state.value.notice)
        assertEquals(0, recognizer.startCount)
        assertEquals(Phase.IDLE, controller.state.value.phase)
    }

    @Test
    fun muteCancelsListeningAndTurnsTheIndicatorOff() {
        controller.startAndListen()
        controller.setMuted(true)
        val state = controller.state.value
        assertTrue(state.micMuted)
        assertFalse(state.micActive)
        assertEquals(Phase.IDLE, state.phase)
        assertEquals(1, recognizer.cancelCount)

        controller.tapToTalk()
        assertEquals("muted: tapping must not start the microphone", 1, recognizer.startCount)
        assertEquals(Notice.MIC_MUTED, controller.state.value.notice)
    }

    @Test
    fun noOfflineVoiceShowsTextOnlyAndNeverUsesNetworkVoice() {
        speech.capability.value = TtsCapability(TtsState.NO_OFFLINE_VOICE, 0)
        assistant.result = AssistantResult.Reply("Hello.")
        controller.startAndListen()
        hear("hi there")

        assertTrue(speech.spoken.isEmpty())
        assertEquals(Notice.NO_VOICE, controller.state.value.notice)
        assertEquals(Phase.IDLE, controller.state.value.phase)
        assertTrue(controller.state.value.messages.any { it.speaker == Speaker.ASSISTANT })
    }

    @Test
    fun audioFocusLossStopsEverythingAndWaits() {
        controller.startAndListen()
        audio.onLost!!.invoke()
        val state = controller.state.value
        assertEquals(Phase.IDLE, state.phase)
        assertEquals(Notice.AUDIO_INTERRUPTED, state.notice)
        assertFalse(state.micActive)
    }

    @Test
    fun routeDisconnectIsAnnounced() {
        audio.route.value = AudioRoute.BLUETOOTH
        controller.startSession()
        controller.onRouteChanged(AudioRoute.BLUETOOTH)
        controller.onRouteChanged(AudioRoute.PHONE_SPEAKER)
        assertEquals(Notice.ROUTE_DISCONNECTED, controller.state.value.notice)
        assertEquals(AudioRoute.PHONE_SPEAKER, controller.state.value.audioRoute)
    }

    @Test
    fun leavingTheAppEndsASessionThatHasNoVisibleBackgroundService() {
        controller.startAndListen()
        controller.onAppBackgrounded()
        assertFalse(controller.state.value.sessionActive)
        assertEquals(0, host.started)
    }

    @Test
    fun backgroundSessionStartsTheServiceAndSurvivesLeavingTheApp() {
        backgroundEnabled = true
        controller.startAndListen()
        assertTrue(controller.state.value.backgroundActive)
        assertEquals(1, host.started)

        controller.onAppBackgrounded()
        assertTrue(controller.state.value.sessionActive)

        controller.endSession()
        assertEquals(1, host.stopped)
    }

    @Test
    fun failedBackgroundStartFallsBackToForegroundOnlyAndSaysSo() {
        backgroundEnabled = true
        host.startResult = false
        controller.startAndListen()
        assertFalse(controller.state.value.backgroundActive)
        assertEquals(Notice.BACKGROUND_UNAVAILABLE, controller.state.value.notice)
        controller.onAppBackgrounded()
        assertFalse(controller.state.value.sessionActive)
    }

    @Test
    fun tapWhileListeningFinishesCapture() {
        controller.startAndListen()
        controller.tapToTalk()
        assertEquals(1, recognizer.stopListeningCount)
    }

    @Test
    fun endSessionResetsState() {
        controller.startAndListen()
        controller.endSession()
        assertNull(controller.state.value.codeSnippet)
        assertEquals(Phase.IDLE, controller.state.value.phase)
        assertTrue(controller.state.value.messages.isEmpty())
    }

    @Test
    fun wakeWithARequestAfterItGoesStraightToTheAssistant() {
        controller.startFromWake("what is a loop")

        val state = controller.state.value
        assertTrue(state.sessionActive)
        assertEquals(listOf("what is a loop"), assistant.calls)
        assertEquals(Speaker.USER, state.messages.first().speaker)
        // The request was already heard together with the wake phrase, so the microphone is not opened again.
        assertEquals(0, recognizer.startCount)
    }

    @Test
    fun wakeWithNothingAfterItOpensTheMicrophone() {
        controller.startFromWake("")

        assertTrue(controller.state.value.sessionActive)
        assertEquals(Phase.LISTENING, controller.state.value.phase)
        assertEquals(1, recognizer.startCount)
    }

    private fun controllerWith(actions: ConnectivityActions) = VoiceSessionController(
        scope = TestScope(UnconfinedTestDispatcher()),
        recognizer = recognizer,
        speech = speech,
        assistant = assistant,
        audio = audio,
        host = host,
        history = history,
        matcher = CommandMatcher(clock = { now }),
        settings = { SessionSettings(DefaultCommands.all(), backgroundEnabled, historyEnabled) },
        clock = { now },
        connectivity = actions,
    )

    @Test
    fun turnOnWifiIsHandledByTheConnectivityActionNotTheAssistant() {
        val actions = FakeConnectivity(ConnectivityResult.CONNECTED)
        val c = controllerWith(actions)
        c.startSession()
        c.tapToTalk()
        hear("Turn on Wi-Fi")

        assertEquals(listOf(ConnectionKind.WIFI), actions.calls)
        assertTrue(assistant.calls.isEmpty())
        assertEquals(listOf("result:CONNECTED"), speech.spoken)
        assertEquals(Speaker.ASSISTANT, c.state.value.messages.last().speaker)
    }

    @Test
    fun aLongQuestionAboutWifiStillGoesToTheAssistant() {
        val actions = FakeConnectivity(ConnectivityResult.CONNECTED)
        val c = controllerWith(actions)
        c.startSession()
        c.tapToTalk()
        hear("how do I turn on wifi on my router")

        assertTrue(actions.calls.isEmpty())
        assertEquals(1, assistant.calls.size)
    }
}
