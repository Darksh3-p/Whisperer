package com.darksh3ep.whisperer.domain

import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind
import com.darksh3ep.whisperer.domain.connectivity.ConnectivityIntent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ConnectivityIntentTest {
    @Test
    fun recognisesWifiRequests() {
        assertEquals(ConnectionKind.WIFI, ConnectivityIntent.parse("Turn on Wi-Fi"))
        assertEquals(ConnectionKind.WIFI, ConnectivityIntent.parse("turn on the wifi."))
        assertEquals(ConnectionKind.WIFI, ConnectivityIntent.parse("Please enable Wi-Fi"))
        assertEquals(ConnectionKind.WIFI, ConnectivityIntent.parse("switch my wifi on"))
        assertEquals(ConnectionKind.WIFI, ConnectivityIntent.parse("open wifi"))
    }

    @Test
    fun recognisesMobileDataRequests() {
        assertEquals(ConnectionKind.MOBILE_DATA, ConnectivityIntent.parse("turn on mobile data"))
        assertEquals(ConnectionKind.MOBILE_DATA, ConnectivityIntent.parse("Can you turn on cellular data please"))
        assertEquals(ConnectionKind.MOBILE_DATA, ConnectivityIntent.parse("enable data"))
        assertEquals(ConnectionKind.MOBILE_DATA, ConnectivityIntent.parse("open data"))
    }

    @Test
    fun recognisesGenericInternetRequests() {
        assertEquals(ConnectionKind.ANY, ConnectivityIntent.parse("turn on the internet"))
        assertEquals(ConnectionKind.ANY, ConnectivityIntent.parse("open internet"))
    }

    @Test
    fun ignoresQuestionsLongSentencesAndOtherSettings() {
        assertNull(ConnectivityIntent.parse("how do I turn on wifi on my router"))
        assertNull(ConnectivityIntent.parse("what is wifi"))
        assertNull(ConnectivityIntent.parse("turn on bluetooth"))
        assertNull(ConnectivityIntent.parse("turn on wifi settings"))
        assertNull(ConnectivityIntent.parse("enable data saver"))
        assertNull(ConnectivityIntent.parse("turn off wifi"))
        assertNull(ConnectivityIntent.parse(""))
    }
}
