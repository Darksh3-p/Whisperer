package com.darksh3ep.whisperer.service

import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.darksh3ep.whisperer.session.SessionHost

/**
 * Starts the visible foreground microphone service. This must only be called from a user-initiated
 * flow while the app is visible (Android 14+ restricts starting microphone foreground services otherwise).
 */
class AndroidSessionHost(
    context: Context,
    /** True while always-on wake listening still needs the foreground service after a conversation ends. */
    private val keepRunning: () -> Boolean = { false },
) : SessionHost {
    private val appContext = context.applicationContext

    override fun startBackgroundSession(): Boolean {
        // The persistent notification is mandatory for background microphone use: no notification, no background session.
        if (!NotificationManagerCompat.from(appContext).areNotificationsEnabled()) return false
        return try {
            ContextCompat.startForegroundService(appContext, Intent(appContext, VoiceSessionService::class.java))
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun stopBackgroundSession() {
        if (keepRunning()) return
        appContext.stopService(Intent(appContext, VoiceSessionService::class.java))
    }
}
