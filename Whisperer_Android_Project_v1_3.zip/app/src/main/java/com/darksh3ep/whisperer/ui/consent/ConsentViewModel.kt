package com.darksh3ep.whisperer.ui.consent

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darksh3ep.whisperer.AppContainer
import com.darksh3ep.whisperer.ai.speechrecognition.AsrAvailability
import com.darksh3ep.whisperer.ai.speechrecognition.ListenResult
import com.darksh3ep.whisperer.ai.speechrecognition.listenOnce
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechError
import com.darksh3ep.whisperer.ai.speechsynthesis.SpeechListener
import com.darksh3ep.whisperer.ai.speechsynthesis.TtsState
import com.darksh3ep.whisperer.connectivity.NetworkSnapshot
import com.darksh3ep.whisperer.connectivity.SystemPanels
import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind
import com.darksh3ep.whisperer.domain.connectivity.ConsentEvent
import com.darksh3ep.whisperer.domain.connectivity.ConsentReducer
import com.darksh3ep.whisperer.domain.connectivity.ConsentState
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Why the spoken consent flow cannot run right now. Whisperer never skips the spoken approval step. */
enum class ConsentBlock { NO_SPEECH_OUTPUT, NO_RECOGNITION, SESSION_ACTIVE, SPEECH_FAILED, PANEL_FAILED }

/**
 * Runs the connectivity consent flow:
 *   ask aloud (offline voice) -> listen for a clear spoken answer -> only on "yes" allow the Android panel
 *   -> user changes the setting in Android's own UI -> verify the real network state.
 * Nothing here changes any setting; Whisperer only opens Android's supported panel.
 */
class ConsentViewModel(
    private val container: AppContainer,
    val kind: ConnectionKind,
) : ViewModel() {

    private val _state = MutableStateFlow<ConsentState>(ConsentState.Idle)
    val state: StateFlow<ConsentState> = _state.asStateFlow()

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private val _listening = MutableStateFlow(false)
    /** True only while the microphone is really capturing the answer. */
    val listening: StateFlow<Boolean> = _listening.asStateFlow()

    private val _blocked = MutableStateFlow<ConsentBlock?>(null)
    val blocked: StateFlow<ConsentBlock?> = _blocked.asStateFlow()

    private val _snapshot = MutableStateFlow(NetworkSnapshot.OFFLINE)
    /** Network state observed after returning from Android's panel. */
    val snapshot: StateFlow<NetworkSnapshot> = _snapshot.asStateFlow()

    private var job: Job? = null
    private var pausedWhileAwaitingPanel = false

    private fun dispatch(event: ConsentEvent) {
        _state.value = ConsentReducer.reduce(_state.value, event)
    }

    /** [prompt] and [reprompt] are the exact texts shown on screen and spoken aloud. */
    fun begin(prompt: String, reprompt: String) {
        if (job != null || _state.value != ConsentState.Idle) return
        // Always-on listening shares the microphone: pause it for the whole spoken exchange.
        container.wakeListener.setPaused(true)
        job = viewModelScope.launch {
            val tts = container.speechOutput.capability.first { it.state != TtsState.INITIALIZING }
            if (tts.state != TtsState.OFFLINE_AVAILABLE) {
                _blocked.value = ConsentBlock.NO_SPEECH_OUTPUT
                return@launch
            }
            if (container.recognizer.availability() != AsrAvailability.AVAILABLE) {
                _blocked.value = ConsentBlock.NO_RECOGNITION
                return@launch
            }
            if (container.sessionController.state.value.sessionActive) {
                _blocked.value = ConsentBlock.SESSION_ACTIVE
                return@launch
            }
            dispatch(ConsentEvent.Begin(kind))
            var first = true
            while (_state.value is ConsentState.AwaitingApproval) {
                _speaking.value = true
                val spoken = speakAndWait(if (first) prompt else reprompt)
                _speaking.value = false
                if (!spoken) {
                    _blocked.value = ConsentBlock.SPEECH_FAILED
                    return@launch
                }
                first = false
                _listening.value = true
                val result = container.recognizer.listenOnce()
                _listening.value = false
                dispatch(
                    when (result) {
                        is ListenResult.Heard -> ConsentEvent.Heard(result.text)
                        is ListenResult.Failed -> ConsentEvent.HeardNothing
                    }
                )
            }
        }.also { launched ->
            launched.invokeOnCompletion { container.wakeListener.setPaused(false) }
        }
    }

    private suspend fun speakAndWait(text: String): Boolean = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { container.speechOutput.stop() }
        container.speechOutput.speak(text, object : SpeechListener {
            override fun onDone() {
                if (continuation.isActive) continuation.resume(true)
            }

            override fun onError(error: SpeechError) {
                if (continuation.isActive) continuation.resume(false)
            }
        })
    }

    fun onNotNow() {
        job?.cancel()
        job = null
        container.speechOutput.stop()
        _speaking.value = false
        _listening.value = false
        dispatch(ConsentEvent.TappedNotNow)
    }

    /** Only has an effect after a clear spoken "yes". */
    fun onContinueToAndroid(context: Context) {
        dispatch(ConsentEvent.TappedContinue)
        if (_state.value is ConsentState.AwaitingSystemPanel) {
            val opened = SystemPanels.openConnectivity(context, kind)
            if (!opened) _blocked.value = ConsentBlock.PANEL_FAILED
        }
    }

    fun onPaused() {
        if (_state.value is ConsentState.AwaitingSystemPanel) pausedWhileAwaitingPanel = true
    }

    /** When the user comes back from Android's panel, verify the real state instead of assuming. */
    fun onResumed() {
        if (pausedWhileAwaitingPanel && _state.value is ConsentState.AwaitingSystemPanel) {
            pausedWhileAwaitingPanel = false
            verify()
        }
    }

    fun verify() {
        val snapshot = container.connectivity.current()
        _snapshot.value = snapshot
        val ok = when (kind) {
            ConnectionKind.WIFI -> snapshot.viaWifi
            ConnectionKind.MOBILE_DATA -> snapshot.viaMobileData
            ConnectionKind.ANY -> snapshot.connected
        }
        if (_state.value is ConsentState.AwaitingSystemPanel) {
            dispatch(ConsentEvent.ReturnedFromSettings(ok))
        }
    }

    fun recheck() {
        _snapshot.value = container.connectivity.current()
    }

    override fun onCleared() {
        job?.cancel()
        container.speechOutput.stop()
        super.onCleared()
    }
}
