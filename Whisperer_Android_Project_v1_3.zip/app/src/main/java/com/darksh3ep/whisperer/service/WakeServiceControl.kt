package com.darksh3ep.whisperer.service

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/**
 * Starts and stops the foreground microphone service that hosts always-on wake listening.
 * [start] must only be called while the app is visible (Android 14+ refuses to start a microphone
 * foreground service from the background).
 */
class WakeServiceControl(context: Context) {
    private val appContext = context.applicationContext

    /** Returns true only if the service was really started (microphone permission + notifications are required). */
    fun start(): Boolean {
        val micGranted = ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (!micGranted) return false
        // The persistent notification is mandatory for background microphone use.
        if (!NotificationManagerCompat.from(appContext).areNotificationsEnabled()) return false
        return send(VoiceSessionService.ACTION_WAKE)
    }

    /** Re-posts the notification and drops the always-on wake lock while a background session keeps the service alive. */
    fun refresh(): Boolean = send(null)

    fun stop() {
        appContext.stopService(Intent(appContext, VoiceSessionService::class.java))
    }

    private fun send(action: String?): Boolean {
        return try {
            val intent = Intent(appContext, VoiceSessionService::class.java)
            if (action != null) intent.setAction(action)
            ContextCompat.startForegroundService(appContext, intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
