package com.darksh3ep.whisperer.domain.connectivity

enum class ConnectivityResult {
    /** The connection is now on and Android reports real internet through it. */
    CONNECTED,

    /** It was already connected; nothing was changed. */
    ALREADY_CONNECTED,

    /** The switch was turned on, but Android does not (yet) report a working connection through it. */
    SWITCHED_ON,

    /** Android's panel was opened but the switch could not be found or tapped; the user must tap it. */
    NEEDS_MANUAL_TAP,

    /** The auto-tap accessibility service is off, so Android's panel was opened for the user to tap. */
    AUTO_TAP_OFF,

    /** Android's panel could not be opened at all (phone locked, or Android refused). */
    PANEL_UNAVAILABLE,

    FAILED,
}

/** What the voice session can do when the user asks for a connection. Implemented on Android in the app layer. */
interface ConnectivityActions {
    /** Tries to switch the connection on and reports what really happened. */
    suspend fun enable(kind: ConnectionKind): ConnectivityResult

    /** The sentence shown and spoken to the user for [result] (localized). */
    fun describe(kind: ConnectionKind, result: ConnectivityResult): String
}
