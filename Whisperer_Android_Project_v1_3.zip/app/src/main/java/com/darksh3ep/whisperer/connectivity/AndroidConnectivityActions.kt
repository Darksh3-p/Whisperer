package com.darksh3ep.whisperer.connectivity

import android.content.Context
import com.darksh3ep.whisperer.R
import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind
import com.darksh3ep.whisperer.domain.connectivity.ConnectivityActions
import com.darksh3ep.whisperer.domain.connectivity.ConnectivityResult
import com.darksh3ep.whisperer.service.AutoTapService
import com.darksh3ep.whisperer.service.TapOutcome
import kotlinx.coroutines.delay

/**
 * Switches Wi-Fi / mobile data on by voice request. With the opt-in auto-tap accessibility service it opens Android's
 * own connectivity panel and taps the switch; without it, it only opens the panel for the user to tap.
 * The result always comes from what Android really reports afterwards.
 */
class AndroidConnectivityActions(
    context: Context,
    private val checker: ConnectivityChecker,
) : ConnectivityActions {
    private val appContext = context.applicationContext

    override suspend fun enable(kind: ConnectionKind): ConnectivityResult {
        if (isConnected(kind)) return ConnectivityResult.ALREADY_CONNECTED

        val service = AutoTapService.instance
        if (service == null) {
            return if (SystemPanels.openConnectivity(appContext, kind)) {
                ConnectivityResult.AUTO_TAP_OFF
            } else {
                ConnectivityResult.PANEL_UNAVAILABLE
            }
        }

        return when (service.enableAndWait(kind)) {
            TapOutcome.PANEL_FAILED -> ConnectivityResult.PANEL_UNAVAILABLE
            TapOutcome.NOT_FOUND -> ConnectivityResult.NEEDS_MANUAL_TAP
            TapOutcome.SWITCHED_ON, TapOutcome.ALREADY_ON -> waitForConnection(kind)
        }
    }

    private suspend fun waitForConnection(kind: ConnectionKind): ConnectivityResult {
        // Mobile data often stays idle while Wi-Fi is the active network, so do not wait long for it.
        val polls = if (kind == ConnectionKind.MOBILE_DATA) 3 else 8
        repeat(polls) {
            delay(1_000)
            if (isConnected(kind)) return ConnectivityResult.CONNECTED
        }
        return ConnectivityResult.SWITCHED_ON
    }

    private fun isConnected(kind: ConnectionKind): Boolean {
        val snapshot = checker.current()
        return when (kind) {
            ConnectionKind.WIFI -> snapshot.viaWifi
            ConnectionKind.MOBILE_DATA -> snapshot.viaMobileData
            ConnectionKind.ANY -> snapshot.connected
        }
    }

    override fun describe(kind: ConnectionKind, result: ConnectivityResult): String {
        val res = when (result) {
            ConnectivityResult.CONNECTED -> when (kind) {
                ConnectionKind.WIFI -> R.string.conn_wifi_connected
                ConnectionKind.MOBILE_DATA -> R.string.conn_data_connected
                ConnectionKind.ANY -> R.string.conn_any_connected
            }
            ConnectivityResult.ALREADY_CONNECTED -> when (kind) {
                ConnectionKind.WIFI -> R.string.conn_wifi_already
                ConnectionKind.MOBILE_DATA -> R.string.conn_data_already
                ConnectionKind.ANY -> R.string.conn_any_already
            }
            ConnectivityResult.SWITCHED_ON -> when (kind) {
                ConnectionKind.WIFI -> R.string.conn_wifi_switched_on
                ConnectionKind.MOBILE_DATA -> R.string.conn_data_switched_on
                ConnectionKind.ANY -> R.string.conn_any_switched_on
            }
            ConnectivityResult.NEEDS_MANUAL_TAP -> R.string.conn_manual_tap
            ConnectivityResult.AUTO_TAP_OFF -> R.string.conn_auto_tap_off
            ConnectivityResult.PANEL_UNAVAILABLE -> R.string.conn_panel_unavailable
            ConnectivityResult.FAILED -> R.string.conn_failed
        }
        return appContext.getString(res)
    }
}
