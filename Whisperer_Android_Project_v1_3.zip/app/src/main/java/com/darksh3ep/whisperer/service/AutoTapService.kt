package com.darksh3ep.whisperer.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.darksh3ep.whisperer.connectivity.SystemPanels
import com.darksh3ep.whisperer.domain.connectivity.ConnectionKind
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

enum class TapOutcome {
    /** The switch was off and has been tapped. */
    SWITCHED_ON,

    /** The switch was already on. */
    ALREADY_ON,

    /** Android's panel opened, but no matching switch was found in time. */
    NOT_FOUND,

    /** Android's panel could not be opened. */
    PANEL_FAILED,
}

/**
 * Opt-in accessibility service that taps the Wi-Fi or mobile-data switch in Android's own internet panel.
 *
 * Android does not let ordinary apps switch these directly, so this is the only way to do it without root.
 * It is deliberately narrow:
 *  - it subscribes to no useful events ([onAccessibilityEvent] does nothing);
 *  - it reads the screen ONLY while a request from the voice session is running (about 12 seconds at most);
 *  - it only looks at windows of Android's settings / system UI, and only ever taps one switch whose label
 *    says Wi-Fi or mobile data (never airplane mode, hotspot, Bluetooth, data saver, roaming, ...);
 *  - it never types, never reads text into the app, and never stores anything.
 * The user must switch the service on themselves in Android's Accessibility settings.
 */
class AutoTapService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var tick: Runnable? = null
    private var pendingDone: ((TapOutcome) -> Unit)? = null
    private var elapsedMs = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    // Deliberately ignored: this service never reacts to what is on the screen.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        finishNow(TapOutcome.NOT_FOUND)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        finishNow(TapOutcome.PANEL_FAILED)
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        finishNow(TapOutcome.PANEL_FAILED)
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** Opens Android's connectivity panel and taps the matching switch. Call on the main thread. */
    suspend fun enableAndWait(kind: ConnectionKind): TapOutcome = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { stopPolling(); pendingDone = null }
        start(kind) { outcome -> if (cont.isActive) cont.resume(outcome) }
    }

    private fun start(kind: ConnectionKind, onDone: (TapOutcome) -> Unit) {
        // A newer request replaces an older one that is still waiting.
        finishNow(TapOutcome.PANEL_FAILED)
        pendingDone = onDone
        if (!SystemPanels.openConnectivity(this, kind)) {
            complete(TapOutcome.PANEL_FAILED)
            return
        }
        elapsedMs = 0L
        val runnable = object : Runnable {
            override fun run() {
                val outcome = tryOnce(kind)
                if (outcome != null) {
                    complete(outcome)
                } else if (elapsedMs >= TIMEOUT_MS) {
                    complete(TapOutcome.NOT_FOUND)
                } else {
                    elapsedMs += STEP_MS
                    handler.postDelayed(this, STEP_MS)
                }
            }
        }
        tick = runnable
        handler.postDelayed(runnable, FIRST_DELAY_MS)
    }

    private fun stopPolling() {
        tick?.let { handler.removeCallbacks(it) }
        tick = null
    }

    private fun finishNow(outcome: TapOutcome) {
        stopPolling()
        val done = pendingDone
        pendingDone = null
        done?.invoke(outcome)
    }

    private fun complete(outcome: TapOutcome) {
        stopPolling()
        val done = pendingDone
        pendingDone = null
        if (outcome == TapOutcome.SWITCHED_ON || outcome == TapOutcome.ALREADY_ON) {
            // Close Android's panel again so the user lands back where they were, but only if it is still the
            // window on screen (otherwise Back would leave whatever app the user is in).
            handler.postDelayed({
                val pkg = rootInActiveWindow?.packageName?.toString().orEmpty()
                if (isSystemSettingsPackage(pkg)) performGlobalAction(GLOBAL_ACTION_BACK)
            }, CLOSE_DELAY_MS)
        }
        done?.invoke(outcome)
    }

    private class SwitchRow(val node: AccessibilityNodeInfo, val label: String)

    /** One attempt: null means "not there yet, keep polling". */
    private fun tryOnce(kind: ConnectionKind): TapOutcome? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString().orEmpty()
        if (!isSystemSettingsPackage(pkg)) return null

        val switches = ArrayList<SwitchRow>()
        collectSwitches(root, switches, 0)

        val wifi = switches.filter { isWifiSwitch(it.label) }
        val data = switches.filter { isDataSwitch(it.label) }
        val wanted = when (kind) {
            ConnectionKind.WIFI -> wifi
            ConnectionKind.MOBILE_DATA -> data
            ConnectionKind.ANY -> wifi + data
        }
        if (wanted.isEmpty()) return null

        val off = wanted.firstOrNull { !it.node.isChecked } ?: return TapOutcome.ALREADY_ON
        return if (click(off.node)) TapOutcome.SWITCHED_ON else null
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        var parent: AccessibilityNodeInfo? = node.parent
        var steps = 0
        while (parent != null && steps < 3) {
            if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            parent = parent.parent
            steps++
        }
        return false
    }

    private fun collectSwitches(node: AccessibilityNodeInfo, out: MutableList<SwitchRow>, depth: Int) {
        if (depth > MAX_DEPTH) return
        if (node.isCheckable) out.add(SwitchRow(node, labelOf(node)))
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectSwitches(child, out, depth + 1)
        }
    }

    /** The words that identify a switch: its own text/id, else the text of the nearest row that holds only this switch. */
    private fun labelOf(node: AccessibilityNodeInfo): String {
        val own = describe(node)
        if (own.isNotBlank()) return own.lowercase()
        var current: AccessibilityNodeInfo? = node.parent
        var steps = 0
        while (current != null && steps < 5) {
            if (countCheckable(current, 0) > 1) break
            val text = collectText(current, 0)
            if (text.isNotBlank()) return text.lowercase()
            current = current.parent
            steps++
        }
        return ""
    }

    private fun describe(node: AccessibilityNodeInfo): String =
        listOfNotNull(node.text, node.contentDescription, node.viewIdResourceName)
            .joinToString(" ") { it.toString() }

    private fun collectText(node: AccessibilityNodeInfo, depth: Int): String {
        if (depth > 6) return ""
        val builder = StringBuilder(describe(node))
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            builder.append(' ').append(collectText(child, depth + 1))
            if (builder.length > 400) break
        }
        return builder.toString()
    }

    private fun countCheckable(node: AccessibilityNodeInfo, depth: Int): Int {
        if (depth > 6) return 0
        var count = if (node.isCheckable) 1 else 0
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            count += countCheckable(child, depth + 1)
            if (count > 1) return count
        }
        return count
    }

    companion object {
        /** The connected service, or null when the user has not switched auto-tap on. */
        @Volatile
        var instance: AutoTapService? = null

        private const val FIRST_DELAY_MS = 900L
        private const val STEP_MS = 500L
        private const val TIMEOUT_MS = 12_000L
        private const val CLOSE_DELAY_MS = 900L
        private const val MAX_DEPTH = 40

        // Switches that must never be tapped, even when their label also mentions Wi-Fi or mobile data.
        private val NEVER = listOf(
            "airplane", "aeroplane", "flight", "hotspot", "tether", "bluetooth", "saver", "roaming",
            "calling", "scanning", "direct", "nearby",
        )
        private val WIFI_WORDS = listOf("wi-fi", "wifi", "wi fi", "wlan", "wi\u2011fi")
        private val DATA_WORDS = listOf(
            "mobile data", "mobile_data", "cellular", "mobile_toggle", "mobile network", "mobile internet",
        )

        internal fun isWifiSwitch(label: String): Boolean =
            NEVER.none { label.contains(it) } && WIFI_WORDS.any { label.contains(it) }

        internal fun isDataSwitch(label: String): Boolean =
            NEVER.none { label.contains(it) } &&
                !WIFI_WORDS.any { label.contains(it) } &&
                DATA_WORDS.any { label.contains(it) }

        internal fun isSystemSettingsPackage(pkg: String): Boolean =
            pkg.contains("settings") || pkg.contains("systemui")
    }
}
