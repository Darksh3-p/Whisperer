package com.darksh3ep.whisperer.session

import com.darksh3ep.whisperer.ai.speechrecognition.AsrAvailability
import com.darksh3ep.whisperer.ai.speechrecognition.RecognitionCallbacks
import com.darksh3ep.whisperer.ai.speechrecognition.RecognitionFailure
import com.darksh3ep.whisperer.ai.speechrecognition.SpeechRecognizerProvider
import com.darksh3ep.whisperer.domain.commands.WakePhraseConfig
import com.darksh3ep.whisperer.domain.commands.WakePhraseMatcher
import com.darksh3ep.whisperer.domain.conversation.Phase
import com.darksh3ep.whisperer.domain.conversation.SessionUiState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** What the always-on listener is doing, for the UI. */
enum class WakeStatus {
    /** Not started (or switched off). */
    OFF,

    /** The microphone is open and waiting for the wake phrase. */
    LISTENING,

    /** A conversation (or mute) has the microphone; listening resumes when it is idle again. */
    BUSY,

    NEEDS_MIC_PERMISSION,

    /** No usable speech recognizer (Whisper model not imported and no on-device Android recognizer). */
    UNAVAILABLE,
}

/**
 * Always-on wake phrase listening.
 *
 * It repeatedly asks the normal speech recognizer (Whisper if a model is imported, otherwise Android's on-device
 * recognizer) to hear one utterance, and checks whether that utterance STARTS with the user's wake phrase.
 * Speech that does not start with the wake phrase is discarded: it is never stored, sent or shown.
 *
 * The listener only owns the microphone while the session is idle. During a conversation the
 * [VoiceSessionController] owns it, and listening resumes by itself when the conversation is idle again.
 * All methods must be called on the main thread.
 */
class WakeListener(
    private val scope: CoroutineScope,
    private val recognizer: SpeechRecognizerProvider,
    private val session: StateFlow<SessionUiState>,
    private val wakeConfig: () -> WakePhraseConfig,
    /** Called with whatever was said after the wake phrase (may be empty). */
    private val onWake: (String) -> Unit,
    /** Short audible "I'm listening" signal, played only when nothing followed the wake phrase. */
    private val cue: () -> Unit = {},
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private val _status = MutableStateFlow(WakeStatus.OFF)
    val status: StateFlow<WakeStatus> = _status.asStateFlow()

    private var isRunning = false
    private var paused = false

    /** True from [start] until [stop] (or a fatal problem). */
    val running: Boolean get() = isRunning

    private var armed = false
    private var armedAt = 0L
    private var token = 0
    private var failures = 0
    private var watchJob: Job? = null
    private var retryJob: Job? = null
    private var wakeJob: Job? = null

    fun start() {
        if (isRunning) return
        isRunning = true
        failures = 0
        watchJob = scope.launch { session.collect { onSession(it) } }
    }

    /**
     * Temporarily hands the microphone to something else (the "Test wake phrase" button, the spoken consent
     * question). Listening resumes by itself when [value] is set back to false.
     */
    fun setPaused(value: Boolean) {
        if (paused == value) return
        paused = value
        if (!isRunning) return
        if (value) {
            val owned = armed
            armed = false
            token++
            retryJob?.cancel()
            retryJob = null
            if (owned && session.value.phase == Phase.IDLE) recognizer.cancel()
            _status.value = WakeStatus.BUSY
        } else {
            onSession(session.value)
        }
    }

    fun stop() {
        isRunning = false
        watchJob?.cancel()
        watchJob = null
        retryJob?.cancel()
        retryJob = null
        wakeJob?.cancel()
        wakeJob = null
        val owned = armed
        armed = false
        token++
        // Only cancel what we started: during a conversation the session controller owns the recognizer.
        if (owned && session.value.phase == Phase.IDLE) recognizer.cancel()
        _status.value = WakeStatus.OFF
    }

    private fun fail(status: WakeStatus) {
        isRunning = false
        watchJob?.cancel()
        watchJob = null
        retryJob?.cancel()
        retryJob = null
        wakeJob?.cancel()
        wakeJob = null
        armed = false
        token++
        _status.value = status
    }

    private fun onSession(state: SessionUiState) {
        if (!isRunning) return
        if (state.phase == Phase.IDLE && !state.micMuted && !paused) {
            arm()
        } else {
            if (armed) {
                armed = false
                token++
                // Muted while idle: our own capture must stop. In every other phase the session controller
                // has already taken over the recognizer (starting it cancels ours).
                if (state.phase == Phase.IDLE) recognizer.cancel()
            }
            retryJob?.cancel()
            retryJob = null
            _status.value = WakeStatus.BUSY
        }
    }

    private fun arm() {
        if (armed || !isRunning) return
        if (retryJob?.isActive == true) return
        if (recognizer.availability() != AsrAvailability.AVAILABLE) {
            fail(WakeStatus.UNAVAILABLE)
            return
        }
        armed = true
        armedAt = clock()
        token++
        val mine = token
        _status.value = WakeStatus.LISTENING
        recognizer.start(object : RecognitionCallbacks {
            override fun onFinal(text: String, confidence: Float?) {
                if (mine != token || !armed) return
                armed = false
                failures = 0
                onHeard(text)
            }

            override fun onFailure(reason: RecognitionFailure) {
                if (mine != token || !armed) return
                armed = false
                onFailed(reason)
            }
        })
    }

    private fun onHeard(text: String) {
        val hit = WakePhraseMatcher.findAtStart(text, wakeConfig())
        if (hit == null) {
            // Ordinary speech: discard it and keep listening.
            scheduleRearm(0L)
            return
        }
        wakeJob?.cancel()
        wakeJob = scope.launch {
            if (hit.trailing.isEmpty()) {
                cue()
                // Let the cue finish so it is not mistaken for speech by the next recording.
                delay(CUE_GAP_MS)
            }
            if (isRunning) onWake(hit.trailing)
            scheduleRearm(REARM_AFTER_WAKE_MS)
        }
    }

    private fun onFailed(reason: RecognitionFailure) {
        when (reason) {
            RecognitionFailure.NO_SPEECH -> {
                // A normal silence timeout takes seconds; an instant one means the microphone is not really usable.
                if (clock() - armedAt < QUICK_FAILURE_MS) backoff() else {
                    failures = 0
                    scheduleRearm(0L)
                }
            }
            RecognitionFailure.PERMISSION -> fail(WakeStatus.NEEDS_MIC_PERMISSION)
            RecognitionFailure.UNAVAILABLE -> fail(WakeStatus.UNAVAILABLE)
            RecognitionFailure.BUSY,
            RecognitionFailure.OTHER -> backoff()
        }
    }

    /** Microphone busy (for example during a phone call): retry slowly, never in a tight loop. */
    private fun backoff() {
        failures++
        val steps = (failures - 1).coerceAtMost(5)
        val delayMs = (BACKOFF_BASE_MS shl steps).coerceAtMost(BACKOFF_MAX_MS)
        scheduleRearm(delayMs)
    }

    private fun scheduleRearm(delayMs: Long) {
        retryJob?.cancel()
        retryJob = scope.launch {
            if (delayMs > 0L) delay(delayMs)
            retryJob = null
            onSession(session.value)
        }
    }

    private companion object {
        const val CUE_GAP_MS = 350L
        const val REARM_AFTER_WAKE_MS = 300L
        const val QUICK_FAILURE_MS = 1_500L
        const val BACKOFF_BASE_MS = 500L
        const val BACKOFF_MAX_MS = 15_000L
    }
}
