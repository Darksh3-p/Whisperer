package com.darksh3ep.whisperer.domain.connectivity

import com.darksh3ep.whisperer.domain.commands.PhraseText

/**
 * Recognises SHORT spoken English requests to switch a connection on, such as "turn on Wi-Fi",
 * "please switch mobile data on" or "enable the internet". Longer sentences and questions
 * ("how do I turn on wifi on my router?") are deliberately not matched and go to the assistant instead.
 * Only switching ON is supported.
 */
object ConnectivityIntent {
    private val leadIns = listOf("please ", "can you ", "could you ", "would you ", "will you ", "hey ", "okay ", "ok ")
    private val verbFirst = Regex("^(?:turn on|switch on|enable|activate|open|start|power on|put on)(?: the| my)? (.+)$")
    private val verbLast = Regex("^(?:turn|switch|put|power)(?: the| my)? (.+) on$")

    private val wifiTargets = setOf(
        "wifi", "wi fi", "wifi connection", "wi fi connection", "wireless", "wlan", "wifi internet", "wi fi internet",
    )
    private val dataTargets = setOf(
        "data", "mobile data", "cellular data", "cell data", "mobile internet", "cellular",
        "data connection", "mobile data connection", "mobile network",
    )
    private val anyTargets = setOf("internet", "internet connection", "network", "connection")

    fun parse(utterance: String): ConnectionKind? {
        var text = PhraseText.normalize(utterance)
        if (text.isEmpty()) return null

        var stripped = true
        while (stripped) {
            stripped = false
            for (lead in leadIns) {
                if (text.startsWith(lead)) {
                    text = text.removePrefix(lead).trim()
                    stripped = true
                }
            }
        }
        text = text.removeSuffix(" please").trim()
        if (text.isEmpty() || text.split(' ').size > 7) return null

        val target = verbFirst.find(text)?.groupValues?.get(1)
            ?: verbLast.find(text)?.groupValues?.get(1)
            ?: return null
        val cleaned = target.removeSuffix(" please").trim()
        return when (cleaned) {
            in wifiTargets -> ConnectionKind.WIFI
            in dataTargets -> ConnectionKind.MOBILE_DATA
            in anyTargets -> ConnectionKind.ANY
            else -> null
        }
    }
}
